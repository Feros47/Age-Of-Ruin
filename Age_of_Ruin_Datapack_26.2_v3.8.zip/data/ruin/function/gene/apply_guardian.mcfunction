execute if entity @s[tag=ruin.gene_guardian] run return 0
tag @s add ruin.gene_guardian
tag @s add ruin.genetic
tag @s add ruin.name_dirty
attribute @s minecraft:knockback_resistance modifier add ruin:gene_guardian 0.4 add_value
execute store success score @s ruin_tmp store result score @s ruin_base_dmg run attribute @s minecraft:attack_damage base get 100
execute if score @s ruin_base_dmg matches 1.. run attribute @s minecraft:attack_damage modifier add ruin:gene_guardian 0.6 add_multiplied_total

tag @s remove ruin.gene_loot_assigned
function ruin:gene/assign_loot_table
