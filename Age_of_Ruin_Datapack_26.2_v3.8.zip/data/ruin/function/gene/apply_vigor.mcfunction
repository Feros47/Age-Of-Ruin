execute if entity @s[tag=ruin.gene_vigor] run return 0
tag @s add ruin.gene_vigor
tag @s add ruin.genetic
tag @s add ruin.name_dirty
attribute @s minecraft:max_health modifier add ruin:gene_vigor 0.5 add_multiplied_total
effect give @s minecraft:regeneration 2 4 true

tag @s remove ruin.gene_loot_assigned
function ruin:gene/assign_loot_table
