execute if entity @s[tag=ruin.gene_swift] run return 0
tag @s add ruin.gene_swift
tag @s add ruin.genetic
tag @s add ruin.name_dirty
attribute @s minecraft:movement_speed modifier add ruin:gene_swift 0.30 add_multiplied_total

tag @s remove ruin.gene_loot_assigned
function ruin:gene/assign_loot_table
