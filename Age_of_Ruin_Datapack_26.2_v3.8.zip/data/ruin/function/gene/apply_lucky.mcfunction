execute if entity @s[tag=ruin.gene_lucky] run return 0
tag @s add ruin.gene_lucky
tag @s add ruin.genetic
tag @s add ruin.name_dirty

tag @s remove ruin.gene_loot_assigned
function ruin:gene/assign_loot_table
