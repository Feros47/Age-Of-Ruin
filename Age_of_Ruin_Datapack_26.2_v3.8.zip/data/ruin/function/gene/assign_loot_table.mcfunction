# v3.4: assign a gene-aware death loot table. Existing vanilla drops are preserved inside each custom table.
execute if entity @s[type=minecraft:cow] run data merge entity @s {DeathLootTable:"ruin:gene/entities/cow"}
execute if entity @s[type=minecraft:pig] run data merge entity @s {DeathLootTable:"ruin:gene/entities/pig"}
execute if entity @s[type=minecraft:sheep] run data merge entity @s {DeathLootTable:"ruin:gene/entities/sheep"}
execute if entity @s[type=minecraft:chicken] run data merge entity @s {DeathLootTable:"ruin:gene/entities/chicken"}
execute if entity @s[type=minecraft:wolf] run data merge entity @s {DeathLootTable:"ruin:gene/entities/wolf"}
execute if entity @s[type=minecraft:horse] run data merge entity @s {DeathLootTable:"ruin:gene/entities/horse"}
execute if entity @s[type=minecraft:donkey] run data merge entity @s {DeathLootTable:"ruin:gene/entities/donkey"}
execute if entity @s[type=minecraft:mule] run data merge entity @s {DeathLootTable:"ruin:gene/entities/mule"}
execute if entity @s[type=minecraft:camel] run data merge entity @s {DeathLootTable:"ruin:gene/entities/camel"}
execute if entity @s[type=minecraft:goat] run data merge entity @s {DeathLootTable:"ruin:gene/entities/goat"}
execute if entity @s[type=minecraft:bee] run data merge entity @s {DeathLootTable:"ruin:gene/entities/bee"}
execute if entity @s[type=minecraft:rabbit] run data merge entity @s {DeathLootTable:"ruin:gene/entities/rabbit"}
execute if entity @s[type=minecraft:axolotl] run data merge entity @s {DeathLootTable:"ruin:gene/entities/axolotl"}
execute if entity @s[type=minecraft:turtle] run data merge entity @s {DeathLootTable:"ruin:gene/entities/turtle"}
execute if entity @s[type=minecraft:frog] run data merge entity @s {DeathLootTable:"ruin:gene/entities/frog"}
execute if entity @s[type=minecraft:cat] run data merge entity @s {DeathLootTable:"ruin:gene/entities/cat"}
execute if entity @s[type=minecraft:ocelot] run data merge entity @s {DeathLootTable:"ruin:gene/entities/ocelot"}
execute if entity @s[type=minecraft:fox] run data merge entity @s {DeathLootTable:"ruin:gene/entities/fox"}
execute if entity @s[type=minecraft:llama] run data merge entity @s {DeathLootTable:"ruin:gene/entities/llama"}
execute if entity @s[type=minecraft:trader_llama] run data merge entity @s {DeathLootTable:"ruin:gene/entities/trader_llama"}
execute if entity @s[type=minecraft:panda] run data merge entity @s {DeathLootTable:"ruin:gene/entities/panda"}
execute if entity @s[type=minecraft:mooshroom] run data merge entity @s {DeathLootTable:"ruin:gene/entities/mooshroom"}
execute if entity @s[type=minecraft:sniffer] run data merge entity @s {DeathLootTable:"ruin:gene/entities/sniffer"}
execute if entity @s[type=minecraft:armadillo] run data merge entity @s {DeathLootTable:"ruin:gene/entities/armadillo"}
execute if entity @s[type=minecraft:nautilus] run data merge entity @s {DeathLootTable:"ruin:gene/entities/nautilus"}
execute if entity @s[type=minecraft:strider] run data merge entity @s {DeathLootTable:"ruin:gene/entities/strider"}
tag @s add ruin.gene_loot_assigned
