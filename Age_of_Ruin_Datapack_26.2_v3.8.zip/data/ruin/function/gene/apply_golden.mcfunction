execute if entity @s[tag=ruin.gene_golden] run return 0
tag @s add ruin.gene_golden
tag @s add ruin.genetic
tag @s add ruin.name_dirty

tag @s remove ruin.gene_loot_assigned
function ruin:gene/assign_loot_table
