execute if entity @s[tag=ruin.gene_arcane] run return 0
tag @s add ruin.gene_arcane
tag @s add ruin.genetic
tag @s add ruin.name_dirty

tag @s remove ruin.gene_loot_assigned
function ruin:gene/assign_loot_table
