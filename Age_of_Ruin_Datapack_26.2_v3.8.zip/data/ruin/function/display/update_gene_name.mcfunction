data modify entity @s CustomName set value {text:'Genes',color:'green',bold:true,extra:[{text:''}]}
execute if entity @s[tag=ruin.gene_vigor] run data modify entity @s CustomName.extra append value {text:' • Vigor',color:'red'}
execute if entity @s[tag=ruin.gene_swift] run data modify entity @s CustomName.extra append value {text:' • Swift',color:'aqua'}
execute if entity @s[tag=ruin.gene_guardian] run data modify entity @s CustomName.extra append value {text:' • Guardian',color:'blue'}
execute if entity @s[tag=ruin.gene_primal] run data modify entity @s CustomName.extra append value {text:' • Primal',color:'dark_green'}
execute if entity @s[tag=ruin.gene_gourmet] run data modify entity @s CustomName.extra append value {text:' • Gourmet',color:'gold'}
execute if entity @s[tag=ruin.gene_golden] run data modify entity @s CustomName.extra append value {text:' • Golden',color:'yellow'}
execute if entity @s[tag=ruin.gene_arcane] run data modify entity @s CustomName.extra append value {text:' • Arcane',color:'light_purple'}
execute if entity @s[tag=ruin.gene_lucky] run data modify entity @s CustomName.extra append value {text:' • Lucky',color:'green'}
execute if entity @s[tag=ruin.gene_alchemist] run data modify entity @s CustomName.extra append value {text:' • Alchemist',color:'dark_aqua'}
execute if entity @s[tag=ruin.gene_invincible] run data modify entity @s CustomName.extra append value {text:' • INVINCIBLE',color:'gold',bold:true}
data merge entity @s {CustomNameVisible:1b}
tag @s remove ruin.name_dirty
