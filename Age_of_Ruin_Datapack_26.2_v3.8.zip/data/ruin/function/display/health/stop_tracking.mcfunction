# Executed as and at the living entity leaving health-label range.
execute on passengers if entity @s[type=minecraft:text_display,tag=ruin.health_display] run kill @s
tag @s remove ruin.health_tracked
scoreboard players reset @s ruin_namehp
scoreboard players reset @s ruin_namemax
scoreboard players reset @s ruin_namepct
