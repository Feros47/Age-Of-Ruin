# Cache integer current/max health on the parent entity.
execute store result score @s ruin_namehp run data get entity @s Health 1
execute store result score @s ruin_namemax run attribute @s minecraft:max_health get 1
scoreboard players operation @s ruin_namepct = @s ruin_namehp
scoreboard players operation @s ruin_namepct *= #hundred ruin_namepct
execute if score @s ruin_namemax matches 1.. run scoreboard players operation @s ruin_namepct /= @s ruin_namemax

# Macro storage supplies the values without hard-coding entity types or health caps.
execute store result storage ruin:health current int 1 run scoreboard players get @s ruin_namehp
execute store result storage ruin:health max int 1 run scoreboard players get @s ruin_namemax
execute if score @s ruin_namepct matches 67.. on passengers if entity @s[type=minecraft:text_display,tag=ruin.health_display] run function ruin:display/health/render_green with storage ruin:health
execute if score @s ruin_namepct matches 34..66 on passengers if entity @s[type=minecraft:text_display,tag=ruin.health_display] run function ruin:display/health/render_yellow with storage ruin:health
execute if score @s ruin_namepct matches ..33 on passengers if entity @s[type=minecraft:text_display,tag=ruin.health_display] run function ruin:display/health/render_red with storage ruin:health
