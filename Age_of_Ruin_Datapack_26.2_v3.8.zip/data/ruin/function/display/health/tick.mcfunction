# Add a lightweight health display to every living non-player entity near a player.
# A wider removal radius prevents rapid attach/detach churn at the tracking edge.
execute as @a at @s as @e[type=!minecraft:player,type=!minecraft:armor_stand,tag=!ruin.health_tracked,distance=..48] if data entity @s Health run function ruin:display/health/start_tracking

# Stop tracking mobs that are no longer near any player and remove their passenger display.
execute as @e[type=!minecraft:player,tag=ruin.health_tracked] at @s unless entity @a[distance=..56] run function ruin:display/health/stop_tracking

# Remove displays whose parent died or was removed.
tag @e[type=minecraft:text_display,tag=ruin.health_display] add ruin.health_orphan
execute as @e[type=!minecraft:player,tag=ruin.health_tracked] on passengers if entity @s[type=minecraft:text_display,tag=ruin.health_display] run tag @s remove ruin.health_orphan
kill @e[type=minecraft:text_display,tag=ruin.health_orphan]

# Repair manually deleted passengers, then refresh all visible values and colors.
execute as @e[type=!minecraft:player,tag=ruin.health_tracked] if data entity @s Health unless data entity @s Passengers[{Tags:["ruin.health_display"]}] at @s run function ruin:display/health/attach
execute as @e[type=!minecraft:player,tag=ruin.health_tracked] if data entity @s Health run function ruin:display/health/update
