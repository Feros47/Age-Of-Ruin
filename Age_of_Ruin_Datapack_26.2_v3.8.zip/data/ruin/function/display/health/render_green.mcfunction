$data modify entity @s text set value {text:"❤ $(current) / $(max) HP",color:"green",bold:true}
