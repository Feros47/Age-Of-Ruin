$data modify entity @s text set value {text:"❤ $(current) / $(max) HP",color:"red",bold:true}
