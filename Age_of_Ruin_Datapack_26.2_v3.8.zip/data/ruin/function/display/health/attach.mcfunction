# The display rides the mob so following is free and exact between one-second updates.
summon minecraft:text_display ~ ~ ~ {Tags:["ruin.health_display","ruin.health_new"],Invulnerable:1b,billboard:"center",view_range:1f,shadow:1b,see_through:0b,default_background:0b,background:0,line_width:200,text_opacity:-1b,alignment:"center",text:{text:"HP",color:"green",bold:true},transformation:{translation:[0f,0.75f,0f],left_rotation:[0f,0f,0f,1f],scale:[1f,1f,1f],right_rotation:[0f,0f,0f,1f]}}
ride @e[type=minecraft:text_display,tag=ruin.health_new,distance=..1,limit=1,sort=nearest] mount @s
tag @e[type=minecraft:text_display,tag=ruin.health_new,distance=..1,limit=1,sort=nearest] remove ruin.health_new

# Taller encounters need more separation from their existing boss/miniboss names.
execute if entity @s[tag=ruin.miniboss] on passengers if entity @s[type=minecraft:text_display,tag=ruin.health_display] run data modify entity @s transformation.translation set value [0f,1.15f,0f]
execute if entity @s[tag=ruin.boss] on passengers if entity @s[type=minecraft:text_display,tag=ruin.health_display] run data modify entity @s transformation.translation set value [0f,1.75f,0f]
