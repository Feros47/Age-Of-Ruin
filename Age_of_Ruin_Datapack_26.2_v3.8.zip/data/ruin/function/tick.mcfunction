# Keep the self-rescheduling one-second heartbeat alive and run projectile/relic logic every game tick.
execute unless score #runtime_ready ruin_runtime matches 1 run schedule function ruin:runtime/heartbeat 1t replace
execute in minecraft:overworld run function ruin:fast_tick
execute if entity @a[predicate=ruin:in_nether] in minecraft:the_nether run function ruin:fast_tick
execute if entity @a[predicate=ruin:in_end] in minecraft:the_end run function ruin:fast_tick
