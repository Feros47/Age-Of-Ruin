# Age of Ruin v3.8 loader
scoreboard objectives add ruin_state dummy
scoreboard objectives add ruin_version dummy
execute unless score #version ruin_version matches 38 run function ruin:migrate/v38
execute if score #version ruin_version matches 38 run scoreboard players set #runtime_ready ruin_runtime 0
execute if score #version ruin_version matches 38 run schedule function ruin:runtime/heartbeat 1t replace
execute if score #version ruin_version matches 38 run tellraw @a [{text:'[Age of Ruin] ',color:'dark_red',bold:true},{text:'v3.8 runtime loaded.',color:'gold'}]
