execute if score #active_lich_king ruin_state matches 1 run return 0
execute if entity @e[tag=ruin.boss_lich_king] run return 0
function ruin:boss/summon_lich_king
function ruin:altar/consume_one
