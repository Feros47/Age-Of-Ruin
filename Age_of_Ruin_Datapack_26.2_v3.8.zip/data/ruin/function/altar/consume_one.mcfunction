execute store result score @s ruin_tmp run data get entity @s Item.count
scoreboard players remove @s ruin_tmp 1
execute if score @s ruin_tmp matches ..0 run kill @s
execute if score @s ruin_tmp matches 1.. store result entity @s Item.count int 1 run scoreboard players get @s ruin_tmp
