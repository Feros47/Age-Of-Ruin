execute if score #active_leviathan ruin_state matches 1 run return 0
execute if entity @e[tag=ruin.boss_leviathan] run return 0
function ruin:boss/summon_leviathan
function ruin:altar/consume_one
