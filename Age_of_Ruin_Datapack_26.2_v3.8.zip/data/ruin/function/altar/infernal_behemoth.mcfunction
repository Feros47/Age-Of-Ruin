execute if score #active_infernal_behemoth ruin_state matches 1 run return 0
execute if entity @e[tag=ruin.boss_infernal_behemoth] run return 0
function ruin:boss/summon_infernal_behemoth
function ruin:altar/consume_one
