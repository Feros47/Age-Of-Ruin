execute if score #active_grave_king ruin_state matches 1 run return 0
execute if entity @e[tag=ruin.boss_grave_king] run return 0
function ruin:boss/summon_grave_king
function ruin:altar/consume_one
