execute if score #active_ancient_colossus ruin_state matches 1 run return 0
execute if entity @e[tag=ruin.boss_ancient_colossus] run return 0
function ruin:boss/summon_ancient_colossus
function ruin:altar/consume_one
