execute if score #active_storm_herald ruin_state matches 1 run return 0
execute if entity @e[tag=ruin.boss_storm_herald] run return 0
function ruin:boss/summon_storm_herald
function ruin:altar/consume_one
