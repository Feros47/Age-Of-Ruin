execute if score #active_warden_king ruin_state matches 1 run return 0
execute if entity @e[tag=ruin.boss_warden_king] run return 0
function ruin:boss/summon_warden_king
function ruin:altar/consume_one
