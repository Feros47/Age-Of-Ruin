execute if score #active_infernal_titan ruin_state matches 1 run return 0
execute if entity @e[tag=ruin.boss_infernal_titan] run return 0
function ruin:boss/summon_infernal_titan
function ruin:altar/consume_one
