execute if score #active_abyss_watcher ruin_state matches 1 run return 0
execute if entity @e[tag=ruin.boss_abyss_watcher] run return 0
function ruin:boss/summon_abyss_watcher
function ruin:altar/consume_one
