execute if score #active_void_emperor ruin_state matches 1 run return 0
execute if entity @e[tag=ruin.boss_void_emperor] run return 0
function ruin:boss/summon_void_emperor
function ruin:altar/consume_one
