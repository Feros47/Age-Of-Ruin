# Waves now fit inside a normal night: ~2 min and ~5 min after Wave I.
execute as @a[tag=ruin.invasion_target,limit=1] at @s run tag @a[distance=..128] add ruin.invasion_participant
execute as @e[tag=ruin.invasion_boss] at @s run tag @a[distance=..128] add ruin.invasion_participant
execute if score #event_wave ruin_state matches 1 if score #event_timer ruin_clock matches 120.. run function ruin:event/invasion_wave2
execute if score #event_wave ruin_state matches 2 if score #event_timer ruin_clock matches 300.. run function ruin:event/invasion_wave3
execute if score #event_wave ruin_state matches 3 unless entity @e[tag=ruin.invasion_boss] run function ruin:event/invasion_reward
