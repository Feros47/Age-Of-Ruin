scoreboard players set #event_wave ruin_state 3
tellraw @a {text:'Wave III - The Dread Marshal has arrived.',color:'dark_red',bold:true}
execute unless entity @a[tag=ruin.invasion_target] run tag @a[predicate=ruin:in_overworld,limit=1,sort=random] add ruin.invasion_target
tag @a[tag=ruin.invasion_target] add ruin.invasion_participant
execute as @a[tag=ruin.invasion_target,limit=1] at @s run function ruin:miniboss/spawn_dread_marshal_invasion
