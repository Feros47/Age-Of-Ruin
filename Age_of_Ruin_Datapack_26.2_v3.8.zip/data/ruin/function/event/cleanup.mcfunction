kill @e[tag=ruin.event_spawn]
kill @e[tag=ruin.invasion]
