scoreboard players set #event_timer ruin_clock 0
tag @a remove ruin.event_target
tag @a[limit=1,sort=random] add ruin.event_target
execute as @a[tag=ruin.event_target,limit=1] at @s run summon minecraft:blaze ~5 ~2 ~ {Tags:["ruin.event_spawn"]}
execute as @a[tag=ruin.event_target,limit=1] at @s run summon minecraft:magma_cube ~-5 ~ ~ {Size:3,Tags:["ruin.event_spawn"]}
execute as @a[tag=ruin.event_target,limit=1] at @s run summon minecraft:piglin_brute ~ ~ ~6 {Tags:["ruin.event_spawn"]}
tag @a remove ruin.event_target
