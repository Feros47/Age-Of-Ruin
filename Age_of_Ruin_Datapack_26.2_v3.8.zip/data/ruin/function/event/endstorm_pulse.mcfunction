scoreboard players set #event_timer ruin_clock 0
tag @a remove ruin.event_target
tag @a[limit=1,sort=random] add ruin.event_target
execute as @a[tag=ruin.event_target,limit=1] at @s run summon minecraft:enderman ~4 ~ ~ {Tags:["ruin.event_spawn"]}
execute as @a[tag=ruin.event_target,limit=1] at @s run summon minecraft:endermite ~-3 ~ ~ {Tags:["ruin.event_spawn"]}
tag @a remove ruin.event_target
