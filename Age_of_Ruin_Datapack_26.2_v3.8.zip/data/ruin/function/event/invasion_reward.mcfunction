scoreboard players set #event_live ruin_state 0
scoreboard players set #event ruin_state 0
scoreboard players set #event_wave ruin_state 0
scoreboard players set #event_timer ruin_clock 0
give @a[tag=ruin.invasion_participant] minecraft:amethyst_shard[custom_data={ruin_item:'soul_shard'},item_name={text:'Soul Shard',color:'aqua',italic:false},item_model='ruin:soul_shard',enchantment_glint_override=true] 16
give @a[tag=ruin.invasion_participant] minecraft:echo_shard[custom_data={ruin_item:'greater_soul'},item_name={text:'Greater Soul',color:'blue',italic:false},item_model='ruin:greater_soul',enchantment_glint_override=true] 4
give @a[tag=ruin.invasion_participant] minecraft:nether_star[custom_data={ruin_item:'ancient_soul'},item_name={text:'Ancient Soul',color:'light_purple',italic:false},item_model='ruin:ancient_soul',enchantment_glint_override=true] 1
tellraw @a[tag=ruin.invasion_participant] [{text:'INVASION REPELLED',color:'gold',bold:true},{text:' - your defense has been rewarded.',color:'gray'}]
tellraw @a[tag=!ruin.invasion_participant] [{text:'INVASION REPELLED',color:'gold',bold:true},{text:' - the defenders prevailed.',color:'gray'}]

execute in minecraft:overworld run function ruin:event/cleanup
execute in minecraft:the_nether run function ruin:event/cleanup
execute in minecraft:the_end run function ruin:event/cleanup
tag @a remove ruin.invasion_target
tag @a remove ruin.invasion_participant
