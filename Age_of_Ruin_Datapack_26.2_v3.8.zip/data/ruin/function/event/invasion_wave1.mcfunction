scoreboard players set #event_wave ruin_state 1
tellraw @a {text:'Wave I - The dead surround the marked survivor.',color:'red'}
execute unless entity @a[tag=ruin.invasion_target] run tag @a[predicate=ruin:in_overworld,limit=1,sort=random] add ruin.invasion_target
tag @a[tag=ruin.invasion_target] add ruin.invasion_participant
execute as @a[tag=ruin.invasion_target,limit=1] at @s run function ruin:event/invasion_wave1_at_target
