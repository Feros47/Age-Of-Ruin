execute if score #event ruin_state matches 1 if score #event_wave ruin_state matches 3 if entity @e[tag=ruin.invasion_boss] run return 0
execute if score #event ruin_state matches 1 if score #event_wave ruin_state matches 3 run function ruin:event/invasion_reward
scoreboard players set #event_live ruin_state 0
scoreboard players set #event ruin_state 0
scoreboard players set #event_timer ruin_clock 0
scoreboard players set #event_wave ruin_state 0
tellraw @a {text:'The world event has ended.',color:'gray'}

execute in minecraft:overworld run function ruin:event/cleanup
execute in minecraft:the_nether run function ruin:event/cleanup
execute in minecraft:the_end run function ruin:event/cleanup
tag @a remove ruin.invasion_target
tag @a remove ruin.invasion_participant
