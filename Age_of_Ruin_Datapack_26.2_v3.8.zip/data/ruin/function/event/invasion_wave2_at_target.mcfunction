summon minecraft:zombie ~6 ~ ~0 {Tags:["ruin.invasion","ruin.invasion_new_elite","ruin.siege"]}
summon minecraft:zombie ~8 ~ ~4 {Tags:["ruin.invasion","ruin.invasion_new_elite","ruin.siege"]}
summon minecraft:zombie ~-6 ~ ~1 {Tags:["ruin.invasion","ruin.invasion_new_elite","ruin.siege"]}
summon minecraft:zombie ~-8 ~ ~-3 {Tags:["ruin.invasion","ruin.invasion_new_elite","ruin.siege"]}
summon minecraft:zombie ~4 ~ ~7 {Tags:["ruin.invasion","ruin.invasion_new_elite","ruin.siege"]}
summon minecraft:zombie ~-4 ~ ~8 {Tags:["ruin.invasion","ruin.invasion_new_elite","ruin.siege"]}
summon minecraft:zombie ~7 ~ ~-6 {Tags:["ruin.invasion","ruin.invasion_new_elite","ruin.siege"]}
summon minecraft:zombie ~-7 ~ ~-7 {Tags:["ruin.invasion","ruin.invasion_new_elite","ruin.siege"]}
summon minecraft:zombie ~ ~ ~10 {Tags:["ruin.invasion","ruin.invasion_new_commander","ruin.siege"],PersistenceRequired:1b}
execute as @e[tag=ruin.invasion_new_elite,distance=..32] at @s run function ruin:mob/scale_v33
execute as @e[tag=ruin.invasion_new_elite,distance=..32] at @s run function ruin:mob/make_elite
execute as @e[tag=ruin.invasion_new_elite,distance=..32] at @s run function ruin:mob/finalize
execute as @e[tag=ruin.invasion_new_commander,distance=..32] at @s run function ruin:mob/scale_v33
execute as @e[tag=ruin.invasion_new_commander,distance=..32] at @s run function ruin:mob/make_elite
execute as @e[tag=ruin.invasion_new_commander,distance=..32] at @s run function ruin:affix/commander
execute as @e[tag=ruin.invasion_new_commander,distance=..32] at @s run function ruin:affix/armored
execute as @e[tag=ruin.invasion_new_commander,distance=..32] at @s run function ruin:mob/finalize
tag @e[tag=ruin.invasion_new_elite,distance=..32] remove ruin.invasion_new_elite
tag @e[tag=ruin.invasion_new_commander,distance=..32] remove ruin.invasion_new_commander
