scoreboard players set #event_timer ruin_clock 0
tag @a remove ruin.event_target
tag @a[limit=1,sort=random] add ruin.event_target
execute as @a[tag=ruin.event_target,limit=1] at @s run summon minecraft:lightning_bolt ~ ~ ~
execute as @a[tag=ruin.event_target,limit=1] at @s run summon minecraft:breeze ~4 ~ ~ {Tags:["ruin.event_spawn","ruin.storm_spawn"]}
execute as @e[tag=ruin.storm_spawn,tag=!ruin.affix_stormborn] run function ruin:affix/stormborn
tag @a remove ruin.event_target
