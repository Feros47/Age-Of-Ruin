execute if score #event ruin_state matches 1 unless entity @a[predicate=ruin:in_overworld] run return 0
scoreboard players set #event_live ruin_state 1
scoreboard players set #event_timer ruin_clock 0
scoreboard players set #event_wave ruin_state 0
execute if score #event ruin_state matches 1 run title @a title {text:'UNDEAD INVASION',color:'red',bold:true}
execute if score #event ruin_state matches 2 run title @a title {text:'THE HUNT',color:'gold',bold:true}
execute if score #event ruin_state matches 3 run title @a title {text:'NETHER INCURSION',color:'red',bold:true}
execute if score #event ruin_state matches 4 run title @a title {text:'BLACK NIGHT',color:'dark_gray',bold:true}
execute if score #event ruin_state matches 5 run title @a title {text:'STORM OF WRATH',color:'aqua',bold:true}
execute if score #event ruin_state matches 6 run title @a title {text:'PLAGUE',color:'green',bold:true}
execute if score #event ruin_state matches 7 run title @a title {text:'ENDSTORM',color:'light_purple',bold:true}
execute if score #event ruin_state matches 8 run title @a title {text:'BOUNTY',color:'gold',bold:true}
execute if score #event ruin_state matches 9 run title @a title {text:'BLESSING',color:'yellow',bold:true}
execute if score #event ruin_state matches 1 run tag @a remove ruin.invasion_target
execute if score #event ruin_state matches 1 run tag @a remove ruin.invasion_participant
execute if score #event ruin_state matches 1 run tag @a[predicate=ruin:in_overworld,limit=1,sort=random] add ruin.invasion_target
execute if score #event ruin_state matches 1 run tag @a[tag=ruin.invasion_target] add ruin.invasion_participant
execute if score #event ruin_state matches 1 run function ruin:event/invasion_wave1
execute if score #event ruin_state matches 5 run weather thunder 1200
