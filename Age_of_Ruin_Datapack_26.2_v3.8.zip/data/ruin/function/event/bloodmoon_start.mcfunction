scoreboard players set #bloodmoon_live ruin_state 1
scoreboard players set #blood_timer ruin_clock 0
execute unless score #sleep_saved ruin_state matches 1 run execute store result storage ruin:runtime sleep_pct int 1 run gamerule players_sleeping_percentage
scoreboard players set #sleep_saved ruin_state 1
gamerule players_sleeping_percentage 101
title @a title {text:'BLOOD MOON',color:'dark_red',bold:true}
title @a subtitle {text:'The night wants you dead.',color:'red'}
playsound minecraft:entity.wither.spawn master @a ~ ~ ~ 0.8 0.6
