scoreboard players set #bloodmoon_live ruin_state 0
scoreboard players set #blood_timer ruin_clock 0
execute if score #sleep_saved ruin_state matches 1 run function ruin:event/restore_sleep with storage ruin:runtime
scoreboard players set #sleep_saved ruin_state 0
tellraw @a [{text:'The Blood Moon recedes.',color:'gray'},{text:' For now.',color:'dark_red'}]
