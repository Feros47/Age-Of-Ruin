scoreboard players set #elite ruin_random 100
scoreboard players set #greater ruin_random 0
scoreboard players set #mini ruin_random 0
scoreboard players set #blood ruin_random 0
execute if score #threat ruin_threat matches 1..9 run function ruin:day/prob/elite_1
execute if score #threat ruin_threat matches 10..24 run function ruin:day/prob/elite_2
execute if score #threat ruin_threat matches 25..49 run function ruin:day/prob/elite_3
execute if score #threat ruin_threat matches 50..74 run function ruin:day/prob/elite_4
execute if score #threat ruin_threat matches 75..99 run function ruin:day/prob/elite_5
execute if score #threat ruin_threat matches 100..149 run function ruin:day/prob/elite_6
execute if score #threat ruin_threat matches 1..9 run function ruin:day/prob/greater_1
execute if score #threat ruin_threat matches 10..24 run function ruin:day/prob/greater_2
execute if score #threat ruin_threat matches 25..49 run function ruin:day/prob/greater_3
execute if score #threat ruin_threat matches 50..74 run function ruin:day/prob/greater_4
execute if score #threat ruin_threat matches 75..99 run function ruin:day/prob/greater_5
execute if score #threat ruin_threat matches 100..149 run function ruin:day/prob/greater_6
execute if score #threat ruin_threat matches 10..24 run function ruin:day/prob/mini_1
execute if score #threat ruin_threat matches 25..49 run function ruin:day/prob/mini_2
execute if score #threat ruin_threat matches 50..74 run function ruin:day/prob/mini_3
execute if score #threat ruin_threat matches 75..99 run function ruin:day/prob/mini_4
execute if score #threat ruin_threat matches 100..149 run function ruin:day/prob/mini_5
execute if score #threat ruin_threat matches 150..199 run function ruin:day/prob/mini_6
execute if score #threat ruin_threat matches 7..24 run function ruin:day/prob/blood_1
execute if score #threat ruin_threat matches 25..49 run function ruin:day/prob/blood_2
execute if score #threat ruin_threat matches 50..74 run function ruin:day/prob/blood_3
execute if score #threat ruin_threat matches 75..99 run function ruin:day/prob/blood_4
execute if score #threat ruin_threat matches 100..149 run function ruin:day/prob/blood_5
execute if score #threat ruin_threat matches 150..199 run function ruin:day/prob/blood_6
execute if score #threat ruin_threat matches 150.. run scoreboard players set #elite ruin_random 3500
execute if score #threat ruin_threat matches 150.. run scoreboard players set #greater ruin_random 1000
execute if score #threat ruin_threat matches 200.. run scoreboard players set #mini ruin_random 300
execute if score #threat ruin_threat matches 200.. run scoreboard players set #blood ruin_random 3000
