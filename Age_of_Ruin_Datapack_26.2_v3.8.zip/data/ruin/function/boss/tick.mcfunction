scoreboard players set #bossclock ruin_clock 0
function ruin:boss/dragon
function ruin:boss/wither
# Encounter anchors follow their boss. They make non-player deaths observable without
# mistaking an unloaded boss for a defeated one.
execute as @e[tag=ruin.boss_grave_king] at @s run tp @e[type=minecraft:marker,tag=ruin.anchor_grave_king,distance=..128,limit=1,sort=nearest] @s
execute as @e[tag=ruin.boss_infernal_behemoth] at @s run tp @e[type=minecraft:marker,tag=ruin.anchor_infernal_behemoth,distance=..128,limit=1,sort=nearest] @s
execute as @e[tag=ruin.boss_abyss_watcher] at @s run tp @e[type=minecraft:marker,tag=ruin.anchor_abyss_watcher,distance=..128,limit=1,sort=nearest] @s
execute as @e[tag=ruin.boss_leviathan] at @s run tp @e[type=minecraft:marker,tag=ruin.anchor_leviathan,distance=..128,limit=1,sort=nearest] @s
execute as @e[tag=ruin.boss_ancient_colossus] at @s run tp @e[type=minecraft:marker,tag=ruin.anchor_ancient_colossus,distance=..128,limit=1,sort=nearest] @s
execute as @e[tag=ruin.boss_lich_king] at @s run tp @e[type=minecraft:marker,tag=ruin.anchor_lich_king,distance=..128,limit=1,sort=nearest] @s
execute as @e[tag=ruin.boss_infernal_titan] at @s run tp @e[type=minecraft:marker,tag=ruin.anchor_infernal_titan,distance=..128,limit=1,sort=nearest] @s
execute as @e[tag=ruin.boss_warden_king] at @s run tp @e[type=minecraft:marker,tag=ruin.anchor_warden_king,distance=..128,limit=1,sort=nearest] @s
execute as @e[tag=ruin.boss_storm_herald] at @s run tp @e[type=minecraft:marker,tag=ruin.anchor_storm_herald,distance=..128,limit=1,sort=nearest] @s
execute as @e[tag=ruin.boss_void_emperor] at @s run tp @e[type=minecraft:marker,tag=ruin.anchor_void_emperor,distance=..128,limit=1,sort=nearest] @s
# Track nearby participants while each custom encounter is alive.
execute as @e[tag=ruin.boss_grave_king] at @s run tag @a[distance=..128] add ruin.part_grave_king
execute as @e[tag=ruin.boss_infernal_behemoth] at @s run tag @a[distance=..128] add ruin.part_infernal_behemoth
execute as @e[tag=ruin.boss_abyss_watcher] at @s run tag @a[distance=..128] add ruin.part_abyss_watcher
execute as @e[tag=ruin.boss_leviathan] at @s run tag @a[distance=..128] add ruin.part_leviathan
execute as @e[tag=ruin.boss_ancient_colossus] at @s run tag @a[distance=..128] add ruin.part_ancient_colossus
execute as @e[tag=ruin.boss_lich_king] at @s run tag @a[distance=..128] add ruin.part_lich_king
execute as @e[tag=ruin.boss_infernal_titan] at @s run tag @a[distance=..128] add ruin.part_infernal_titan
execute as @e[tag=ruin.boss_warden_king] at @s run tag @a[distance=..128] add ruin.part_warden_king
execute as @e[tag=ruin.boss_storm_herald] at @s run tag @a[distance=..128] add ruin.part_storm_herald
execute as @e[tag=ruin.boss_void_emperor] at @s run tag @a[distance=..128] add ruin.part_void_emperor
execute if score #active_grave_king ruin_state matches 1 run bossbar set ruin:grave_king players @a[tag=ruin.part_grave_king]
execute if score #active_infernal_behemoth ruin_state matches 1 run bossbar set ruin:infernal_behemoth players @a[tag=ruin.part_infernal_behemoth]
execute if score #active_abyss_watcher ruin_state matches 1 run bossbar set ruin:abyss_watcher players @a[tag=ruin.part_abyss_watcher]
execute if score #active_leviathan ruin_state matches 1 run bossbar set ruin:leviathan players @a[tag=ruin.part_leviathan]
execute if score #active_ancient_colossus ruin_state matches 1 run bossbar set ruin:ancient_colossus players @a[tag=ruin.part_ancient_colossus]
execute if score #active_lich_king ruin_state matches 1 run bossbar set ruin:lich_king players @a[tag=ruin.part_lich_king]
execute if score #active_infernal_titan ruin_state matches 1 run bossbar set ruin:infernal_titan players @a[tag=ruin.part_infernal_titan]
execute if score #active_warden_king ruin_state matches 1 run bossbar set ruin:warden_king players @a[tag=ruin.part_warden_king]
execute if score #active_storm_herald ruin_state matches 1 run bossbar set ruin:storm_herald players @a[tag=ruin.part_storm_herald]
execute if score #active_void_emperor ruin_state matches 1 run bossbar set ruin:void_emperor players @a[tag=ruin.part_void_emperor]
execute as @e[tag=ruin.boss_grave_king,limit=1] store result score @s ruin_hpcur run data get entity @s Health 1
execute as @e[tag=ruin.boss_grave_king,limit=1] store result score @s ruin_tmp run data get entity @s AbsorptionAmount 1
execute as @e[tag=ruin.boss_grave_king,limit=1] run scoreboard players operation @s ruin_hpcur += @s ruin_tmp
execute if entity @e[tag=ruin.boss_grave_king] store result bossbar ruin:grave_king value run scoreboard players get @e[tag=ruin.boss_grave_king,limit=1] ruin_hpcur
execute as @e[tag=ruin.boss_grave_king] run scoreboard players add @s ruin_boss_timer 1
execute as @e[tag=ruin.boss_grave_king,scores={ruin_boss_timer=5..}] at @s run function ruin:boss/pulse_grave_king
execute as @e[tag=ruin.boss_infernal_behemoth,limit=1] store result score @s ruin_hpcur run data get entity @s Health 1
execute as @e[tag=ruin.boss_infernal_behemoth,limit=1] store result score @s ruin_tmp run data get entity @s AbsorptionAmount 1
execute as @e[tag=ruin.boss_infernal_behemoth,limit=1] run scoreboard players operation @s ruin_hpcur += @s ruin_tmp
execute if entity @e[tag=ruin.boss_infernal_behemoth] store result bossbar ruin:infernal_behemoth value run scoreboard players get @e[tag=ruin.boss_infernal_behemoth,limit=1] ruin_hpcur
execute as @e[tag=ruin.boss_infernal_behemoth] run scoreboard players add @s ruin_boss_timer 1
execute as @e[tag=ruin.boss_infernal_behemoth,scores={ruin_boss_timer=5..}] at @s run function ruin:boss/pulse_infernal_behemoth
execute as @e[tag=ruin.boss_abyss_watcher,limit=1] store result score @s ruin_hpcur run data get entity @s Health 1
execute as @e[tag=ruin.boss_abyss_watcher,limit=1] store result score @s ruin_tmp run data get entity @s AbsorptionAmount 1
execute as @e[tag=ruin.boss_abyss_watcher,limit=1] run scoreboard players operation @s ruin_hpcur += @s ruin_tmp
execute if entity @e[tag=ruin.boss_abyss_watcher] store result bossbar ruin:abyss_watcher value run scoreboard players get @e[tag=ruin.boss_abyss_watcher,limit=1] ruin_hpcur
execute as @e[tag=ruin.boss_abyss_watcher] run scoreboard players add @s ruin_boss_timer 1
execute as @e[tag=ruin.boss_abyss_watcher,scores={ruin_boss_timer=5..}] at @s run function ruin:boss/pulse_abyss_watcher
execute as @e[tag=ruin.boss_leviathan,limit=1] store result score @s ruin_hpcur run data get entity @s Health 1
execute as @e[tag=ruin.boss_leviathan,limit=1] store result score @s ruin_tmp run data get entity @s AbsorptionAmount 1
execute as @e[tag=ruin.boss_leviathan,limit=1] run scoreboard players operation @s ruin_hpcur += @s ruin_tmp
execute if entity @e[tag=ruin.boss_leviathan] store result bossbar ruin:leviathan value run scoreboard players get @e[tag=ruin.boss_leviathan,limit=1] ruin_hpcur
execute as @e[tag=ruin.boss_leviathan] run scoreboard players add @s ruin_boss_timer 1
execute as @e[tag=ruin.boss_leviathan,scores={ruin_boss_timer=6..}] at @s run function ruin:boss/pulse_leviathan
execute as @e[tag=ruin.boss_ancient_colossus,limit=1] store result score @s ruin_hpcur run data get entity @s Health 1
execute as @e[tag=ruin.boss_ancient_colossus,limit=1] store result score @s ruin_tmp run data get entity @s AbsorptionAmount 1
execute as @e[tag=ruin.boss_ancient_colossus,limit=1] run scoreboard players operation @s ruin_hpcur += @s ruin_tmp
execute if entity @e[tag=ruin.boss_ancient_colossus] store result bossbar ruin:ancient_colossus value run scoreboard players get @e[tag=ruin.boss_ancient_colossus,limit=1] ruin_hpcur
execute as @e[tag=ruin.boss_ancient_colossus] run scoreboard players add @s ruin_boss_timer 1
execute as @e[tag=ruin.boss_ancient_colossus] at @s if entity @e[tag=ruin.colossus_node,distance=..24] run effect give @s minecraft:resistance 2 4 true
execute as @e[tag=ruin.boss_ancient_colossus,tag=!ruin.nodes_down] at @s unless entity @e[tag=ruin.colossus_node,distance=..24] run function ruin:boss/colossus_nodes_down
execute as @e[tag=ruin.boss_ancient_colossus,scores={ruin_boss_timer=5..}] at @s run function ruin:boss/pulse_ancient_colossus
execute as @e[tag=ruin.boss_lich_king,limit=1] store result score @s ruin_hpcur run data get entity @s Health 1
execute as @e[tag=ruin.boss_lich_king,limit=1] store result score @s ruin_tmp run data get entity @s AbsorptionAmount 1
execute as @e[tag=ruin.boss_lich_king,limit=1] run scoreboard players operation @s ruin_hpcur += @s ruin_tmp
execute if entity @e[tag=ruin.boss_lich_king] store result bossbar ruin:lich_king value run scoreboard players get @e[tag=ruin.boss_lich_king,limit=1] ruin_hpcur
execute as @e[tag=ruin.boss_lich_king] run scoreboard players add @s ruin_boss_timer 1
execute as @e[tag=ruin.boss_lich_king] at @s if entity @e[tag=ruin.lich_phylactery,distance=..24] run effect give @s minecraft:resistance 2 4 true
execute as @e[tag=ruin.boss_lich_king,tag=!ruin.phylacteries_down] at @s unless entity @e[tag=ruin.lich_phylactery,distance=..24] run function ruin:boss/lich_phylacteries_down
execute as @e[tag=ruin.boss_lich_king] at @s run function ruin:boss/lich_phase
execute as @e[tag=ruin.boss_lich_king,scores={ruin_boss_timer=5..}] at @s run function ruin:boss/pulse_lich_king
execute as @e[tag=ruin.boss_infernal_titan,limit=1] store result score @s ruin_hpcur run data get entity @s Health 1
execute as @e[tag=ruin.boss_infernal_titan,limit=1] store result score @s ruin_tmp run data get entity @s AbsorptionAmount 1
execute as @e[tag=ruin.boss_infernal_titan,limit=1] run scoreboard players operation @s ruin_hpcur += @s ruin_tmp
execute if entity @e[tag=ruin.boss_infernal_titan] store result bossbar ruin:infernal_titan value run scoreboard players get @e[tag=ruin.boss_infernal_titan,limit=1] ruin_hpcur
execute as @e[tag=ruin.boss_infernal_titan] run scoreboard players add @s ruin_boss_timer 1
execute as @e[tag=ruin.boss_infernal_titan,scores={ruin_boss_timer=4..}] at @s run function ruin:boss/pulse_infernal_titan
execute as @e[tag=ruin.boss_warden_king,limit=1] store result score @s ruin_hpcur run data get entity @s Health 1
execute as @e[tag=ruin.boss_warden_king,limit=1] store result score @s ruin_tmp run data get entity @s AbsorptionAmount 1
execute as @e[tag=ruin.boss_warden_king,limit=1] run scoreboard players operation @s ruin_hpcur += @s ruin_tmp
execute if entity @e[tag=ruin.boss_warden_king] store result bossbar ruin:warden_king value run scoreboard players get @e[tag=ruin.boss_warden_king,limit=1] ruin_hpcur
execute as @e[tag=ruin.boss_warden_king] run scoreboard players add @s ruin_boss_timer 1
execute as @e[tag=ruin.boss_warden_king,scores={ruin_boss_timer=4..}] at @s run function ruin:boss/pulse_warden_king
execute as @e[tag=ruin.boss_storm_herald,limit=1] store result score @s ruin_hpcur run data get entity @s Health 1
execute as @e[tag=ruin.boss_storm_herald,limit=1] store result score @s ruin_tmp run data get entity @s AbsorptionAmount 1
execute as @e[tag=ruin.boss_storm_herald,limit=1] run scoreboard players operation @s ruin_hpcur += @s ruin_tmp
execute if entity @e[tag=ruin.boss_storm_herald] store result bossbar ruin:storm_herald value run scoreboard players get @e[tag=ruin.boss_storm_herald,limit=1] ruin_hpcur
execute as @e[tag=ruin.boss_storm_herald] run scoreboard players add @s ruin_boss_timer 1
execute as @e[tag=ruin.boss_storm_herald,scores={ruin_boss_timer=4..}] at @s run function ruin:boss/pulse_storm_herald
execute as @e[tag=ruin.boss_void_emperor,limit=1] store result score @s ruin_hpcur run data get entity @s Health 1
execute as @e[tag=ruin.boss_void_emperor,limit=1] store result score @s ruin_tmp run data get entity @s AbsorptionAmount 1
execute as @e[tag=ruin.boss_void_emperor,limit=1] run scoreboard players operation @s ruin_hpcur += @s ruin_tmp
execute if entity @e[tag=ruin.boss_void_emperor] store result bossbar ruin:void_emperor value run scoreboard players get @e[tag=ruin.boss_void_emperor,limit=1] ruin_hpcur
execute as @e[tag=ruin.boss_void_emperor] run scoreboard players add @s ruin_boss_timer 1
execute as @e[tag=ruin.boss_void_emperor,scores={ruin_boss_timer=4..}] at @s run function ruin:boss/pulse_void_emperor
