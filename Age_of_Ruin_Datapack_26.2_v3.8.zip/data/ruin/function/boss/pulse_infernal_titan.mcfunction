scoreboard players set @s ruin_boss_timer 0
summon minecraft:blaze ~4 ~3 ~ {Tags:["ruin.initialized"]}
summon minecraft:magma_cube ~-4 ~ ~ {Size:4,Tags:["ruin.initialized"]}
particle minecraft:explosion ~ ~1 ~ 0 0 0 0 1 force
execute as @a[distance=..8] run damage @s 20 minecraft:explosion
execute as @a[distance=..6] run damage @s 10 minecraft:on_fire
