scoreboard players set @s ruin_boss_timer 0
effect give @a[distance=..24] minecraft:mining_fatigue 6 2 true
effect give @a[distance=..24] minecraft:slowness 5 1 true
summon minecraft:guardian ~5 ~ ~ {Tags:["ruin.initialized"]}
summon minecraft:drowned ~-5 ~ ~ {Tags:["ruin.initialized"]}
execute as @a[distance=..5] run damage @s 12 minecraft:indirect_magic
