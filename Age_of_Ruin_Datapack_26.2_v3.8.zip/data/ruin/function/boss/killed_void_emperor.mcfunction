advancement revoke @s only ruin:kill_boss_void_emperor
function ruin:boss/defeated_void_emperor
