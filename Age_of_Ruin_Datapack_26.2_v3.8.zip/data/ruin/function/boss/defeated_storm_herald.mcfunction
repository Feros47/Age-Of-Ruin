scoreboard players set #active_storm_herald ruin_state 0
kill @e[type=minecraft:marker,tag=ruin.anchor_storm_herald]
bossbar remove ruin:storm_herald
scoreboard players set #boss_first ruin_state 0
execute unless score #defeated_storm_herald ruin_state matches 1 run scoreboard players set #boss_first ruin_state 1
execute if score #boss_first ruin_state matches 1 run scoreboard players add #corruption ruin_corrupt 5
scoreboard players set #defeated_storm_herald ruin_state 1
function ruin:day/recalculate
give @a[tag=ruin.part_storm_herald] minecraft:heart_of_the_sea[custom_data={ruin_item:'storm_core'},item_name={text:'Storm Core',color:'aqua',italic:false},item_model='ruin:storm_core',enchantment_glint_override=true] 1
give @a[tag=ruin.part_storm_herald] minecraft:mace[custom_data={ruin_relic:'stormbreaker'},item_name={text:'Stormbreaker',color:'aqua',italic:false},item_model='ruin:stormbreaker',enchantments={density:8,breach:5,unbreaking:8}] 1
execute if score #boss_first ruin_state matches 1 run tellraw @a [{text:'THE STORM HERALD DEFEATED',color:'gold',bold:true},{text:'  |  World Threat +5',color:'red'}]
execute unless score #boss_first ruin_state matches 1 run tellraw @a {text:'THE STORM HERALD DEFEATED AGAIN',color:'gold',bold:true}

tag @a remove ruin.part_storm_herald
