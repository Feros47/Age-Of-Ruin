scoreboard players set #active_infernal_behemoth ruin_state 0
kill @e[type=minecraft:marker,tag=ruin.anchor_infernal_behemoth]
bossbar remove ruin:infernal_behemoth
scoreboard players set #boss_first ruin_state 0
execute unless score #defeated_infernal_behemoth ruin_state matches 1 run scoreboard players set #boss_first ruin_state 1
execute if score #boss_first ruin_state matches 1 run scoreboard players add #corruption ruin_corrupt 5
scoreboard players set #defeated_infernal_behemoth ruin_state 1
function ruin:day/recalculate
give @a[tag=ruin.part_infernal_behemoth] minecraft:blaze_powder[custom_data={ruin_item:'infernal_heart'},item_name={text:'Infernal Heart',color:'gold',italic:false},item_model='ruin:infernal_heart',enchantment_glint_override=true] 1
execute if score #boss_first ruin_state matches 1 run tellraw @a [{text:'THE INFERNAL BEHEMOTH DEFEATED',color:'gold',bold:true},{text:'  |  World Threat +5',color:'red'}]
execute unless score #boss_first ruin_state matches 1 run tellraw @a {text:'THE INFERNAL BEHEMOTH DEFEATED AGAIN',color:'gold',bold:true}

tag @a remove ruin.part_infernal_behemoth
