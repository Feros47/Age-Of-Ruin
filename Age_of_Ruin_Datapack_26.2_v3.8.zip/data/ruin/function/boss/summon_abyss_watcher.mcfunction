execute if score #active_abyss_watcher ruin_state matches 1 run return 0
tag @a remove ruin.part_abyss_watcher
summon minecraft:warden ~ ~2 ~ {Tags:["ruin.initialized","ruin.boss","ruin.boss_abyss_watcher","ruin.current_boss","ruin.siege"],CustomName:{text:'THE ABYSS WATCHER',color:'dark_aqua',bold:true},CustomNameVisible:1b,PersistenceRequired:1b,CanPickUpLoot:0b}
summon minecraft:marker ~ ~2 ~ {Tags:["ruin.boss_anchor","ruin.anchor_abyss_watcher"]}
execute as @e[tag=ruin.boss_abyss_watcher,limit=1,sort=nearest] at @s run tag @a[distance=..128] add ruin.part_abyss_watcher
execute as @e[tag=ruin.boss_abyss_watcher,limit=1,sort=nearest] at @s run function ruin:boss/scale_abyss_watcher
execute as @e[tag=ruin.boss_abyss_watcher,limit=1,sort=nearest] run item replace entity @s weapon.offhand with minecraft:echo_shard[custom_data={ruin_item:'abyssal_essence'},item_name={text:'Abyssal Essence',color:'dark_aqua',italic:false},item_model='ruin:abyssal_essence',enchantment_glint_override=true] 1
execute as @e[tag=ruin.boss_abyss_watcher,limit=1,sort=nearest] run data merge entity @s {drop_chances:{offhand:1.0f}}
execute as @e[tag=ruin.boss_abyss_watcher,limit=1,sort=nearest] run function ruin:affix/phasewalker
execute as @e[tag=ruin.boss_abyss_watcher,limit=1,sort=nearest] run function ruin:affix/hexed
execute as @e[tag=ruin.boss_abyss_watcher,limit=1,sort=nearest] run function ruin:affix/armored
execute as @e[tag=ruin.boss_abyss_watcher,limit=1,sort=nearest] run function ruin:boss/finalize_pool
scoreboard players set #active_abyss_watcher ruin_state 1
bossbar remove ruin:abyss_watcher
bossbar add ruin:abyss_watcher {text:'THE ABYSS WATCHER',color:'dark_aqua',bold:true}
execute store result bossbar ruin:abyss_watcher max run scoreboard players get @e[tag=ruin.boss_abyss_watcher,limit=1,sort=nearest] ruin_basehp
bossbar set ruin:abyss_watcher players @a[tag=ruin.part_abyss_watcher]
title @a title {text:'THE ABYSS WATCHER',color:'dark_aqua',bold:true}
playsound minecraft:entity.wither.spawn master @a ~ ~ ~ 0.9 0.7
execute as @e[tag=ruin.current_boss] run tag @s remove ruin.current_boss
