scoreboard players set #active_warden_king ruin_state 0
kill @e[type=minecraft:marker,tag=ruin.anchor_warden_king]
bossbar remove ruin:warden_king
scoreboard players set #boss_first ruin_state 0
execute unless score #defeated_warden_king ruin_state matches 1 run scoreboard players set #boss_first ruin_state 1
execute if score #boss_first ruin_state matches 1 run scoreboard players add #corruption ruin_corrupt 5
scoreboard players set #defeated_warden_king ruin_state 1
function ruin:day/recalculate
give @a[tag=ruin.part_warden_king] minecraft:echo_shard[custom_data={ruin_item:'warden_crown'},item_name={text:'Warden Crown',color:'dark_aqua',italic:false},item_model='ruin:warden_crown',enchantment_glint_override=true] 1
execute if score #boss_first ruin_state matches 1 run tellraw @a [{text:'THE WARDEN KING DEFEATED',color:'gold',bold:true},{text:'  |  World Threat +5',color:'red'}]
execute unless score #boss_first ruin_state matches 1 run tellraw @a {text:'THE WARDEN KING DEFEATED AGAIN',color:'gold',bold:true}

tag @a remove ruin.part_warden_king
