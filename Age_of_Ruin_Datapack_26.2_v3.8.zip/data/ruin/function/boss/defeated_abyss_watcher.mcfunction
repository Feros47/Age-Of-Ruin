scoreboard players set #active_abyss_watcher ruin_state 0
kill @e[type=minecraft:marker,tag=ruin.anchor_abyss_watcher]
bossbar remove ruin:abyss_watcher
scoreboard players set #boss_first ruin_state 0
execute unless score #defeated_abyss_watcher ruin_state matches 1 run scoreboard players set #boss_first ruin_state 1
execute if score #boss_first ruin_state matches 1 run scoreboard players add #corruption ruin_corrupt 5
scoreboard players set #defeated_abyss_watcher ruin_state 1
function ruin:day/recalculate
give @a[tag=ruin.part_abyss_watcher] minecraft:echo_shard[custom_data={ruin_item:'abyssal_essence'},item_name={text:'Abyssal Essence',color:'dark_aqua',italic:false},item_model='ruin:abyssal_essence',enchantment_glint_override=true] 1
execute if score #boss_first ruin_state matches 1 run tellraw @a [{text:'THE ABYSS WATCHER DEFEATED',color:'gold',bold:true},{text:'  |  World Threat +5',color:'red'}]
execute unless score #boss_first ruin_state matches 1 run tellraw @a {text:'THE ABYSS WATCHER DEFEATED AGAIN',color:'gold',bold:true}

tag @a remove ruin.part_abyss_watcher
