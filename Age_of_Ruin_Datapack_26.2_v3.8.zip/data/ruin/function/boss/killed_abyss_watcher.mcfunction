advancement revoke @s only ruin:kill_boss_abyss_watcher
function ruin:boss/defeated_abyss_watcher
