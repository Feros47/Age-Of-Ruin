# Dragon completion is checked only while players remain in the End, avoiding false
# completion when the whole dimension unloads. Other boss deaths use kill advancements.
execute if entity @a[predicate=ruin:in_end] if score #dragon_active ruin_state matches 1 if score #alive_dragon ruin_state matches 0 run function ruin:boss/dragon_defeated
execute if score #wither_active ruin_state matches 1 if score #alive_wither ruin_state matches 0 if score #wither_dim ruin_state matches 0 if entity @a[predicate=ruin:in_overworld] run function ruin:boss/wither_defeated
execute if score #wither_active ruin_state matches 1 if score #alive_wither ruin_state matches 0 if score #wither_dim ruin_state matches 1 if entity @a[predicate=ruin:in_nether] run function ruin:boss/wither_defeated
execute if score #wither_active ruin_state matches 1 if score #alive_wither ruin_state matches 0 if score #wither_dim ruin_state matches 2 if entity @a[predicate=ruin:in_end] run function ruin:boss/wither_defeated
