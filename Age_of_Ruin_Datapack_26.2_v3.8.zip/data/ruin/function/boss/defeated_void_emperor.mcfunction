scoreboard players set #active_void_emperor ruin_state 0
kill @e[type=minecraft:marker,tag=ruin.anchor_void_emperor]
bossbar remove ruin:void_emperor
scoreboard players set #boss_first ruin_state 0
execute unless score #defeated_void_emperor ruin_state matches 1 run scoreboard players set #boss_first ruin_state 1
execute if score #boss_first ruin_state matches 1 run scoreboard players add #corruption ruin_corrupt 5
scoreboard players set #defeated_void_emperor ruin_state 1
function ruin:day/recalculate
give @a[tag=ruin.part_void_emperor] minecraft:bow[custom_data={ruin_relic:'voidpiercer'},item_name={text:'Voidpiercer',color:'light_purple',italic:false},item_model='ruin:voidpiercer',enchantments={power:18,punch:4,infinity:1,unbreaking:10}] 1
execute if score #boss_first ruin_state matches 1 run tellraw @a [{text:'THE VOID EMPEROR DEFEATED',color:'gold',bold:true},{text:'  |  World Threat +5',color:'red'}]
execute unless score #boss_first ruin_state matches 1 run tellraw @a {text:'THE VOID EMPEROR DEFEATED AGAIN',color:'gold',bold:true}

tag @a remove ruin.part_void_emperor
