advancement revoke @s only ruin:kill_boss_warden_king
function ruin:boss/defeated_warden_king
