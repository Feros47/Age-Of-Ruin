# The anchor is loaded only with the encounter. This detects environmental deaths
# while avoiding false completion when an entire boss chunk/dimension unloads.
execute if score #active_grave_king ruin_state matches 1 if entity @e[type=minecraft:marker,tag=ruin.anchor_grave_king] unless entity @e[tag=ruin.boss_grave_king] run function ruin:boss/defeated_grave_king
execute if score #active_infernal_behemoth ruin_state matches 1 if entity @e[type=minecraft:marker,tag=ruin.anchor_infernal_behemoth] unless entity @e[tag=ruin.boss_infernal_behemoth] run function ruin:boss/defeated_infernal_behemoth
execute if score #active_abyss_watcher ruin_state matches 1 if entity @e[type=minecraft:marker,tag=ruin.anchor_abyss_watcher] unless entity @e[tag=ruin.boss_abyss_watcher] run function ruin:boss/defeated_abyss_watcher
execute if score #active_leviathan ruin_state matches 1 if entity @e[type=minecraft:marker,tag=ruin.anchor_leviathan] unless entity @e[tag=ruin.boss_leviathan] run function ruin:boss/defeated_leviathan
execute if score #active_ancient_colossus ruin_state matches 1 if entity @e[type=minecraft:marker,tag=ruin.anchor_ancient_colossus] unless entity @e[tag=ruin.boss_ancient_colossus] run function ruin:boss/defeated_ancient_colossus
execute if score #active_lich_king ruin_state matches 1 if entity @e[type=minecraft:marker,tag=ruin.anchor_lich_king] unless entity @e[tag=ruin.boss_lich_king] run function ruin:boss/defeated_lich_king
execute if score #active_infernal_titan ruin_state matches 1 if entity @e[type=minecraft:marker,tag=ruin.anchor_infernal_titan] unless entity @e[tag=ruin.boss_infernal_titan] run function ruin:boss/defeated_infernal_titan
execute if score #active_warden_king ruin_state matches 1 if entity @e[type=minecraft:marker,tag=ruin.anchor_warden_king] unless entity @e[tag=ruin.boss_warden_king] run function ruin:boss/defeated_warden_king
execute if score #active_storm_herald ruin_state matches 1 if entity @e[type=minecraft:marker,tag=ruin.anchor_storm_herald] unless entity @e[tag=ruin.boss_storm_herald] run function ruin:boss/defeated_storm_herald
execute if score #active_void_emperor ruin_state matches 1 if entity @e[type=minecraft:marker,tag=ruin.anchor_void_emperor] unless entity @e[tag=ruin.boss_void_emperor] run function ruin:boss/defeated_void_emperor
