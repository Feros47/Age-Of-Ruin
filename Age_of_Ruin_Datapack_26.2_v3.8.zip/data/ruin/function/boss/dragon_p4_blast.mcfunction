execute in minecraft:the_end as @e[type=minecraft:ender_dragon,tag=ruin.dragon] at @s run particle minecraft:explosion_emitter ~ ~ ~ 0 0 0 0 1 force
execute in minecraft:the_end as @e[type=minecraft:ender_dragon,tag=ruin.dragon] at @s run execute as @a[tag=ruin.part_dragon,distance=..160] run damage @s 22 minecraft:dragon_breath
