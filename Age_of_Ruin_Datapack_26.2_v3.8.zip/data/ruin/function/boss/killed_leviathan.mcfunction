advancement revoke @s only ruin:kill_boss_leviathan
function ruin:boss/defeated_leviathan
