execute store result score @s ruin_hpcur run data get entity @s Health 100
scoreboard players operation @s ruin_pct = @s ruin_hpcur
scoreboard players set #hundred ruin_tmp 100
scoreboard players operation @s ruin_pct *= #hundred ruin_tmp
scoreboard players operation @s ruin_pct /= @s ruin_maxhp
execute if score @s ruin_pct matches ..66 if entity @s[tag=!ruin.lich_p2] run function ruin:boss/lich_enter_p2
execute if score @s ruin_pct matches ..33 if entity @s[tag=!ruin.lich_p3] run function ruin:boss/lich_enter_p3
