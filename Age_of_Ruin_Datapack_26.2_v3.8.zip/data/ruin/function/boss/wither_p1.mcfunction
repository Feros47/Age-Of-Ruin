scoreboard players set @s ruin_boss_timer 0
summon minecraft:wither_skeleton ~3 ~ ~ {Tags:["ruin.initialized","ruin.siege"]}
summon minecraft:wither_skeleton ~-3 ~ ~ {Tags:["ruin.initialized","ruin.siege"]}
execute as @a[distance=..96] run damage @s 10 minecraft:wither
