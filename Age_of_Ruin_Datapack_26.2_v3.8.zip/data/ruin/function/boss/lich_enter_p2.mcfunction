tag @s add ruin.lich_p2
title @a[tag=ruin.part_lich_king] title {text:'THE DEAD ANSWER',color:'dark_purple',bold:true}
summon minecraft:wither_skeleton ~4 ~ ~ {Tags:["ruin.initialized","ruin.lich_add"]}
summon minecraft:wither_skeleton ~-4 ~ ~ {Tags:["ruin.initialized","ruin.lich_add"]}
summon minecraft:bogged ~ ~ ~4 {Tags:["ruin.initialized","ruin.lich_add"]}
summon minecraft:bogged ~ ~ ~-4 {Tags:["ruin.initialized","ruin.lich_add"]}
