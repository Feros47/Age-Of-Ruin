advancement revoke @s only ruin:kill_boss_infernal_behemoth
function ruin:boss/defeated_infernal_behemoth
