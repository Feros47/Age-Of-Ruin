scoreboard players set @s ruin_boss_timer 0
summon minecraft:wither_skeleton ~4 ~ ~ {Tags:["ruin.initialized","ruin.siege"]}
summon minecraft:wither_skeleton ~-4 ~ ~ {Tags:["ruin.initialized","ruin.siege"]}
effect give @a[distance=..96] minecraft:wither 5 2 true
execute as @a[distance=..96] run damage @s 14 minecraft:explosion
