scoreboard players set #active_leviathan ruin_state 0
kill @e[type=minecraft:marker,tag=ruin.anchor_leviathan]
bossbar remove ruin:leviathan
scoreboard players set #boss_first ruin_state 0
execute unless score #defeated_leviathan ruin_state matches 1 run scoreboard players set #boss_first ruin_state 1
execute if score #boss_first ruin_state matches 1 run scoreboard players add #corruption ruin_corrupt 5
scoreboard players set #defeated_leviathan ruin_state 1
function ruin:day/recalculate
give @a[tag=ruin.part_leviathan] minecraft:netherite_chestplate[custom_data={ruin_relic:'leviathan_plate'},item_name={text:'Leviathan Plate',color:'aqua',italic:false},item_model='ruin:leviathan_plate',enchantments={protection:12,respiration:10,unbreaking:10}] 1
execute if score #boss_first ruin_state matches 1 run tellraw @a [{text:'THE LEVIATHAN DEFEATED',color:'gold',bold:true},{text:'  |  World Threat +5',color:'red'}]
execute unless score #boss_first ruin_state matches 1 run tellraw @a {text:'THE LEVIATHAN DEFEATED AGAIN',color:'gold',bold:true}

tag @a remove ruin.part_leviathan
