scoreboard players set #active_infernal_titan ruin_state 0
kill @e[type=minecraft:marker,tag=ruin.anchor_infernal_titan]
bossbar remove ruin:infernal_titan
scoreboard players set #boss_first ruin_state 0
execute unless score #defeated_infernal_titan ruin_state matches 1 run scoreboard players set #boss_first ruin_state 1
execute if score #boss_first ruin_state matches 1 run scoreboard players add #corruption ruin_corrupt 5
scoreboard players set #defeated_infernal_titan ruin_state 1
function ruin:day/recalculate
give @a[tag=ruin.part_infernal_titan] minecraft:netherite_chestplate[custom_data={ruin_relic:'phoenix_plate'},item_name={text:'Phoenix Plate',color:'gold',italic:false},item_model='ruin:phoenix_plate',enchantments={protection:12,unbreaking:10,'ruin:fortification':3}] 1
execute if score #boss_first ruin_state matches 1 run tellraw @a [{text:'THE INFERNAL TITAN DEFEATED',color:'gold',bold:true},{text:'  |  World Threat +5',color:'red'}]
execute unless score #boss_first ruin_state matches 1 run tellraw @a {text:'THE INFERNAL TITAN DEFEATED AGAIN',color:'gold',bold:true}

tag @a remove ruin.part_infernal_titan
