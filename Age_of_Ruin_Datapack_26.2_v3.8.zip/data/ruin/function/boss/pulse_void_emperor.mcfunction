scoreboard players set @s ruin_boss_timer 0
effect give @a[distance=..32] minecraft:darkness 5 0 true
summon minecraft:shulker ~5 ~ ~ {Tags:["ruin.initialized"]}
summon minecraft:endermite ~-4 ~ ~ {Tags:["ruin.initialized"]}
execute if entity @p[distance=5..30] run tp @s ^5 ^ ^-3 facing entity @p eyes
execute as @a[distance=..6] run damage @s 18 minecraft:magic
