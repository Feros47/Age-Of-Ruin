scoreboard players set @s ruin_boss_timer 0
effect give @a[distance=..160] minecraft:darkness 2 0 true
title @a[tag=ruin.part_dragon] actionbar {text:'The World Eater inhales — MOVE!',color:'red',bold:true}
playsound minecraft:entity.ender_dragon.growl hostile @a[tag=ruin.part_dragon] ~ ~ ~ 1 0.55
particle minecraft:dragon_breath ~ ~ ~ 8 4 8 0.12 120 force
schedule function ruin:boss/dragon_p4_blast 2s replace
