advancement revoke @s only ruin:wither_kill
tag @s add ruin.part_wither
function ruin:boss/wither_defeated
