scoreboard players add @e[type=minecraft:marker,tag=ruin.dragon_void_zone] ruin_timer 1
execute as @e[type=minecraft:marker,tag=ruin.dragon_void_zone] at @s run particle minecraft:dragon_breath ~ ~0.2 ~ 3 0.2 3 0.04 30 force
execute as @e[type=minecraft:marker,tag=ruin.dragon_void_zone] at @s run effect give @a[distance=..4] minecraft:wither 2 2 true
execute as @e[type=minecraft:marker,tag=ruin.dragon_void_zone] at @s run effect give @a[distance=..4] minecraft:slowness 2 1 true
kill @e[type=minecraft:marker,tag=ruin.dragon_void_zone,scores={ruin_timer=8..}]
