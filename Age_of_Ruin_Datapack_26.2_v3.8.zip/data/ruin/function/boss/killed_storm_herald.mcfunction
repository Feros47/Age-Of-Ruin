advancement revoke @s only ruin:kill_boss_storm_herald
function ruin:boss/defeated_storm_herald
