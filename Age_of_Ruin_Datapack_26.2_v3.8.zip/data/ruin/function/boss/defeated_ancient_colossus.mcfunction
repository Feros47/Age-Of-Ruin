scoreboard players set #active_ancient_colossus ruin_state 0
kill @e[type=minecraft:marker,tag=ruin.anchor_ancient_colossus]
bossbar remove ruin:ancient_colossus
scoreboard players set #boss_first ruin_state 0
execute unless score #defeated_ancient_colossus ruin_state matches 1 run scoreboard players set #boss_first ruin_state 1
execute if score #boss_first ruin_state matches 1 run scoreboard players add #corruption ruin_corrupt 5
scoreboard players set #defeated_ancient_colossus ruin_state 1
function ruin:day/recalculate
give @a[tag=ruin.part_ancient_colossus] minecraft:heavy_core[custom_data={ruin_item:'colossus_core'},item_name={text:'Colossus Core',color:'gold',italic:false},item_model='ruin:colossus_core',enchantment_glint_override=true] 1
execute if score #boss_first ruin_state matches 1 run tellraw @a [{text:'THE ANCIENT COLOSSUS DEFEATED',color:'gold',bold:true},{text:'  |  World Threat +5',color:'red'}]
execute unless score #boss_first ruin_state matches 1 run tellraw @a {text:'THE ANCIENT COLOSSUS DEFEATED AGAIN',color:'gold',bold:true}

tag @a remove ruin.part_ancient_colossus
