tag @s add ruin.nodes_down
effect clear @s minecraft:resistance
execute if score @s ruin_players matches 1 run effect give @s minecraft:resistance infinite 0 true
execute if score @s ruin_players matches 2 run effect give @s minecraft:resistance infinite 2 true
execute if score @s ruin_players matches 3.. run effect give @s minecraft:resistance infinite 3 true
title @a[tag=ruin.part_ancient_colossus] actionbar {text:'The Colossus core is exposed!',color:'gold',bold:true}
