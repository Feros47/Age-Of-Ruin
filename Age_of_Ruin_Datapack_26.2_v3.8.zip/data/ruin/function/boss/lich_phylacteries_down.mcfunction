tag @s add ruin.phylacteries_down
effect clear @s minecraft:resistance
execute if score @s ruin_players matches 2 run effect give @s minecraft:resistance infinite 1 true
execute if score @s ruin_players matches 3 run effect give @s minecraft:resistance infinite 2 true
execute if score @s ruin_players matches 4.. run effect give @s minecraft:resistance infinite 3 true
title @a[tag=ruin.part_lich_king] actionbar {text:'The Lich is mortal!',color:'light_purple',bold:true}
