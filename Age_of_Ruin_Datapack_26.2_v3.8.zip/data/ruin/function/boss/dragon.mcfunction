execute as @e[type=minecraft:ender_dragon,tag=!ruin.dragon] run tag @s add ruin.dragon
execute as @e[type=minecraft:ender_dragon,tag=ruin.dragon,tag=!ruin.dragon_scaled] at @s run function ruin:boss/dragon_scale
execute as @e[type=minecraft:ender_dragon,tag=ruin.dragon,tag=!ruin.dragon_scaled] run tag @s add ruin.dragon_scaled
execute if entity @e[type=minecraft:ender_dragon,tag=ruin.dragon] run scoreboard players set #dragon_active ruin_state 1
execute as @e[type=minecraft:ender_dragon,tag=ruin.dragon] at @s run tag @a[distance=..192] add ruin.part_dragon
scoreboard players add @e[type=minecraft:ender_dragon,tag=ruin.dragon] ruin_boss_timer 1
execute as @e[type=minecraft:ender_dragon,tag=ruin.dragon] at @s run function ruin:boss/dragon_phase
