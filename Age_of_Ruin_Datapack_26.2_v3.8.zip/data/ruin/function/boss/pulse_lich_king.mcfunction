scoreboard players set @s ruin_boss_timer 0
execute if entity @e[tag=ruin.lich_phylactery,distance=..24] run function ruin:affix/heal_fixed
execute if entity @e[tag=ruin.lich_phylactery,distance=..24] run effect give @s minecraft:resistance 2 4 true
summon minecraft:wither_skeleton ~3 ~ ~ {Tags:["ruin.initialized"]}
summon minecraft:skeleton ~-3 ~ ~ {Tags:["ruin.initialized"]}
effect give @a[distance=..12] minecraft:weakness 6 2 true
execute if entity @s[tag=ruin.lich_p2] run summon minecraft:zombie ~ ~ ~4 {Tags:["ruin.initialized","ruin.lich_add"]}
execute if entity @s[tag=ruin.lich_p2] run effect give @a[distance=..16] minecraft:wither 5 1 true
execute if entity @s[tag=ruin.lich_p3] if entity @p[distance=5..28] run tp @s ^-5 ^ ^4 facing entity @p eyes
execute if entity @s[tag=ruin.lich_p3] run execute as @a[distance=..8] run damage @s 16 minecraft:magic
execute if entity @s[tag=ruin.lich_p3] run effect give @a[distance=..20] minecraft:darkness 5 0 true
