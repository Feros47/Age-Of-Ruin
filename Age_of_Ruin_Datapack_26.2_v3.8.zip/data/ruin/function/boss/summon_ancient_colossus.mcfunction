execute if score #active_ancient_colossus ruin_state matches 1 run return 0
tag @a remove ruin.part_ancient_colossus
summon minecraft:ravager ~ ~2 ~ {Tags:["ruin.initialized","ruin.boss","ruin.boss_ancient_colossus","ruin.current_boss","ruin.siege"],CustomName:{text:'THE ANCIENT COLOSSUS',color:'gray',bold:true},CustomNameVisible:1b,PersistenceRequired:1b,CanPickUpLoot:0b}
summon minecraft:marker ~ ~2 ~ {Tags:["ruin.boss_anchor","ruin.anchor_ancient_colossus"]}
execute as @e[tag=ruin.boss_ancient_colossus,limit=1,sort=nearest] at @s run tag @a[distance=..128] add ruin.part_ancient_colossus
execute as @e[tag=ruin.boss_ancient_colossus,limit=1,sort=nearest] at @s run function ruin:boss/scale_ancient_colossus
execute as @e[tag=ruin.boss_ancient_colossus,limit=1,sort=nearest] run item replace entity @s weapon.offhand with minecraft:heavy_core[custom_data={ruin_item:'colossus_core'},item_name={text:'Colossus Core',color:'gold',italic:false},item_model='ruin:colossus_core',enchantment_glint_override=true] 1
execute as @e[tag=ruin.boss_ancient_colossus,limit=1,sort=nearest] run data merge entity @s {drop_chances:{offhand:1.0f}}
execute as @e[tag=ruin.boss_ancient_colossus,limit=1,sort=nearest] run function ruin:affix/juggernaut
execute as @e[tag=ruin.boss_ancient_colossus,limit=1,sort=nearest] run function ruin:affix/armored
execute as @e[tag=ruin.boss_ancient_colossus,limit=1,sort=nearest] run function ruin:affix/reflective
execute as @e[tag=ruin.boss_ancient_colossus,limit=1,sort=nearest] run function ruin:boss/finalize_pool
scoreboard players set #active_ancient_colossus ruin_state 1
bossbar remove ruin:ancient_colossus
bossbar add ruin:ancient_colossus {text:'THE ANCIENT COLOSSUS',color:'gray',bold:true}
execute store result bossbar ruin:ancient_colossus max run scoreboard players get @e[tag=ruin.boss_ancient_colossus,limit=1,sort=nearest] ruin_basehp
bossbar set ruin:ancient_colossus players @a[tag=ruin.part_ancient_colossus]
title @a title {text:'THE ANCIENT COLOSSUS',color:'gray',bold:true}
playsound minecraft:entity.wither.spawn master @a ~ ~ ~ 0.9 0.7
execute as @e[tag=ruin.current_boss] run tag @s remove ruin.current_boss
summon minecraft:shulker ~5 ~2 ~ {Tags:["ruin.colossus_node"],CustomName:{text:'Colossus Weak Point',color:'gold'},PersistenceRequired:1b}
summon minecraft:shulker ~-5 ~2 ~ {Tags:["ruin.colossus_node"],CustomName:{text:'Colossus Weak Point',color:'gold'},PersistenceRequired:1b}
summon minecraft:shulker ~ ~2 ~5 {Tags:["ruin.colossus_node"],CustomName:{text:'Colossus Weak Point',color:'gold'},PersistenceRequired:1b}
summon minecraft:shulker ~ ~2 ~-5 {Tags:["ruin.colossus_node"],CustomName:{text:'Colossus Weak Point',color:'gold'},PersistenceRequired:1b}
