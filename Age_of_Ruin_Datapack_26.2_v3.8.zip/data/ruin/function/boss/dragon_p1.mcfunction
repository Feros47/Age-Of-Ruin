scoreboard players set @s ruin_boss_timer 0
execute at @a[tag=ruin.part_dragon,distance=..160] run summon minecraft:enderman ~3 ~ ~ {Tags:["ruin.initialized","ruin.dragon_add"]}
effect give @a[tag=ruin.part_dragon,distance=..160] minecraft:weakness 3 0 true
execute as @a[distance=..160] run damage @s 8 minecraft:dragon_breath
