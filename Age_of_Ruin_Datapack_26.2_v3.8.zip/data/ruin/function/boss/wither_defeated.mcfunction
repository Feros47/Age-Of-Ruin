scoreboard players set #wither_active ruin_state 0
give @a[tag=ruin.part_wither] minecraft:wither_rose[custom_data={ruin_item:'heart_of_extinction'},item_name={text:'Heart of Extinction',color:'dark_red',italic:false},item_model='ruin:heart_of_extinction',enchantment_glint_override=true] 1
give @a[tag=ruin.part_wither] minecraft:nether_star[custom_data={ruin_item:'ancient_soul'},item_name={text:'Ancient Soul',color:'light_purple',italic:false},item_model='ruin:ancient_soul',enchantment_glint_override=true] 6
execute unless score #wither_defeated ruin_state matches 1 run scoreboard players set #wither_defeated ruin_state 1
execute unless score #wither_corruption_awarded ruin_state matches 1 run scoreboard players add #corruption ruin_corrupt 5
execute unless score #wither_corruption_awarded ruin_state matches 1 run scoreboard players set #wither_corruption_awarded ruin_state 1
function ruin:day/recalculate
tellraw @a [{text:'THE HARBINGER OF EXTINCTION HAS FALLEN',color:'dark_red',bold:true},{text:'  |  Its challengers claim the Heart of Extinction.',color:'red'}]
tag @a remove ruin.part_wither
