advancement revoke @s only ruin:kill_boss_lich_king
function ruin:boss/defeated_lich_king
