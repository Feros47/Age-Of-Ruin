scoreboard players set #active_lich_king ruin_state 0
kill @e[type=minecraft:marker,tag=ruin.anchor_lich_king]
bossbar remove ruin:lich_king
scoreboard players set #boss_first ruin_state 0
execute unless score #defeated_lich_king ruin_state matches 1 run scoreboard players set #boss_first ruin_state 1
execute if score #boss_first ruin_state matches 1 run scoreboard players add #corruption ruin_corrupt 5
scoreboard players set #defeated_lich_king ruin_state 1
function ruin:day/recalculate
give @a[tag=ruin.part_lich_king] minecraft:echo_shard[custom_data={ruin_item:'lich_phylactery'},item_name={text:'Lich Phylactery',color:'light_purple',italic:false},item_model='ruin:lich_phylactery',enchantment_glint_override=true] 1
execute if score #boss_first ruin_state matches 1 run tellraw @a [{text:'THE LICH KING DEFEATED',color:'gold',bold:true},{text:'  |  World Threat +5',color:'red'}]
execute unless score #boss_first ruin_state matches 1 run tellraw @a {text:'THE LICH KING DEFEATED AGAIN',color:'gold',bold:true}

tag @a remove ruin.part_lich_king
