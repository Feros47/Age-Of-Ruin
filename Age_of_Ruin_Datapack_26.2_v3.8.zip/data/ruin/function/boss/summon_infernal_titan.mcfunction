execute if score #active_infernal_titan ruin_state matches 1 run return 0
tag @a remove ruin.part_infernal_titan
summon minecraft:ravager ~ ~2 ~ {Tags:["ruin.initialized","ruin.boss","ruin.boss_infernal_titan","ruin.current_boss","ruin.siege"],CustomName:{text:'THE INFERNAL TITAN',color:'dark_red',bold:true},CustomNameVisible:1b,PersistenceRequired:1b,CanPickUpLoot:0b}
summon minecraft:marker ~ ~2 ~ {Tags:["ruin.boss_anchor","ruin.anchor_infernal_titan"]}
execute as @e[tag=ruin.boss_infernal_titan,limit=1,sort=nearest] at @s run tag @a[distance=..128] add ruin.part_infernal_titan
execute as @e[tag=ruin.boss_infernal_titan,limit=1,sort=nearest] at @s run function ruin:boss/scale_infernal_titan
execute as @e[tag=ruin.boss_infernal_titan,limit=1,sort=nearest] run item replace entity @s weapon.offhand with minecraft:netherite_chestplate[custom_data={ruin_relic:'phoenix_plate'},item_name={text:'Phoenix Plate',color:'gold',italic:false},item_model='ruin:phoenix_plate',enchantments={protection:12,unbreaking:10,'ruin:fortification':3}] 1
execute as @e[tag=ruin.boss_infernal_titan,limit=1,sort=nearest] run data merge entity @s {drop_chances:{offhand:1.0f}}
execute as @e[tag=ruin.boss_infernal_titan,limit=1,sort=nearest] run function ruin:affix/infernal
execute as @e[tag=ruin.boss_infernal_titan,limit=1,sort=nearest] run function ruin:affix/juggernaut
execute as @e[tag=ruin.boss_infernal_titan,limit=1,sort=nearest] run function ruin:affix/explosive
execute as @e[tag=ruin.boss_infernal_titan,limit=1,sort=nearest] run function ruin:boss/finalize_pool
scoreboard players set #active_infernal_titan ruin_state 1
bossbar remove ruin:infernal_titan
bossbar add ruin:infernal_titan {text:'THE INFERNAL TITAN',color:'dark_red',bold:true}
execute store result bossbar ruin:infernal_titan max run scoreboard players get @e[tag=ruin.boss_infernal_titan,limit=1,sort=nearest] ruin_basehp
bossbar set ruin:infernal_titan players @a[tag=ruin.part_infernal_titan]
title @a title {text:'THE INFERNAL TITAN',color:'dark_red',bold:true}
playsound minecraft:entity.wither.spawn master @a ~ ~ ~ 0.9 0.7
execute as @e[tag=ruin.current_boss] run tag @s remove ruin.current_boss
