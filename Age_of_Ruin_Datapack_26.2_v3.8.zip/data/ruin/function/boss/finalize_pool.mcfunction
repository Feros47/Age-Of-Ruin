execute store result score @s ruin_maxhp run attribute @s minecraft:max_health get 100
execute store result entity @s Health float 0.01 run scoreboard players get @s ruin_maxhp
execute store result score @s ruin_abs run attribute @s minecraft:max_absorption get 100
execute store result entity @s AbsorptionAmount float 0.01 run scoreboard players get @s ruin_abs
execute store result score @s ruin_basehp run attribute @s minecraft:max_health get 1
execute store result score @s ruin_tmp run attribute @s minecraft:max_absorption get 1
scoreboard players operation @s ruin_basehp += @s ruin_tmp
execute if data entity @s CustomName run function ruin:display/update_hostile_name
