scoreboard players set @s ruin_level 3
title @a title {text:'DEATH HAS COME',color:'dark_red',bold:true}
particle minecraft:explosion_emitter ~ ~ ~ 0 0 0 0 1 force
execute as @a[distance=..16] run damage @s 28 minecraft:explosion
scoreboard players operation @s ruin_hpcur = @s ruin_maxhp
scoreboard players set #eight ruin_tmp 8
scoreboard players operation @s ruin_hpcur *= #eight ruin_tmp
scoreboard players set #ten ruin_tmp 10
scoreboard players operation @s ruin_hpcur /= #ten ruin_tmp
execute store result entity @s Health float 0.01 run scoreboard players get @s ruin_hpcur
