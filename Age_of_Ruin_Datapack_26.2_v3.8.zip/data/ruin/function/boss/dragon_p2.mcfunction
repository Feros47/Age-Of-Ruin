scoreboard players set @s ruin_boss_timer 0
execute at @a[tag=ruin.part_dragon,distance=..160] run summon minecraft:shulker ~-4 ~ ~ {Tags:["ruin.initialized","ruin.dragon_add"]}
execute at @a[tag=ruin.part_dragon,distance=..160] run summon minecraft:enderman ~5 ~ ~ {Tags:["ruin.initialized","ruin.dragon_add"]}
execute at @a[tag=ruin.part_dragon,distance=..160,limit=1,sort=random] run summon minecraft:marker ~ ~ ~ {Tags:["ruin.dragon_void_zone"]}
effect give @a[distance=..160] minecraft:darkness 3 0 true
effect give @s minecraft:resistance 3 1 true
execute if entity @p[distance=16..160] run tp @s ^8 ^4 ^-8 facing entity @p eyes
execute in minecraft:the_end positioned 0 82 0 run summon minecraft:end_crystal ~ ~ ~ {Invulnerable:0b}
execute as @a[distance=..160] run damage @s 12 minecraft:dragon_breath
