scoreboard players set @s ruin_boss_timer 0
summon minecraft:wither_skeleton ~5 ~ ~ {Tags:["ruin.initialized","ruin.elite","ruin.siege"]}
summon minecraft:wither_skeleton ~-5 ~ ~ {Tags:["ruin.initialized","ruin.elite","ruin.siege"]}
effect give @a[distance=..96] minecraft:wither 6 3 true
execute as @a[distance=..12] run damage @s 18 minecraft:explosion
