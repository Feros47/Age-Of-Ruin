tag @s add ruin.lich_p3
title @a[tag=ruin.part_lich_king] title {text:'THE PHYLACTERY CRACKS',color:'light_purple',bold:true}
effect give @s minecraft:strength infinite 2 true
effect give @s minecraft:speed infinite 1 true
summon minecraft:vex ~3 ~2 ~ {Tags:["ruin.initialized","ruin.lich_add"],LifeTicks:400}
summon minecraft:vex ~-3 ~2 ~ {Tags:["ruin.initialized","ruin.lich_add"],LifeTicks:400}
