scoreboard players set @s ruin_boss_timer 0
damage @s 8 minecraft:generic
execute as @a[distance=..96] run damage @s 22 minecraft:wither
effect give @a[distance=..96] minecraft:weakness 3 1 true
