scoreboard players set #active_grave_king ruin_state 0
kill @e[type=minecraft:marker,tag=ruin.anchor_grave_king]
bossbar remove ruin:grave_king
scoreboard players set #boss_first ruin_state 0
execute unless score #defeated_grave_king ruin_state matches 1 run scoreboard players set #boss_first ruin_state 1
execute if score #boss_first ruin_state matches 1 run scoreboard players add #corruption ruin_corrupt 5
scoreboard players set #defeated_grave_king ruin_state 1
function ruin:day/recalculate
give @a[tag=ruin.part_grave_king] minecraft:nether_star[custom_data={ruin_item:'ancient_soul'},item_name={text:'Ancient Soul',color:'light_purple',italic:false},item_model='ruin:ancient_soul',enchantment_glint_override=true] 1
give @a[tag=ruin.part_grave_king] minecraft:netherite_sword[custom_data={ruin_relic:'gravecaller'},item_name={text:'Gravecaller',color:'gray',italic:false},item_model='ruin:gravecaller',enchantments={sharpness:8,unbreaking:8,looting:5}] 1
execute if score #boss_first ruin_state matches 1 run tellraw @a [{text:'THE GRAVE KING DEFEATED',color:'gold',bold:true},{text:'  |  World Threat +5',color:'red'}]
execute unless score #boss_first ruin_state matches 1 run tellraw @a {text:'THE GRAVE KING DEFEATED AGAIN',color:'gold',bold:true}

tag @a remove ruin.part_grave_king
