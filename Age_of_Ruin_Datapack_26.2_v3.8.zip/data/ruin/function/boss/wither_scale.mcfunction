scoreboard players set @s ruin_players 0
execute as @a[distance=..128] run scoreboard players add @e[type=minecraft:wither,tag=ruin.wither,limit=1] ruin_players 1
execute if score @s ruin_players matches ..0 run scoreboard players set @s ruin_players 1
effect clear @s minecraft:resistance
execute if score @s ruin_players matches 1 run attribute @s minecraft:max_health base set 800
execute if score @s ruin_players matches 1 run effect give @s minecraft:resistance infinite 1 true
execute if score @s ruin_players matches 2 run attribute @s minecraft:max_health base set 950
execute if score @s ruin_players matches 2 run effect give @s minecraft:resistance infinite 2 true
execute if score @s ruin_players matches 3 run attribute @s minecraft:max_health base set 1024
execute if score @s ruin_players matches 3 run effect give @s minecraft:resistance infinite 2 true
execute if score @s ruin_players matches 4.. run attribute @s minecraft:max_health base set 1024
execute if score @s ruin_players matches 4.. run effect give @s minecraft:resistance infinite 3 true
execute store result score @s ruin_maxhp run attribute @s minecraft:max_health get 100
execute store result entity @s Health float 0.01 run scoreboard players get @s ruin_maxhp
scoreboard players set @s ruin_boss_timer 0
scoreboard players set @s ruin_level 1
