advancement revoke @s only ruin:kill_boss_grave_king
function ruin:boss/defeated_grave_king
