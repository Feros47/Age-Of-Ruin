advancement revoke @s only ruin:kill_boss_infernal_titan
function ruin:boss/defeated_infernal_titan
