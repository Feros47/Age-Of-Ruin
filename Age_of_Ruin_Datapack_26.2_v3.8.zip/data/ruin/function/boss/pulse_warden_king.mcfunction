scoreboard players set @s ruin_boss_timer 0
effect give @a[distance=..32] minecraft:darkness 6 0 true
execute as @a[distance=8..36] run damage @s 22 minecraft:sonic_boom
execute as @a[distance=..7] run damage @s 16 minecraft:mob_attack
playsound minecraft:entity.warden.sonic_boom hostile @a[distance=..48] ~ ~ ~ 1 0.55
