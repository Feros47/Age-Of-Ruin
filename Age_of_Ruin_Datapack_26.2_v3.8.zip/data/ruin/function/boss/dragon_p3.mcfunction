scoreboard players set @s ruin_boss_timer 0
execute at @a[tag=ruin.part_dragon,distance=..160] run summon minecraft:shulker ~4 ~ ~ {Tags:["ruin.initialized","ruin.dragon_add"]}
execute at @a[tag=ruin.part_dragon,distance=..160] run summon minecraft:enderman ~-4 ~ ~ {Tags:["ruin.initialized","ruin.elite","ruin.dragon_add"]}
execute at @a[tag=ruin.part_dragon,distance=..160] run summon minecraft:endermite ~2 ~ ~-3 {Tags:["ruin.initialized","ruin.dragon_add"]}
execute at @a[tag=ruin.part_dragon,distance=..160] run summon minecraft:phantom ~ ~6 ~ {Tags:["ruin.initialized","ruin.dragon_add"]}
effect give @a[tag=ruin.part_dragon,distance=..160] minecraft:levitation 2 0 true
execute as @a[distance=..160] run damage @s 16 minecraft:dragon_breath
