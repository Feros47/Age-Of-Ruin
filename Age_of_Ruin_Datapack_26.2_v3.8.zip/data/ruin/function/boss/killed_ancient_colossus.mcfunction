advancement revoke @s only ruin:kill_boss_ancient_colossus
function ruin:boss/defeated_ancient_colossus
