execute unless score #wither_active ruin_state matches 1 as @e[type=minecraft:wither,tag=!ruin.wither,limit=1,sort=nearest] run tag @s add ruin.wither
execute as @e[type=minecraft:wither,tag=ruin.wither,tag=!ruin.wither_scaled] at @s unless predicate ruin:in_nether unless predicate ruin:in_end run scoreboard players set #wither_dim ruin_state 0
execute as @e[type=minecraft:wither,tag=ruin.wither,tag=!ruin.wither_scaled] at @s if predicate ruin:in_nether run scoreboard players set #wither_dim ruin_state 1
execute as @e[type=minecraft:wither,tag=ruin.wither,tag=!ruin.wither_scaled] at @s if predicate ruin:in_end run scoreboard players set #wither_dim ruin_state 2
execute as @e[type=minecraft:wither,tag=ruin.wither,tag=!ruin.wither_scaled] at @s run function ruin:boss/wither_scale
execute as @e[type=minecraft:wither,tag=ruin.wither,tag=!ruin.wither_scaled] run tag @s add ruin.wither_scaled
execute if entity @e[type=minecraft:wither,tag=ruin.wither] run scoreboard players set #wither_active ruin_state 1
execute as @e[type=minecraft:wither,tag=ruin.wither] at @s run tag @a[distance=..128] add ruin.part_wither
scoreboard players add @e[type=minecraft:wither,tag=ruin.wither] ruin_boss_timer 1
execute as @e[type=minecraft:wither,tag=ruin.wither] at @s run function ruin:boss/wither_phase
