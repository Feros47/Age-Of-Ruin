function ruin:runtime/second
