effect give @a[distance=..3] minecraft:poison 5 1 true
particle minecraft:spore_blossom_air ~ ~1 ~ 1 0.5 1 0 10 force
