execute store result score @s ruin_random run random value 1..5
execute if score @s ruin_random matches 1 run effect give @a[distance=..6] minecraft:weakness 6 2 true
execute if score @s ruin_random matches 2 run effect give @a[distance=..6] minecraft:slowness 5 2 true
execute if score @s ruin_random matches 3 run effect give @a[distance=..6] minecraft:darkness 4 0 true
execute if score @s ruin_random matches 4 run effect give @a[distance=..6] minecraft:mining_fatigue 6 1 true
execute if score @s ruin_random matches 5 run effect give @a[distance=..6] minecraft:hunger 8 2 true
