scoreboard players set #local_adds ruin_tmp 0
execute as @e[tag=ruin.thrall,distance=..24] run scoreboard players add #local_adds ruin_tmp 1
execute if score #local_adds ruin_tmp matches ..5 run summon minecraft:zombie ~2 ~ ~ {Tags:["ruin.initialized","ruin.thrall"],CustomName:{text:'Raised Thrall',color:'dark_gray'},PersistenceRequired:1b}
execute if score #local_adds ruin_tmp matches ..5 run summon minecraft:skeleton ~-2 ~ ~ {Tags:["ruin.initialized","ruin.thrall"],CustomName:{text:'Raised Thrall',color:'dark_gray'},PersistenceRequired:1b}
