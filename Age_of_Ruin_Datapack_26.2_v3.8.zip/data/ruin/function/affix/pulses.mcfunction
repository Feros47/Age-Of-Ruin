# Execute only the pulses due on this global cadence; resets happen after all dimensions run.
execute as @e[tag=ruin.affix_berserker] at @s run function ruin:affix/pulse_berserker
execute as @e[tag=ruin.affix_reflective] at @s run function ruin:affix/pulse_reflective
execute as @e[tag=ruin.affix_executioner] at @s run function ruin:affix/pulse_executioner
execute if score #affix3 ruin_clock matches 3.. as @e[tag=ruin.affix_vampiric] at @s run function ruin:affix/pulse_vampiric
execute if score #affix3 ruin_clock matches 3.. as @e[tag=ruin.affix_infernal] at @s run function ruin:affix/pulse_infernal
execute if score #affix3 ruin_clock matches 3.. as @e[tag=ruin.affix_commander] at @s run function ruin:affix/pulse_commander
execute if score #affix4 ruin_clock matches 4.. as @e[tag=ruin.affix_regenerating] at @s run function ruin:affix/pulse_regenerating
execute if score #affix4 ruin_clock matches 4.. as @e[tag=ruin.affix_venomous] at @s run function ruin:affix/pulse_venomous
execute if score #affix4 ruin_clock matches 4.. as @e[tag=ruin.affix_withering] at @s run function ruin:affix/pulse_withering
execute if score #affix4 ruin_clock matches 4.. as @e[tag=ruin.affix_frostbound] at @s run function ruin:affix/pulse_frostbound
execute if score #affix5 ruin_clock matches 5.. as @e[tag=ruin.affix_leeching] at @s run function ruin:affix/pulse_leeching
execute if score #affix7 ruin_clock matches 7.. as @e[tag=ruin.affix_blinking] at @s run function ruin:affix/pulse_blinking
execute if score #affix7 ruin_clock matches 7.. as @e[tag=ruin.affix_hexed] at @s run function ruin:affix/pulse_hexed
execute if score #affix8 ruin_clock matches 8.. as @e[tag=ruin.affix_phasewalker] at @s run function ruin:affix/pulse_phasewalker
execute if score #affix9 ruin_clock matches 9.. as @e[tag=ruin.affix_explosive] at @s run function ruin:affix/pulse_explosive
execute if score #affix10 ruin_clock matches 10.. as @e[tag=ruin.affix_necromancer] at @s run function ruin:affix/pulse_necromancer
execute if score #affix12 ruin_clock matches 12.. as @e[tag=ruin.affix_stormborn] at @s run function ruin:affix/pulse_stormborn
