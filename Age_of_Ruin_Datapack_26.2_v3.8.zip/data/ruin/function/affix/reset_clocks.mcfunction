execute if score #affix3 ruin_clock matches 3.. run scoreboard players set #affix3 ruin_clock 0
execute if score #affix4 ruin_clock matches 4.. run scoreboard players set #affix4 ruin_clock 0
execute if score #affix5 ruin_clock matches 5.. run scoreboard players set #affix5 ruin_clock 0
execute if score #affix7 ruin_clock matches 7.. run scoreboard players set #affix7 ruin_clock 0
execute if score #affix8 ruin_clock matches 8.. run scoreboard players set #affix8 ruin_clock 0
execute if score #affix9 ruin_clock matches 9.. run scoreboard players set #affix9 ruin_clock 0
execute if score #affix10 ruin_clock matches 10.. run scoreboard players set #affix10 ruin_clock 0
execute if score #affix12 ruin_clock matches 12.. run scoreboard players set #affix12 ruin_clock 0
