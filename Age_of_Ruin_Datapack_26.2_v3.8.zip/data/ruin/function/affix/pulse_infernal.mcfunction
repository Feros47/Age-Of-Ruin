execute as @a[distance=..2.8] run damage @s 4 minecraft:on_fire
setblock ~ ~ ~ minecraft:fire keep
particle minecraft:flame ~ ~0.5 ~ 0.6 0.2 0.6 0.03 12 force
