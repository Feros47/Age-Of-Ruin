effect give @a[distance=..4] minecraft:slowness 5 2 true
execute as @a[distance=..2.5] run damage @s 3 minecraft:freeze
particle minecraft:snowflake ~ ~1 ~ 0.8 0.8 0.8 0.05 18 force
