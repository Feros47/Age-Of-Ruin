execute if entity @p[distance=4..20] run tp @s ^3 ^ ^3 facing entity @p eyes
particle minecraft:portal ~ ~1 ~ 0.8 1 0.8 0.3 25 force
