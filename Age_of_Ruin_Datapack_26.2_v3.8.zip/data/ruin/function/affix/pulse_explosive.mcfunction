particle minecraft:explosion ~ ~1 ~ 0 0 0 0 1 force
playsound minecraft:entity.generic.explode hostile @a[distance=..24] ~ ~ ~ 0.6 1.3
execute as @a[distance=..4] run damage @s 8 minecraft:explosion
