# Compatibility alias retained for v3.7 operator notes.
function ruin:admin/v38_selftest
