function ruin:day/recalculate
function ruin:day/set_era
function ruin:day/message
