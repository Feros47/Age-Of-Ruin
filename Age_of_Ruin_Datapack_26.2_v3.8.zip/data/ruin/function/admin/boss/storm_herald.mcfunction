execute at @s run function ruin:boss/summon_storm_herald
