execute at @s run function ruin:boss/summon_warden_king
