execute at @s run function ruin:boss/summon_ancient_colossus
