execute at @s run function ruin:boss/summon_lich_king
