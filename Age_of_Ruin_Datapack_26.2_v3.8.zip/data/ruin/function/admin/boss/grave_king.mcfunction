execute at @s run function ruin:boss/summon_grave_king
