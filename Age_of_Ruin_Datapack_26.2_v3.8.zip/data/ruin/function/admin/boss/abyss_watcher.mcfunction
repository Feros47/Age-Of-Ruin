execute at @s run function ruin:boss/summon_abyss_watcher
