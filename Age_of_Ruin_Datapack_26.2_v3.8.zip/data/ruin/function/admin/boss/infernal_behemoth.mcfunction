execute at @s run function ruin:boss/summon_infernal_behemoth
