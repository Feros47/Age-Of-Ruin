execute at @s run function ruin:boss/summon_void_emperor
