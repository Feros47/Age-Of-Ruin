summon minecraft:zombie ~2 ~ ~ {PersistenceRequired:1b,CustomName:{text:'Scaling Test Zombie',color:'red'},CustomNameVisible:1b}
execute as @e[type=minecraft:zombie,distance=..6,sort=nearest,limit=1,tag=!ruin.initialized] at @s run function ruin:mob/init_v33
execute as @e[type=minecraft:zombie,distance=..6,sort=nearest,limit=1] store result score @s ruin_maxhp run attribute @s minecraft:max_health get 100
tellraw @s [{text:'Spawned/scaled test Zombie. Max health x100 = ',color:'gray'},{score:{name:'@e[type=minecraft:zombie,distance=..6,sort=nearest,limit=1]',objective:'ruin_maxhp'},color:'red'}]
