summon minecraft:cow ~2 ~ ~ {Tags:["ruin.gene_initialized"],PersistenceRequired:1b}
execute as @e[type=minecraft:cow,distance=..6,sort=nearest,limit=1] run function ruin:gene/apply_vigor
execute as @e[type=minecraft:cow,distance=..6,sort=nearest,limit=1] run function ruin:gene/apply_golden
execute as @e[type=minecraft:cow,distance=..6,sort=nearest,limit=1] run function ruin:display/update_gene_name
tellraw @s {text:'Spawned a Vigor + Golden genetic Cow for nametag testing.',color:'green'}
