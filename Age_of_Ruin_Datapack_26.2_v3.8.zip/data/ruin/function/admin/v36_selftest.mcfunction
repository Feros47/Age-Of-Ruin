# Compatibility alias retained for v3.6 operator notes.
function ruin:admin/v37_selftest
