summon minecraft:zombie ~2 ~ ~ {Tags:["ruin.initialized"],PersistenceRequired:1b}
execute as @e[type=minecraft:zombie,distance=..6,sort=nearest,limit=1] run function ruin:mob/make_elite
execute as @e[type=minecraft:zombie,distance=..6,sort=nearest,limit=1] run function ruin:mob/finalize
tellraw @s {text:'Spawned a forced Elite Zombie for nametag/affix testing.',color:'green'}
