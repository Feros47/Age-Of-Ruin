tellraw @s {text:'Nearest genetic animal DeathLootTable:',color:'gold'}
data get entity @e[type=#ruin:gene_pool,tag=ruin.genetic,distance=..12,sort=nearest,limit=1] DeathLootTable
