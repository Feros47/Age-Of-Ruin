# Compatibility alias retained for v3.5 operator notes.
function ruin:admin/v36_selftest
