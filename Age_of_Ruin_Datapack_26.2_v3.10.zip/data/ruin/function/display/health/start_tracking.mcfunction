# Executed as and at the living entity entering health-label range.
tag @s add ruin.health_tracked
function ruin:display/health/attach
function ruin:display/health/update
