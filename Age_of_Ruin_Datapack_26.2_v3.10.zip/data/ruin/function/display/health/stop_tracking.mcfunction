# Executed as and at the living entity leaving health-label range.
execute on passengers if entity @s[type=minecraft:text_display,tag=ruin.health_display] run kill @s
execute if entity @s[tag=ruin.health_name_mirrored] if data entity @s CustomName run data merge entity @s {CustomNameVisible:1b}
tag @s remove ruin.health_name_mirrored
tag @s remove ruin.health_tracked
scoreboard players reset @s ruin_namehp
scoreboard players reset @s ruin_namemax
scoreboard players reset @s ruin_namepct
scoreboard players reset @s ruin_namehp_raw
scoreboard players reset @s ruin_namemax_raw
scoreboard players reset @s ruin_namehp_now
scoreboard players reset @s ruin_namemax_now
