# Cache integer current/max health on the parent entity.
execute store result score @s ruin_namehp_raw run data get entity @s Health 100
execute store result score @s ruin_namemax_raw run attribute @s minecraft:max_health get 100
execute store result score @s ruin_namehp run data get entity @s Health 1
execute store result score @s ruin_namemax run attribute @s minecraft:max_health get 1
scoreboard players operation @s ruin_namepct = @s ruin_namehp
scoreboard players operation @s ruin_namepct *= #hundred ruin_namepct
execute if score @s ruin_namemax matches 1.. run scoreboard players operation @s ruin_namepct /= @s ruin_namemax

# Macro storage supplies the values without hard-coding entity types or health caps.
execute store result storage ruin:health current int 1 run scoreboard players get @s ruin_namehp
execute store result storage ruin:health max int 1 run scoreboard players get @s ruin_namemax
execute if score @s ruin_namepct matches 67.. run function ruin:display/health/render_green with storage ruin:health
execute if score @s ruin_namepct matches 34..66 run function ruin:display/health/render_yellow with storage ruin:health
execute if score @s ruin_namepct matches ..33 run function ruin:display/health/render_red with storage ruin:health

# Visible vanilla names are mirrored below health in the same display. This prevents
# genes, affixes and boss names from overlapping or being depth-hidden by the HP line.
execute if data entity @s CustomName if entity @s[nbt={CustomNameVisible:1b}] run tag @s add ruin.health_name_mirrored
execute if entity @s[tag=ruin.health_name_mirrored] if data entity @s CustomName run data modify storage ruin:health label.extra set value [{text:"\n"}]
execute if entity @s[tag=ruin.health_name_mirrored] if data entity @s CustomName run data modify storage ruin:health label.extra append from entity @s CustomName
execute if entity @s[tag=ruin.health_name_mirrored] run data merge entity @s {CustomNameVisible:0b}
execute on passengers if entity @s[type=minecraft:text_display,tag=ruin.health_display] run data modify entity @s text set from storage ruin:health label
tag @s remove ruin.health_label_dirty
