# Poll only tracked living entities every game tick; text is rebuilt only on change.
execute as @e[type=!minecraft:player,tag=ruin.health_tracked] run function ruin:display/health/probe
