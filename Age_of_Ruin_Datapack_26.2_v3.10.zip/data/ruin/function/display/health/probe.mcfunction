execute store result score @s ruin_namehp_now run data get entity @s Health 100
execute store result score @s ruin_namemax_now run attribute @s minecraft:max_health get 100
execute unless score @s ruin_namehp_now = @s ruin_namehp_raw run function ruin:display/health/update
execute unless score @s ruin_namemax_now = @s ruin_namemax_raw run function ruin:display/health/update
execute if entity @s[tag=ruin.health_label_dirty] run function ruin:display/health/update
