# Recreate a missing passenger at the parent, then initialize its text immediately.
function ruin:display/health/attach
function ruin:display/health/update
