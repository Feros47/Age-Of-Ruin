# The invisible AI carrier keeps combat/hitbox mechanics but must render no vanilla equipment.
effect give @s minecraft:invisibility infinite 0 true
item replace entity @s weapon.mainhand with minecraft:air
item replace entity @s weapon.offhand with minecraft:air
item replace entity @s armor.head with minecraft:air
item replace entity @s armor.chest with minecraft:air
item replace entity @s armor.legs with minecraft:air
item replace entity @s armor.feet with minecraft:air
tag @s add ruin.visual_carrier_hidden
