# Remove orphaned visuals, restore missing models, hide carrier equipment, and follow position/rotation at 20 Hz.
execute as @e[tag=ruin.boss,tag=!ruin.visual_carrier_hidden] run function ruin:boss/visual/hide_carrier
execute as @e[type=minecraft:item_display,tag=ruin.visual_grave_king] at @s unless entity @e[tag=ruin.boss_grave_king,distance=..24] run kill @s
execute as @e[type=minecraft:item_display,tag=ruin.visual_infernal_behemoth] at @s unless entity @e[tag=ruin.boss_infernal_behemoth,distance=..24] run kill @s
execute as @e[type=minecraft:item_display,tag=ruin.visual_abyss_watcher] at @s unless entity @e[tag=ruin.boss_abyss_watcher,distance=..24] run kill @s
execute as @e[type=minecraft:item_display,tag=ruin.visual_leviathan] at @s unless entity @e[tag=ruin.boss_leviathan,distance=..24] run kill @s
execute as @e[type=minecraft:item_display,tag=ruin.visual_ancient_colossus] at @s unless entity @e[tag=ruin.boss_ancient_colossus,distance=..24] run kill @s
execute as @e[type=minecraft:item_display,tag=ruin.visual_lich_king] at @s unless entity @e[tag=ruin.boss_lich_king,distance=..24] run kill @s
execute as @e[type=minecraft:item_display,tag=ruin.visual_infernal_titan] at @s unless entity @e[tag=ruin.boss_infernal_titan,distance=..24] run kill @s
execute as @e[type=minecraft:item_display,tag=ruin.visual_warden_king] at @s unless entity @e[tag=ruin.boss_warden_king,distance=..24] run kill @s
execute as @e[type=minecraft:item_display,tag=ruin.visual_storm_herald] at @s unless entity @e[tag=ruin.boss_storm_herald,distance=..24] run kill @s
execute as @e[type=minecraft:item_display,tag=ruin.visual_void_emperor] at @s unless entity @e[tag=ruin.boss_void_emperor,distance=..24] run kill @s
execute as @e[tag=ruin.boss_grave_king] at @s unless entity @e[type=minecraft:item_display,tag=ruin.visual_grave_king,distance=..24] run function ruin:boss/visual/grave_king
execute as @e[tag=ruin.boss_infernal_behemoth] at @s unless entity @e[type=minecraft:item_display,tag=ruin.visual_infernal_behemoth,distance=..24] run function ruin:boss/visual/infernal_behemoth
execute as @e[tag=ruin.boss_abyss_watcher] at @s unless entity @e[type=minecraft:item_display,tag=ruin.visual_abyss_watcher,distance=..24] run function ruin:boss/visual/abyss_watcher
execute as @e[tag=ruin.boss_leviathan] at @s unless entity @e[type=minecraft:item_display,tag=ruin.visual_leviathan,distance=..24] run function ruin:boss/visual/leviathan
execute as @e[tag=ruin.boss_ancient_colossus] at @s unless entity @e[type=minecraft:item_display,tag=ruin.visual_ancient_colossus,distance=..24] run function ruin:boss/visual/ancient_colossus
execute as @e[tag=ruin.boss_lich_king] at @s unless entity @e[type=minecraft:item_display,tag=ruin.visual_lich_king,distance=..24] run function ruin:boss/visual/lich_king
execute as @e[tag=ruin.boss_infernal_titan] at @s unless entity @e[type=minecraft:item_display,tag=ruin.visual_infernal_titan,distance=..24] run function ruin:boss/visual/infernal_titan
execute as @e[tag=ruin.boss_warden_king] at @s unless entity @e[type=minecraft:item_display,tag=ruin.visual_warden_king,distance=..24] run function ruin:boss/visual/warden_king
execute as @e[tag=ruin.boss_storm_herald] at @s unless entity @e[type=minecraft:item_display,tag=ruin.visual_storm_herald,distance=..24] run function ruin:boss/visual/storm_herald
execute as @e[tag=ruin.boss_void_emperor] at @s unless entity @e[type=minecraft:item_display,tag=ruin.visual_void_emperor,distance=..24] run function ruin:boss/visual/void_emperor
execute as @e[tag=ruin.boss_grave_king] at @s rotated as @s run tp @e[type=minecraft:item_display,tag=ruin.visual_grave_king,distance=..24,limit=1,sort=nearest] ~ ~ ~ ~ ~
execute as @e[tag=ruin.boss_infernal_behemoth] at @s rotated as @s run tp @e[type=minecraft:item_display,tag=ruin.visual_infernal_behemoth,distance=..24,limit=1,sort=nearest] ~ ~ ~ ~ ~
execute as @e[tag=ruin.boss_abyss_watcher] at @s rotated as @s run tp @e[type=minecraft:item_display,tag=ruin.visual_abyss_watcher,distance=..24,limit=1,sort=nearest] ~ ~ ~ ~ ~
execute as @e[tag=ruin.boss_leviathan] at @s rotated as @s run tp @e[type=minecraft:item_display,tag=ruin.visual_leviathan,distance=..24,limit=1,sort=nearest] ~ ~ ~ ~ ~
execute as @e[tag=ruin.boss_ancient_colossus] at @s rotated as @s run tp @e[type=minecraft:item_display,tag=ruin.visual_ancient_colossus,distance=..24,limit=1,sort=nearest] ~ ~ ~ ~ ~
execute as @e[tag=ruin.boss_lich_king] at @s rotated as @s run tp @e[type=minecraft:item_display,tag=ruin.visual_lich_king,distance=..24,limit=1,sort=nearest] ~ ~ ~ ~ ~
execute as @e[tag=ruin.boss_infernal_titan] at @s rotated as @s run tp @e[type=minecraft:item_display,tag=ruin.visual_infernal_titan,distance=..24,limit=1,sort=nearest] ~ ~ ~ ~ ~
execute as @e[tag=ruin.boss_warden_king] at @s rotated as @s run tp @e[type=minecraft:item_display,tag=ruin.visual_warden_king,distance=..24,limit=1,sort=nearest] ~ ~ ~ ~ ~
execute as @e[tag=ruin.boss_storm_herald] at @s rotated as @s run tp @e[type=minecraft:item_display,tag=ruin.visual_storm_herald,distance=..24,limit=1,sort=nearest] ~ ~ ~ ~ ~
execute as @e[tag=ruin.boss_void_emperor] at @s rotated as @s run tp @e[type=minecraft:item_display,tag=ruin.visual_void_emperor,distance=..24,limit=1,sort=nearest] ~ ~ ~ ~ ~
