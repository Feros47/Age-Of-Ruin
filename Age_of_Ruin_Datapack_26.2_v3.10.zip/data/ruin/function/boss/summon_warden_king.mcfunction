execute if score #active_warden_king ruin_state matches 1 run return 0
tag @a remove ruin.part_warden_king
summon minecraft:warden ~ ~2 ~ {Tags:["ruin.initialized","ruin.boss","ruin.boss_warden_king","ruin.current_boss","ruin.siege"],CustomName:{text:'THE WARDEN KING',color:'dark_aqua',bold:true},CustomNameVisible:1b,PersistenceRequired:1b,CanPickUpLoot:0b}
summon minecraft:marker ~ ~2 ~ {Tags:["ruin.boss_anchor","ruin.anchor_warden_king"]}
execute as @e[tag=ruin.boss_warden_king,limit=1,sort=nearest] at @s run tag @a[distance=..128] add ruin.part_warden_king
execute as @e[tag=ruin.boss_warden_king,limit=1,sort=nearest] at @s run function ruin:boss/scale_warden_king
execute as @e[tag=ruin.boss_warden_king,limit=1,sort=nearest] run function ruin:affix/armored
execute as @e[tag=ruin.boss_warden_king,limit=1,sort=nearest] run function ruin:affix/phasewalker
execute as @e[tag=ruin.boss_warden_king,limit=1,sort=nearest] run function ruin:affix/executioner
execute as @e[tag=ruin.boss_warden_king,limit=1,sort=nearest] run function ruin:boss/finalize_pool
scoreboard players set #active_warden_king ruin_state 1
bossbar remove ruin:warden_king
bossbar add ruin:warden_king {text:'THE WARDEN KING',color:'dark_aqua',bold:true}
execute store result bossbar ruin:warden_king max run scoreboard players get @e[tag=ruin.boss_warden_king,limit=1,sort=nearest] ruin_basehp
bossbar set ruin:warden_king players @a[tag=ruin.part_warden_king]
title @a title {text:'THE WARDEN KING',color:'dark_aqua',bold:true}
playsound minecraft:entity.wither.spawn master @a ~ ~ ~ 0.9 0.7
execute as @e[tag=ruin.current_boss] run tag @s remove ruin.current_boss
