# Compatibility alias retained for v3.9 operator notes.
function ruin:admin/v310_selftest
