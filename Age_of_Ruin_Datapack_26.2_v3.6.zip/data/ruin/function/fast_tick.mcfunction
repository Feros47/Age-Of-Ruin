scoreboard players set #fastclock ruin_clock 0
function ruin:relic/voidpiercer_tick
execute as @e[type=minecraft:arrow,tag=ruin.necrotic_arrow,tag=!ruin.necrotic_processed] at @s if entity @a[distance=..1.5] run effect give @a[distance=..1.5,limit=1,sort=nearest] minecraft:wither 4 1 true
execute as @e[type=minecraft:arrow,tag=ruin.necrotic_arrow,tag=!ruin.necrotic_processed] at @s if entity @a[distance=..1.5] run tag @s add ruin.necrotic_processed
execute as @e[type=minecraft:arrow,tag=ruin.storm_arrow,tag=!ruin.storm_processed] at @s if entity @a[distance=..1.5] run summon minecraft:lightning_bolt ~ ~ ~
execute as @e[type=minecraft:arrow,tag=ruin.storm_arrow,tag=!ruin.storm_processed] at @s if entity @a[distance=..1.5] run tag @s add ruin.storm_processed
