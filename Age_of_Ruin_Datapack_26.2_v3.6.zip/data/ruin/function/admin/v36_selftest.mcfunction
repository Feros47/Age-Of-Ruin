tellraw @s {text:'=== AGE OF RUIN v3.6 SELF-TEST ===',color:'gold',bold:true}
function ruin:admin/runtime_status
tellraw @s {text:'Spawning one normal processed Zombie, one guaranteed Elite, and one multi-gene Cow nearby.',color:'gray'}
function ruin:admin/test_scaling
function ruin:admin/test_elite
function ruin:admin/test_gene_loot
