Age of Ruin Resource Pack v3.0 for Minecraft Java 26.2. Install alongside the datapack.
