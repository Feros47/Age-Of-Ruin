# Age of Ruin v3.7 loader
scoreboard objectives add ruin_state dummy
scoreboard objectives add ruin_version dummy
execute unless score #version ruin_version matches 37 run function ruin:migrate/v37
execute if score #version ruin_version matches 37 run scoreboard players set #runtime_ready ruin_runtime 0
execute if score #version ruin_version matches 37 run schedule function ruin:runtime/heartbeat 1t replace
execute if score #version ruin_version matches 37 run tellraw @a [{text:'[Age of Ruin] ',color:'dark_red',bold:true},{text:'v3.7 runtime loaded.',color:'gold'}]
