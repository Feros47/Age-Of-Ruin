tellraw @s {text:'=== AGE OF RUIN v3.7 ADMIN ===',color:'dark_red',bold:true}
tellraw @s [{text:'Status: ',color:'gray'},{text:'/function ruin:admin/status',color:'aqua'}]
tellraw @s [{text:'Runtime diagnostics: ',color:'gray'},{text:'/function ruin:admin/runtime_status',color:'aqua'}]
tellraw @s [{text:'Smoke test bundle: ',color:'gray'},{text:'/function ruin:admin/v37_selftest',color:'aqua'}]
tellraw @s [{text:'Show daily report now: ',color:'gray'},{text:'/function ruin:admin/daily_message',color:'aqua'}]
tellraw @s [{text:'Give test currencies: ',color:'gray'},{text:'/function ruin:admin/give_currency',color:'aqua'}]
tellraw @s [{text:'Siege toggle: ',color:'gray'},{text:'/function ruin:admin/siege_on',color:'aqua'},{text:' / ',color:'dark_gray'},{text:'/function ruin:admin/siege_off',color:'aqua'}]
tellraw @s [{text:'Forced Elite test: ',color:'gray'},{text:'/function ruin:admin/test_elite',color:'aqua'}]
tellraw @s [{text:'Threat scaling test: ',color:'gray'},{text:'/function ruin:admin/test_scaling',color:'aqua'}]
tellraw @s [{text:'Genetic Cow test: ',color:'gray'},{text:'/function ruin:admin/test_gene',color:'aqua'}]
tellraw @s {text:'Bosses:',color:'gold',bold:true}
tellraw @s {text:'/function ruin:admin/boss/grave_king',color:'aqua'}
tellraw @s {text:'/function ruin:admin/boss/infernal_behemoth',color:'aqua'}
tellraw @s {text:'/function ruin:admin/boss/abyss_watcher',color:'aqua'}
tellraw @s {text:'/function ruin:admin/boss/leviathan',color:'aqua'}
tellraw @s {text:'/function ruin:admin/boss/ancient_colossus',color:'aqua'}
tellraw @s {text:'/function ruin:admin/boss/lich_king',color:'aqua'}
tellraw @s {text:'/function ruin:admin/boss/infernal_titan',color:'aqua'}
tellraw @s {text:'/function ruin:admin/boss/warden_king',color:'aqua'}
tellraw @s {text:'/function ruin:admin/boss/storm_herald',color:'aqua'}
tellraw @s {text:'/function ruin:admin/boss/void_emperor',color:'aqua'}

tellraw @s [{text:'/function ruin:admin/test_gene_loot',color:'aqua'},{text:' — spawn a cow that proves gene loot bonuses',color:'gray'}]
tellraw @s [{text:'/function ruin:admin/inspect_gene_loot',color:'aqua'},{text:' — show nearest genetic animal DeathLootTable',color:'gray'}]
