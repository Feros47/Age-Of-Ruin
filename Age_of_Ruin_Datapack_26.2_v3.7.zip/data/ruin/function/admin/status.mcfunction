tellraw @s {text:'=== AGE OF RUIN v3.7 ===',color:'dark_red',bold:true}
tellraw @s [{text:'Day: ',color:'gray'},{score:{name:'#day',objective:'ruin_day'},color:'gold'},{text:' | Threat: ',color:'gray'},{score:{name:'#threat',objective:'ruin_threat'},color:'red'},{text:' | Corruption: ',color:'gray'},{score:{name:'#corruption',objective:'ruin_corrupt'},color:'dark_purple'}]
tellraw @s [{text:'Event: ',color:'gray'},{score:{name:'#event',objective:'ruin_state'},color:'yellow'},{text:' | Blood Moon: ',color:'gray'},{score:{name:'#bloodmoon',objective:'ruin_state'},color:'red'}]
execute store result score #nearby_init ruin_tmp if entity @e[type=#ruin:scalable_hostiles,tag=ruin.initialized,distance=..32]
tellraw @s [{text:'Initialized hostile mobs nearby: ',color:'gray'},{score:{name:'#nearby_init',objective:'ruin_tmp'},color:'green'}]
tellraw @s [{text:'Admin help: ',color:'gray'},{text:'/function ruin:admin/help',color:'aqua'}]
