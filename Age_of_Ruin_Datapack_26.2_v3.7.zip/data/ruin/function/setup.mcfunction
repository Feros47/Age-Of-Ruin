# Age of Ruin v3.7 first-time setup.
scoreboard objectives add ruin_clock dummy
scoreboard objectives add ruin_day dummy
scoreboard objectives add ruin_state dummy
scoreboard objectives add ruin_random dummy
scoreboard objectives add ruin_timer dummy
scoreboard objectives add ruin_level dummy
scoreboard objectives add ruin_have dummy
scoreboard objectives add ruin_cost dummy
scoreboard objectives add ruin_threat dummy
scoreboard objectives add ruin_corrupt dummy
scoreboard objectives add ruin_tmp dummy
scoreboard objectives add ruin_basehp dummy
scoreboard objectives add ruin_maxhp dummy
scoreboard objectives add ruin_abs dummy
scoreboard objectives add ruin_base_dmg dummy
scoreboard objectives add ruin_dmg dummy
scoreboard objectives add ruin_hpcur dummy
scoreboard objectives add ruin_pct dummy
scoreboard objectives add ruin_players dummy
scoreboard objectives add ruin_affixes dummy
scoreboard objectives add ruin_deaths deathCount
scoreboard objectives add ruin_deaths_prev dummy
scoreboard objectives add ruin_fracture dummy
scoreboard objectives add ruin_fracture_time dummy
scoreboard objectives add ruin_phoenix_cd dummy
scoreboard objectives add ruin_prot dummy
scoreboard objectives add ruin_fort dummy
scoreboard objectives add ruin_sharp trigger
scoreboard objectives add ruin_power trigger
scoreboard objectives add ruin_prot_h trigger
scoreboard objectives add ruin_prot_c trigger
scoreboard objectives add ruin_prot_l trigger
scoreboard objectives add ruin_prot_f trigger
scoreboard objectives add ruin_eff trigger
scoreboard objectives add ruin_unbr trigger
scoreboard objectives add ruin_loot trigger
scoreboard players set #setup ruin_state 2
scoreboard players set #day ruin_day 1
scoreboard players set #processed_day ruin_day 0
scoreboard players set #corruption ruin_corrupt 0
scoreboard players set #bloodmoon ruin_state 0
scoreboard players set #bloodmoon_live ruin_state 0
scoreboard players set #event ruin_state 0
scoreboard players set #event_live ruin_state 0
scoreboard players set #event_wave ruin_state 0
scoreboard players set #event_timer ruin_clock 0
scoreboard players set #event_last ruin_day 1
scoreboard players set #last_blood ruin_day 1
scoreboard players set #next_invasion ruin_day 18
scoreboard players set #patrol_cd ruin_clock 0
scoreboard players set #blood_timer ruin_clock 0
scoreboard players set #siege ruin_state 1
scoreboard players set #second ruin_clock 0
scoreboard players set #siegeclock ruin_clock 0
scoreboard players set #bossclock ruin_clock 0
scoreboard players set #fastclock ruin_clock 0
scoreboard players set #diamond_seen ruin_state 0
scoreboard players set #nether_seen ruin_state 0
scoreboard players set #netherite_seen ruin_state 0
scoreboard players set #dragon_active ruin_state 0
scoreboard players set #dragon_defeated ruin_state 0
scoreboard players set #wither_active ruin_state 0
scoreboard players set #wither_defeated ruin_state 0
team add ruin_bossadds {text:'Ruin Boss Adds'}
team modify ruin_bossadds friendlyFire false
tellraw @a [{text:'[Age of Ruin] ',color:'dark_red',bold:true},{text:'The world has begun to learn from you.',color:'gray'}]
scoreboard objectives add ruin_enchant trigger
scoreboard objectives add ruin_luck dummy
scoreboard objectives add ruin_gene_count dummy
scoreboard objectives add ruin_gene_age dummy
scoreboard objectives add ruin_gene_roll dummy
scoreboard players set #nether_warband ruin_clock 0
scoreboard players set #nether_storm ruin_clock 0
scoreboard players set #geneclock ruin_clock 0
scoreboard players set #neutralclock ruin_clock 0
scoreboard players set #epic ruin_random 0
scoreboard players set #legendary ruin_random 0

# v3.3 runtime objectives
scoreboard objectives add ruin_worldday dummy
scoreboard objectives add ruin_runtime dummy
scoreboard objectives add ruin_lives dummy

scoreboard objectives add ruin_mb_timer dummy
scoreboard objectives add ruin_variant_timer dummy
scoreboard objectives add ruin_boss_timer dummy
scoreboard objectives add ruin_relic_timer dummy
execute store result score #last_daytime ruin_day run time query day
