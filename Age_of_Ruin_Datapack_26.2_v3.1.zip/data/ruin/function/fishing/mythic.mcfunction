tellraw @a [{selector:'@s',color:'aqua'},{text:' has pulled a MYTHIC relic from the deep.',color:'light_purple',bold:true}]
playsound minecraft:entity.ender_dragon.growl master @a ~ ~ ~ 0.7 1.4
execute store result score @s ruin_random run random value 1..6
execute if score @s ruin_random matches 1 run give @s minecraft:fishing_rod[item_name={text:'Rod of the Drowned King',color:'light_purple',bold:true,italic:false},item_model='ruin:drowned_king_rod',enchantments={luck_of_the_sea:255,lure:200,unbreaking:255,mending:255}] 1
execute if score @s ruin_random matches 2 run give @s minecraft:trident[item_name={text:"Poseidon's Wrath",color:'light_purple',bold:true,italic:false},item_model='ruin:poseidons_wrath',enchantments={impaling:255,loyalty:100,channeling:255,unbreaking:200,mending:100}] 1
execute if score @s ruin_random matches 3 run give @s minecraft:netherite_sword[item_name={text:"Ocean's End",color:'light_purple',bold:true,italic:false},item_model='ruin:oceans_end',enchantments={sharpness:180,looting:120,sweeping_edge:100,unbreaking:200,mending:100}] 1
execute if score @s ruin_random matches 4 run give @s minecraft:netherite_helmet[item_name={text:'Abyss Crown',color:'light_purple',bold:true,italic:false},item_model='ruin:abyss_crown',enchantments={protection:150,respiration:120,aqua_affinity:100,thorns:80,unbreaking:180,mending:100}] 1
execute if score @s ruin_random matches 5 run give @s minecraft:netherite_spear[item_name={text:'The Final Catch',color:'light_purple',bold:true,italic:false},enchantments={sharpness:255,lunge:120,fire_aspect:80,looting:100,unbreaking:220,mending:100}] 1
execute if score @s ruin_random matches 6 run give @s minecraft:enchanted_book[stored_enchantments={luck_of_the_sea:255}] 1
