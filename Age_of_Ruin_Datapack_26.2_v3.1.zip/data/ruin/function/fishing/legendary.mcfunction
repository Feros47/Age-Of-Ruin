tellraw @s {text:'LEGENDARY CATCH!',color:'gold',bold:true}
playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 1 1.1
execute store result score @s ruin_random run random value 1..8
execute if score @s ruin_random matches 1 run give @s minecraft:netherite_spear[item_name={text:'Abyssal Harpoon',color:'gold',italic:false},item_model='ruin:abyssal_harpoon',enchantments={sharpness:45,lunge:25,unbreaking:60,mending:1}] 1
execute if score @s ruin_random matches 2 run give @s minecraft:bow[item_name={text:'Tideglass Bow',color:'gold',italic:false},item_model='ruin:tideglass_bow',enchantments={power:55,punch:15,infinity:1,unbreaking:60}] 1
execute if score @s ruin_random matches 3 run give @s minecraft:netherite_chestplate[item_name={text:'Leviathan Plate',color:'gold',italic:false},item_model='ruin:leviathan_plate',enchantments={protection:45,thorns:20,unbreaking:60,mending:1}] 1
execute if score @s ruin_random matches 4 run give @s minecraft:fishing_rod[item_name={text:'Pearl Rod',color:'gold',italic:false},item_model='ruin:pearl_rod',enchantments={luck_of_the_sea:70,lure:60,unbreaking:70,mending:1}] 1
execute if score @s ruin_random matches 5 run give @s minecraft:trident[item_name={text:'Stormhook',color:'gold',italic:false},enchantments={impaling:60,loyalty:25,channeling:1,unbreaking:60,mending:1}] 1
execute if score @s ruin_random matches 6 run give @s minecraft:netherite_boots[item_name={text:'Deepwalker Boots',color:'gold',italic:false},enchantments={protection:40,depth_strider:40,feather_falling:30,soul_speed:20,unbreaking:60}] 1
execute if score @s ruin_random matches 7 run give @s minecraft:enchanted_book[stored_enchantments={luck_of_the_sea:80}] 1
execute if score @s ruin_random matches 8 run give @s minecraft:enchanted_book[stored_enchantments={mending:40}] 1
