revoke @s only ruin:legendary_fishing
scoreboard players set @s ruin_luck 0
execute store result score @s ruin_luck run data get entity @s SelectedItem.components."minecraft:enchantments"."minecraft:luck_of_the_sea"
execute unless score @s ruin_luck matches 10.. run return 0
execute store result score @s ruin_random run random value 1..100000
scoreboard players set #mythic_fish ruin_tmp 0
scoreboard players set #legend_fish ruin_tmp 50
execute if score @s ruin_luck matches 25..49 run scoreboard players set #mythic_fish ruin_tmp 5
execute if score @s ruin_luck matches 25..49 run scoreboard players set #legend_fish ruin_tmp 150
execute if score @s ruin_luck matches 50..99 run scoreboard players set #mythic_fish ruin_tmp 20
execute if score @s ruin_luck matches 50..99 run scoreboard players set #legend_fish ruin_tmp 400
execute if score @s ruin_luck matches 100..149 run scoreboard players set #mythic_fish ruin_tmp 80
execute if score @s ruin_luck matches 100..149 run scoreboard players set #legend_fish ruin_tmp 1000
execute if score @s ruin_luck matches 150..199 run scoreboard players set #mythic_fish ruin_tmp 200
execute if score @s ruin_luck matches 150..199 run scoreboard players set #legend_fish ruin_tmp 2000
execute if score @s ruin_luck matches 200..254 run scoreboard players set #mythic_fish ruin_tmp 500
execute if score @s ruin_luck matches 200..254 run scoreboard players set #legend_fish ruin_tmp 4000
execute if score @s ruin_luck matches 255 run scoreboard players set #mythic_fish ruin_tmp 1250
execute if score @s ruin_luck matches 255 run scoreboard players set #legend_fish ruin_tmp 7500
execute if score @s ruin_random <= #mythic_fish ruin_tmp run function ruin:fishing/mythic
execute if score @s ruin_random <= #mythic_fish ruin_tmp run return 0
scoreboard players operation #legend_threshold ruin_tmp = #mythic_fish ruin_tmp
scoreboard players operation #legend_threshold ruin_tmp += #legend_fish ruin_tmp
execute if score @s ruin_random <= #legend_threshold ruin_tmp run function ruin:fishing/legendary
