give @s minecraft:amethyst_shard[custom_data={ruin_item:'soul_shard'},item_name={text:'Soul Shard',color:'aqua',italic:false},item_model='ruin:soul_shard',enchantment_glint_override=true] 64
give @s minecraft:echo_shard[custom_data={ruin_item:'greater_soul'},item_name={text:'Greater Soul',color:'blue',italic:false},item_model='ruin:greater_soul',enchantment_glint_override=true] 32
give @s minecraft:nether_star[custom_data={ruin_item:'ancient_soul'},item_name={text:'Ancient Soul',color:'light_purple',italic:false},item_model='ruin:ancient_soul',enchantment_glint_override=true] 16
