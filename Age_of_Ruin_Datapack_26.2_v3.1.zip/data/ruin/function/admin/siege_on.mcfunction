scoreboard players set #siege ruin_state 1
