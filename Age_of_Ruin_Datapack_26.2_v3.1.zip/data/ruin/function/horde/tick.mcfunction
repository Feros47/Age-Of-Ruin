scoreboard players remove #patrol_cd ruin_clock 1
execute if score #patrol_cd ruin_clock matches ..0 run scoreboard players set #patrol_cd ruin_clock 0
execute unless score #threat ruin_threat matches 30.. run return 0
execute unless score #daytime ruin_day matches 13000..23000 run return 0
execute unless score #patrol_cd ruin_clock matches 0 run return 0
execute store result score #patrol_roll ruin_random run random value 1..240
execute if score #patrol_roll ruin_random matches 1 run function ruin:horde/spawn
