scoreboard players set #patrol_cd ruin_clock 600
tellraw @a {text:'An Undead Patrol is roaming nearby.',color:'dark_gray'}
execute at @r run summon minecraft:zombie ~12 ~ ~2 {Tags:["ruin.patrol_new","ruin.patrol_commander","ruin.siege"]}
execute at @r run summon minecraft:zombie ~10 ~ ~6 {Tags:["ruin.patrol_new","ruin.patrol_armored","ruin.siege"]}
execute at @r run summon minecraft:zombie ~14 ~ ~-4 {Tags:["ruin.patrol_new","ruin.patrol_armored","ruin.siege"]}
execute at @r run summon minecraft:zombie ~-11 ~ ~4 {Tags:["ruin.patrol_new","ruin.patrol_armored","ruin.siege"]}
execute at @r run summon minecraft:skeleton ~-13 ~ ~-3 {Tags:["ruin.patrol_new"]}
execute at @r run summon minecraft:skeleton ~8 ~ ~-11 {Tags:["ruin.patrol_new"]}
execute at @r run summon minecraft:zombie ~-8 ~ ~-10 {Tags:["ruin.patrol_new","ruin.patrol_elite","ruin.siege"]}
execute as @e[tag=ruin.patrol_new] at @s run function ruin:mob/age_scale
execute as @e[tag=ruin.patrol_commander] run function ruin:affix/commander
execute as @e[tag=ruin.patrol_commander] run function ruin:affix/armored
execute as @e[tag=ruin.patrol_armored] run function ruin:affix/armored
execute as @e[tag=ruin.patrol_elite] run function ruin:mob/make_elite
execute as @e[tag=ruin.patrol_new] run function ruin:mob/finalize
tag @e[tag=ruin.patrol_new] remove ruin.patrol_new
