scoreboard players set #era ruin_state 1
execute if score #threat ruin_threat matches 6..15 run scoreboard players set #era ruin_state 2
execute if score #threat ruin_threat matches 16..30 run scoreboard players set #era ruin_state 3
execute if score #threat ruin_threat matches 31..50 run scoreboard players set #era ruin_state 4
execute if score #threat ruin_threat matches 51..75 run scoreboard players set #era ruin_state 5
execute if score #threat ruin_threat matches 76..100 run scoreboard players set #era ruin_state 6
execute if score #threat ruin_threat matches 101..150 run scoreboard players set #era ruin_state 7
execute if score #threat ruin_threat matches 151.. run scoreboard players set #era ruin_state 8
