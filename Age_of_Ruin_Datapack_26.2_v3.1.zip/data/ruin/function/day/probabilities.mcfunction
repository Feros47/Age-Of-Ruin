scoreboard players set #elite ruin_random 100
scoreboard players set #greater ruin_random 0
scoreboard players set #mini ruin_random 0
scoreboard players set #blood ruin_random 0
execute if score #threat ruin_threat matches 1..10 run function ruin:day/prob/elite_1
execute if score #threat ruin_threat matches 10..25 run function ruin:day/prob/elite_2
execute if score #threat ruin_threat matches 25..50 run function ruin:day/prob/elite_3
execute if score #threat ruin_threat matches 50..75 run function ruin:day/prob/elite_4
execute if score #threat ruin_threat matches 75..100 run function ruin:day/prob/elite_5
execute if score #threat ruin_threat matches 100..150 run function ruin:day/prob/elite_6
execute if score #threat ruin_threat matches 1..10 run function ruin:day/prob/greater_1
execute if score #threat ruin_threat matches 10..25 run function ruin:day/prob/greater_2
execute if score #threat ruin_threat matches 25..50 run function ruin:day/prob/greater_3
execute if score #threat ruin_threat matches 50..75 run function ruin:day/prob/greater_4
execute if score #threat ruin_threat matches 75..100 run function ruin:day/prob/greater_5
execute if score #threat ruin_threat matches 100..150 run function ruin:day/prob/greater_6
execute if score #threat ruin_threat matches 10..25 run function ruin:day/prob/mini_1
execute if score #threat ruin_threat matches 25..50 run function ruin:day/prob/mini_2
execute if score #threat ruin_threat matches 50..75 run function ruin:day/prob/mini_3
execute if score #threat ruin_threat matches 75..100 run function ruin:day/prob/mini_4
execute if score #threat ruin_threat matches 100..150 run function ruin:day/prob/mini_5
execute if score #threat ruin_threat matches 150..200 run function ruin:day/prob/mini_6
execute if score #threat ruin_threat matches 7..25 run function ruin:day/prob/blood_1
execute if score #threat ruin_threat matches 25..50 run function ruin:day/prob/blood_2
execute if score #threat ruin_threat matches 50..75 run function ruin:day/prob/blood_3
execute if score #threat ruin_threat matches 75..100 run function ruin:day/prob/blood_4
execute if score #threat ruin_threat matches 100..150 run function ruin:day/prob/blood_5
execute if score #threat ruin_threat matches 150..200 run function ruin:day/prob/blood_6
execute if score #threat ruin_threat matches 150.. run scoreboard players set #elite ruin_random 3500
execute if score #threat ruin_threat matches 150.. run scoreboard players set #greater ruin_random 1000
execute if score #threat ruin_threat matches 200.. run scoreboard players set #mini ruin_random 300
execute if score #threat ruin_threat matches 200.. run scoreboard players set #blood ruin_random 3000
