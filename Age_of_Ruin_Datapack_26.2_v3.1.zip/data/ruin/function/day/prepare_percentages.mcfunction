scoreboard players operation #elite_p ruin_tmp = #elite ruin_random
scoreboard players set #ten ruin_tmp 10
scoreboard players operation #elite_p ruin_tmp /= #ten ruin_tmp
scoreboard players operation #elite_d ruin_tmp = #elite_p ruin_tmp
scoreboard players operation #elite_d ruin_tmp %= #ten ruin_tmp
scoreboard players operation #elite_i ruin_tmp = #elite_p ruin_tmp
scoreboard players operation #elite_i ruin_tmp /= #ten ruin_tmp
scoreboard players operation #greater_p ruin_tmp = #greater ruin_random
scoreboard players set #ten ruin_tmp 10
scoreboard players operation #greater_p ruin_tmp /= #ten ruin_tmp
scoreboard players operation #greater_d ruin_tmp = #greater_p ruin_tmp
scoreboard players operation #greater_d ruin_tmp %= #ten ruin_tmp
scoreboard players operation #greater_i ruin_tmp = #greater_p ruin_tmp
scoreboard players operation #greater_i ruin_tmp /= #ten ruin_tmp
scoreboard players operation #mini_p ruin_tmp = #mini ruin_random
scoreboard players set #ten ruin_tmp 10
scoreboard players operation #mini_p ruin_tmp /= #ten ruin_tmp
scoreboard players operation #mini_d ruin_tmp = #mini_p ruin_tmp
scoreboard players operation #mini_d ruin_tmp %= #ten ruin_tmp
scoreboard players operation #mini_i ruin_tmp = #mini_p ruin_tmp
scoreboard players operation #mini_i ruin_tmp /= #ten ruin_tmp
scoreboard players operation #blood_p ruin_tmp = #blood ruin_random
scoreboard players set #ten ruin_tmp 10
scoreboard players operation #blood_p ruin_tmp /= #ten ruin_tmp
scoreboard players operation #blood_d ruin_tmp = #blood_p ruin_tmp
scoreboard players operation #blood_d ruin_tmp %= #ten ruin_tmp
scoreboard players operation #blood_i ruin_tmp = #blood_p ruin_tmp
scoreboard players operation #blood_i ruin_tmp /= #ten ruin_tmp
