scoreboard players operation #processed_day ruin_day = #day ruin_day
function ruin:day/recalculate
function ruin:day/set_era
scoreboard players set #bloodmoon ruin_state 0
scoreboard players set #event ruin_state 0
function ruin:event/roll_bloodmoon
execute unless score #bloodmoon ruin_state matches 1 run function ruin:event/roll_world
execute unless score #bloodmoon ruin_state matches 1 run function ruin:event/check_scheduled_invasion
function ruin:day/message
