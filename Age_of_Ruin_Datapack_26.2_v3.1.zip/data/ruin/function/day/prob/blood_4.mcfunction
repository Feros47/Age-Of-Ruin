scoreboard players operation #blood ruin_random = #threat ruin_threat
scoreboard players remove #blood ruin_random 75
scoreboard players set #k ruin_tmp 400
scoreboard players operation #blood ruin_random *= #k ruin_tmp
scoreboard players set #den ruin_tmp 25
scoreboard players operation #blood ruin_random /= #den ruin_tmp
scoreboard players add #blood ruin_random 1600
