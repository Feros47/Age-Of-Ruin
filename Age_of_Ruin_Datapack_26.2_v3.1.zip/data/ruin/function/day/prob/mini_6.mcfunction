scoreboard players operation #mini ruin_random = #threat ruin_threat
scoreboard players remove #mini ruin_random 150
scoreboard players set #k ruin_tmp 50
scoreboard players operation #mini ruin_random *= #k ruin_tmp
scoreboard players set #den ruin_tmp 50
scoreboard players operation #mini ruin_random /= #den ruin_tmp
scoreboard players add #mini ruin_random 250
