scoreboard players operation #elite ruin_random = #threat ruin_threat
scoreboard players remove #elite ruin_random 25
scoreboard players set #k ruin_tmp 600
scoreboard players operation #elite ruin_random *= #k ruin_tmp
scoreboard players set #den ruin_tmp 25
scoreboard players operation #elite ruin_random /= #den ruin_tmp
scoreboard players add #elite ruin_random 1000
