scoreboard players operation #blood ruin_random = #threat ruin_threat
scoreboard players remove #blood ruin_random 150
scoreboard players set #k ruin_tmp 500
scoreboard players operation #blood ruin_random *= #k ruin_tmp
scoreboard players set #den ruin_tmp 50
scoreboard players operation #blood ruin_random /= #den ruin_tmp
scoreboard players add #blood ruin_random 2500
