scoreboard players operation #greater ruin_random = #threat ruin_threat
scoreboard players remove #greater ruin_random 25
scoreboard players set #k ruin_tmp 200
scoreboard players operation #greater ruin_random *= #k ruin_tmp
scoreboard players set #den ruin_tmp 25
scoreboard players operation #greater ruin_random /= #den ruin_tmp
scoreboard players add #greater ruin_random 200
