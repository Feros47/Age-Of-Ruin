scoreboard players operation #threat ruin_threat = #day ruin_day
scoreboard players operation #threat ruin_threat += #corruption ruin_corrupt
function ruin:day/probabilities
scoreboard players operation #hp_bonus ruin_tmp = #threat ruin_threat
scoreboard players set #k ruin_tmp 15
scoreboard players operation #hp_bonus ruin_tmp *= #k ruin_tmp
scoreboard players set #ten ruin_tmp 10
scoreboard players operation #hp_bonus ruin_tmp /= #ten ruin_tmp
scoreboard players operation #dmg_bonus ruin_tmp = #threat ruin_threat
