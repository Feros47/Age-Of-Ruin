execute if score @s ruin_affixes matches 1.. run function ruin:affix/roll_one
execute if score @s ruin_affixes matches 2.. run function ruin:affix/roll_one
execute if score @s ruin_affixes matches 3.. run function ruin:affix/roll_one
execute if score @s ruin_affixes matches 4.. run function ruin:affix/roll_one
execute if score @s ruin_affixes matches 5.. run function ruin:affix/roll_one
