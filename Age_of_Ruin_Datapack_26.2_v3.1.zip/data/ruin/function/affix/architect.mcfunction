execute if entity @s[tag=ruin.affix_architect] run function ruin:affix/roll_one
execute if entity @s[tag=ruin.affix_architect] run return 0
tag @s add ruin.affix_architect
tag @s add ruin.architect
tag @s add ruin.siege
