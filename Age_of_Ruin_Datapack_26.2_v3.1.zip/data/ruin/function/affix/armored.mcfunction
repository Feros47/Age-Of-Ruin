execute if entity @s[tag=ruin.affix_armored] run function ruin:affix/roll_one
execute if entity @s[tag=ruin.affix_armored] run return 0
tag @s add ruin.affix_armored
attribute @s minecraft:armor modifier add ruin:affix_armored 12 add_value
attribute @s minecraft:armor_toughness modifier add ruin:affix_armored 4 add_value
