scoreboard players set @s ruin_timer 0
execute at @p[distance=..28] run summon minecraft:lightning_bolt ~ ~ ~
particle minecraft:electric_spark ~ ~1 ~ 0.6 1 0.6 0.2 20 force
