execute if entity @s[tag=ruin.affix_swift] run function ruin:affix/roll_one
execute if entity @s[tag=ruin.affix_swift] run return 0
tag @s add ruin.affix_swift
attribute @s minecraft:movement_speed modifier add ruin:affix_swift 0.45 add_multiplied_total
