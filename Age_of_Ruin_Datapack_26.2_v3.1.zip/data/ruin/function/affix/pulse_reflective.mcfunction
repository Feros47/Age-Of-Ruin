execute as @e[type=minecraft:arrow,distance=..1.8,limit=1] at @s run particle minecraft:enchanted_hit ~ ~ ~ 0.4 0.4 0.4 0.1 8 force
execute if entity @e[type=minecraft:arrow,distance=..1.8] run damage @p[distance=..24] 6 minecraft:indirect_magic
kill @e[type=minecraft:arrow,distance=..1.8,limit=1]
