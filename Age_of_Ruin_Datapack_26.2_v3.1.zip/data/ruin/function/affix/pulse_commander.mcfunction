scoreboard players set @s ruin_timer 0
effect give @e[type=#ruin:scalable_hostiles,distance=..10] minecraft:strength 4 1 true
effect give @e[type=#ruin:scalable_hostiles,distance=..10] minecraft:speed 4 0 true
effect give @e[type=#ruin:scalable_hostiles,distance=..10] minecraft:resistance 4 0 true
particle minecraft:enchanted_hit ~ ~1 ~ 1 1 1 0.1 15 force
