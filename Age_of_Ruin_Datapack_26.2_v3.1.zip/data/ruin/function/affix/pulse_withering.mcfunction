scoreboard players set @s ruin_timer 0
effect give @a[distance=..3] minecraft:wither 4 1 true
particle minecraft:soul ~ ~1 ~ 0.7 0.7 0.7 0.02 10 force
