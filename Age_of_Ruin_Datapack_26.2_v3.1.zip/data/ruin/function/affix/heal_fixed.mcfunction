execute store result score @s ruin_hpcur run data get entity @s Health 100
scoreboard players add @s ruin_hpcur 600
execute if score @s ruin_hpcur > @s ruin_maxhp run scoreboard players operation @s ruin_hpcur = @s ruin_maxhp
execute store result entity @s Health float 0.01 run scoreboard players get @s ruin_hpcur
