scoreboard players set @s ruin_timer 0
effect give @a[distance=..4] minecraft:slowness 5 2 true
damage @a[distance=..2.5] 3 minecraft:freeze
particle minecraft:snowflake ~ ~1 ~ 0.8 0.8 0.8 0.05 18 force
