execute if entity @s[tag=ruin.affix_frostbound] run function ruin:affix/roll_one
execute if entity @s[tag=ruin.affix_frostbound] run return 0
tag @s add ruin.affix_frostbound
