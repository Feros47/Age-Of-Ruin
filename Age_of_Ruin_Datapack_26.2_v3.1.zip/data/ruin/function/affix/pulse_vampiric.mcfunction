scoreboard players set @s ruin_timer 0
execute if entity @a[distance=..2.8] run damage @p[distance=..2.8] 4 minecraft:magic
execute if entity @a[distance=..2.8] run function ruin:affix/heal_fixed
particle minecraft:heart ~ ~1 ~ 0.3 0.5 0.3 0.05 4 force
