execute if entity @s[tag=ruin.affix_brutal] run function ruin:affix/roll_one
execute if entity @s[tag=ruin.affix_brutal] run return 0
tag @s add ruin.affix_brutal
attribute @s minecraft:attack_damage modifier add ruin:affix_brutal 0.6 add_multiplied_total
