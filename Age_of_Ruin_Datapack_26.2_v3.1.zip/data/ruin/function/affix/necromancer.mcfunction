execute if entity @s[tag=ruin.affix_necromancer] run function ruin:affix/roll_one
execute if entity @s[tag=ruin.affix_necromancer] run return 0
tag @s add ruin.affix_necromancer
