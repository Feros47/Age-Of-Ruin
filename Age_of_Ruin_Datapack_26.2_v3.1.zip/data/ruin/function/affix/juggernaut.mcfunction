execute if entity @s[tag=ruin.affix_juggernaut] run function ruin:affix/roll_one
execute if entity @s[tag=ruin.affix_juggernaut] run return 0
tag @s add ruin.affix_juggernaut
attribute @s minecraft:max_health modifier add ruin:affix_juggernaut 1.0 add_multiplied_total
attribute @s minecraft:max_absorption modifier add ruin:affix_juggernaut 200 add_value
attribute @s minecraft:knockback_resistance modifier add ruin:affix_juggernaut 1 add_value
attribute @s minecraft:movement_speed modifier add ruin:affix_juggernaut -0.18 add_multiplied_total
