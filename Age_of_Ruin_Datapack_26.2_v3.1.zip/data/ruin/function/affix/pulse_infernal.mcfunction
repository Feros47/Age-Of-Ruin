scoreboard players set @s ruin_timer 0
damage @a[distance=..2.8] 4 minecraft:on_fire
execute if block ~ ~-1 ~ #minecraft:fire_igniter run setblock ~ ~ ~ minecraft:fire keep
particle minecraft:flame ~ ~0.5 ~ 0.6 0.2 0.6 0.03 12 force
