scoreboard players set @s ruin_timer 0
execute if entity @p[distance=..3] run damage @p[distance=..3] 5 minecraft:magic
execute if entity @p[distance=..3] run effect give @s minecraft:absorption 5 2 true
effect clear @p[distance=..3] minecraft:absorption
