execute if entity @s[tag=ruin.affix_blinking] run function ruin:affix/roll_one
execute if entity @s[tag=ruin.affix_blinking] run return 0
tag @s add ruin.affix_blinking
