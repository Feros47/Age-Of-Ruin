execute if entity @s[tag=ruin.affix_regenerating] run function ruin:affix/roll_one
execute if entity @s[tag=ruin.affix_regenerating] run return 0
tag @s add ruin.affix_regenerating
