execute if entity @s[tag=ruin.affix_infernal] run function ruin:affix/roll_one
execute if entity @s[tag=ruin.affix_infernal] run return 0
tag @s add ruin.affix_infernal
effect give @s minecraft:fire_resistance infinite 0 true
