execute store result score @s ruin_hpcur run data get entity @s Health 100
scoreboard players operation @s ruin_tmp = @s ruin_maxhp
scoreboard players set #k ruin_tmp 3
scoreboard players operation @s ruin_tmp *= #k ruin_tmp
scoreboard players set #ten ruin_tmp 10
scoreboard players operation @s ruin_tmp /= #ten ruin_tmp
execute if score @s ruin_hpcur <= @s ruin_tmp run effect give @s minecraft:strength 2 4 true
execute if score @s ruin_hpcur <= @s ruin_tmp run effect give @s minecraft:speed 2 2 true
