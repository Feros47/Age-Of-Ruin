execute if entity @s[tag=ruin.affix_hexed] run function ruin:affix/roll_one
execute if entity @s[tag=ruin.affix_hexed] run return 0
tag @s add ruin.affix_hexed
