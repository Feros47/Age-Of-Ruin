execute if entity @s[tag=ruin.affix_vampiric] run function ruin:affix/roll_one
execute if entity @s[tag=ruin.affix_vampiric] run return 0
tag @s add ruin.affix_vampiric
