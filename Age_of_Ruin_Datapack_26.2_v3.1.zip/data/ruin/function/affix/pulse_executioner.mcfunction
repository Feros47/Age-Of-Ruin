execute as @a[distance=..4] store result score @s ruin_hpcur run data get entity @s Health 100
execute as @a[distance=..4] store result score @s ruin_tmp run attribute @s minecraft:max_health get 30
execute as @a[distance=..4] if score @s ruin_hpcur <= @s ruin_tmp run damage @s 8 minecraft:mob_attack
