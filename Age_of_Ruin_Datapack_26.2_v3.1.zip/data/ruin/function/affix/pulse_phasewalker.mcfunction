scoreboard players set @s ruin_timer 0
effect give @s minecraft:resistance 1 4 true
execute if entity @p[distance=3..20] run tp @s ^-3 ^ ^2 facing entity @p eyes
particle minecraft:reverse_portal ~ ~1 ~ 0.8 1 0.8 0.2 25 force
