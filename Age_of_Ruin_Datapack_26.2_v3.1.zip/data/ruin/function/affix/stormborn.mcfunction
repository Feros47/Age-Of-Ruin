execute if entity @s[tag=ruin.affix_stormborn] run function ruin:affix/roll_one
execute if entity @s[tag=ruin.affix_stormborn] run return 0
tag @s add ruin.affix_stormborn
