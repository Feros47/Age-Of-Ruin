execute if entity @s[tag=ruin.affix_phasewalker] run function ruin:affix/roll_one
execute if entity @s[tag=ruin.affix_phasewalker] run return 0
tag @s add ruin.affix_phasewalker
