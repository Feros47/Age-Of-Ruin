scoreboard players set @s ruin_timer 0
function ruin:affix/heal_fixed
particle minecraft:happy_villager ~ ~1 ~ 0.3 0.5 0.3 0.02 5 force
