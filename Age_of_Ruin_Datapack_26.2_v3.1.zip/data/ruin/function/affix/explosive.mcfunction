execute if entity @s[tag=ruin.affix_explosive] run function ruin:affix/roll_one
execute if entity @s[tag=ruin.affix_explosive] run return 0
tag @s add ruin.affix_explosive
