scoreboard players set #fastclock ruin_clock 0
function ruin:relic/voidpiercer_tick
execute as @e[type=minecraft:arrow,tag=ruin.necrotic_arrow] at @s if entity @a[distance=..1.5] run effect give @a[distance=..1.5,limit=1] minecraft:wither 4 1 true
execute as @e[type=minecraft:arrow,tag=ruin.storm_arrow] at @s if entity @a[distance=..1.5] run summon minecraft:lightning_bolt ~ ~ ~
