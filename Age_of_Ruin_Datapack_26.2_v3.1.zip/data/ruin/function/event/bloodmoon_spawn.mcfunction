execute store result score @s ruin_random run random value 1..5
execute if score @s ruin_random matches 1 run summon minecraft:zombie ~14 ~ ~8 {Tags:["ruin.blood_spawn","ruin.siege"]}
execute if score @s ruin_random matches 2 run summon minecraft:skeleton ~-12 ~ ~10 {Tags:["ruin.blood_spawn"]}
execute if score @s ruin_random matches 3 run summon minecraft:spider ~10 ~ ~-14 {Tags:["ruin.blood_spawn"]}
execute if score @s ruin_random matches 4 run summon minecraft:creeper ~-14 ~ ~-8 {Tags:["ruin.blood_spawn"]}
execute if score @s ruin_random matches 5 run summon minecraft:husk ~16 ~ ~0 {Tags:["ruin.blood_spawn","ruin.siege"]}
