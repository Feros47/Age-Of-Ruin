execute if score #bloodmoon ruin_state matches 1 if score #daytime ruin_day matches 13000..23000 unless score #bloodmoon_live ruin_state matches 1 run function ruin:event/bloodmoon_start
execute if score #bloodmoon_live ruin_state matches 1 run scoreboard players add #blood_timer ruin_clock 1
execute if score #bloodmoon_live ruin_state matches 1 if score #blood_timer ruin_clock matches 10.. run function ruin:event/bloodmoon_pulse
execute if score #bloodmoon_live ruin_state matches 1 unless score #daytime ruin_day matches 13000..23000 run function ruin:event/bloodmoon_end
execute if score #event ruin_state matches 1.. if score #daytime ruin_day matches 13000..23000 unless score #event_live ruin_state matches 1 run function ruin:event/start
execute if score #event_live ruin_state matches 1 run scoreboard players add #event_timer ruin_clock 1
execute if score #event_live ruin_state matches 1 run function ruin:event/live
execute if score #event_live ruin_state matches 1 unless score #daytime ruin_day matches 13000..23000 run function ruin:event/end
