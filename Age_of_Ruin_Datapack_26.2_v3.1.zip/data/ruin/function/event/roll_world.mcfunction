scoreboard players operation #since ruin_tmp = #day ruin_day
scoreboard players operation #since ruin_tmp -= #event_last ruin_day
execute if score #since ruin_tmp matches ..2 run return 0
execute store result score #roll ruin_random run random value 1..100
execute if score #since ruin_tmp matches 7.. run scoreboard players set #roll ruin_random 1
execute unless score #roll ruin_random matches ..35 run return 0
execute store result score #event ruin_state run random value 1..9
scoreboard players operation #event_last ruin_day = #day ruin_day
