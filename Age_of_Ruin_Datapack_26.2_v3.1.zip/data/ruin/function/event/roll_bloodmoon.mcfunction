scoreboard players operation #since ruin_tmp = #day ruin_day
scoreboard players operation #since ruin_tmp -= #last_blood ruin_day
execute if score #since ruin_tmp matches ..6 run return 0
execute if score #since ruin_tmp matches 12.. run scoreboard players set #bloodmoon ruin_state 1
execute if score #since ruin_tmp matches 12.. run scoreboard players operation #last_blood ruin_day = #day ruin_day
execute if score #since ruin_tmp matches 12.. run return 0
execute store result score #roll ruin_random run random value 1..10000
execute if score #roll ruin_random <= #blood ruin_random run scoreboard players set #bloodmoon ruin_state 1
execute if score #bloodmoon ruin_state matches 1 run scoreboard players operation #last_blood ruin_day = #day ruin_day
