execute unless score #day ruin_day >= #next_invasion ruin_day run return 0
scoreboard players set #event ruin_state 1
execute store result score #gap ruin_tmp run random value 10..20
scoreboard players operation #next_invasion ruin_day = #day ruin_day
scoreboard players operation #next_invasion ruin_day += #gap ruin_tmp
