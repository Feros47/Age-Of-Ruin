execute if score #event ruin_state matches 1 run function ruin:event/invasion_tick
execute if score #event ruin_state matches 3 if score #event_timer ruin_clock matches 30.. run function ruin:event/nether_pulse
execute if score #event ruin_state matches 4 run effect give @a minecraft:darkness 3 0 true
execute if score #event ruin_state matches 4 run effect give @e[type=#ruin:scalable_hostiles] minecraft:strength 3 1 true
execute if score #event ruin_state matches 5 if score #event_timer ruin_clock matches 20.. run function ruin:event/storm_pulse
execute if score #event ruin_state matches 6 run effect give @e[type=#ruin:zombie_family] minecraft:regeneration 3 0 true
execute if score #event ruin_state matches 7 if score #event_timer ruin_clock matches 15.. run function ruin:event/endstorm_pulse
execute if score #event ruin_state matches 9 run effect give @a minecraft:luck 3 1 true
