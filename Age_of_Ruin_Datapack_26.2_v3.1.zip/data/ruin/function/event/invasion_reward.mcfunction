scoreboard players set #event_live ruin_state 0
scoreboard players set #event ruin_state 0
scoreboard players set #event_wave ruin_state 0
scoreboard players set #event_timer ruin_clock 0
give @a minecraft:amethyst_shard[custom_data={ruin_item:'soul_shard'},item_name={text:'Soul Shard',color:'aqua',italic:false},item_model='ruin:soul_shard',enchantment_glint_override=true] 16
give @a minecraft:echo_shard[custom_data={ruin_item:'greater_soul'},item_name={text:'Greater Soul',color:'blue',italic:false},item_model='ruin:greater_soul',enchantment_glint_override=true] 4
give @a minecraft:nether_star[custom_data={ruin_item:'ancient_soul'},item_name={text:'Ancient Soul',color:'light_purple',italic:false},item_model='ruin:ancient_soul',enchantment_glint_override=true] 1
tellraw @a [{text:'INVASION REPELLED',color:'gold',bold:true},{text:' - the survivors are rewarded.',color:'gray'}]
