execute if score #event_wave ruin_state matches 1 if score #event_timer ruin_clock matches 600.. run function ruin:event/invasion_wave2
execute if score #event_wave ruin_state matches 2 if score #event_timer ruin_clock matches 1200.. run function ruin:event/invasion_wave3
execute if score #event_wave ruin_state matches 3 unless entity @e[tag=ruin.invasion_boss] run function ruin:event/invasion_reward
