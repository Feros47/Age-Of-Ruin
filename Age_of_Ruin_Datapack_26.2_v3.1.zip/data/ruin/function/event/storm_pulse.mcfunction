scoreboard players set #event_timer ruin_clock 0
execute at @r run summon minecraft:lightning_bolt ~ ~ ~
execute at @r run summon minecraft:breeze ~4 ~ ~ {Tags:["ruin.event_spawn","ruin.storm_spawn"]}
execute as @e[tag=ruin.storm_spawn,tag=!ruin.affix_stormborn] run function ruin:affix/stormborn
