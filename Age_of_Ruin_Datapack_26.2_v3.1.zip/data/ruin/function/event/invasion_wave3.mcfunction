scoreboard players set #event_wave ruin_state 3
tellraw @a {text:'Wave III - The Dread Marshal has arrived.',color:'dark_red',bold:true}
execute at @r run function ruin:miniboss/spawn_dread_marshal_invasion
