scoreboard players set #bloodmoon_live ruin_state 0
scoreboard players set #blood_timer ruin_clock 0
gamerule playersSleepingPercentage 100
tellraw @a [{text:'The Blood Moon recedes.',color:'gray'},{text:' For now.',color:'dark_red'}]
