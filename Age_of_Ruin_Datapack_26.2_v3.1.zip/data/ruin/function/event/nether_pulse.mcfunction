scoreboard players set #event_timer ruin_clock 0
execute at @r run summon minecraft:blaze ~5 ~2 ~ {Tags:["ruin.event_spawn"]}
execute at @r run summon minecraft:magma_cube ~-5 ~ ~ {Size:3,Tags:["ruin.event_spawn"]}
execute at @r run summon minecraft:piglin_brute ~ ~ ~6 {Tags:["ruin.event_spawn"]}
