scoreboard players set #blood_timer ruin_clock 0
execute as @a at @s run function ruin:event/bloodmoon_spawn
