scoreboard players set #event_wave ruin_state 2
tellraw @a {text:'Wave II - Elites and a commander breach the walls.',color:'dark_red'}
execute at @r run summon minecraft:zombie ~6 ~ ~0 {Tags:["ruin.initialized","ruin.elite","ruin.siege","ruin.invasion"],CustomName:{text:'Invasion Elite',color:'green'},CustomNameVisible:1b}
execute as @e[tag=ruin.invasion,tag=ruin.elite,tag=!ruin.invasion_affixed,limit=1,sort=nearest] run tag @s add ruin.invasion_affixed
execute as @e[tag=ruin.invasion_affixed,tag=!ruin.affix_commander,limit=1,sort=nearest] run function ruin:affix/roll_one
execute at @r run summon minecraft:zombie ~8 ~ ~4 {Tags:["ruin.initialized","ruin.elite","ruin.siege","ruin.invasion"],CustomName:{text:'Invasion Elite',color:'green'},CustomNameVisible:1b}
execute as @e[tag=ruin.invasion,tag=ruin.elite,tag=!ruin.invasion_affixed,limit=1,sort=nearest] run tag @s add ruin.invasion_affixed
execute as @e[tag=ruin.invasion_affixed,tag=!ruin.affix_commander,limit=1,sort=nearest] run function ruin:affix/roll_one
execute at @r run summon minecraft:zombie ~-6 ~ ~1 {Tags:["ruin.initialized","ruin.elite","ruin.siege","ruin.invasion"],CustomName:{text:'Invasion Elite',color:'green'},CustomNameVisible:1b}
execute as @e[tag=ruin.invasion,tag=ruin.elite,tag=!ruin.invasion_affixed,limit=1,sort=nearest] run tag @s add ruin.invasion_affixed
execute as @e[tag=ruin.invasion_affixed,tag=!ruin.affix_commander,limit=1,sort=nearest] run function ruin:affix/roll_one
execute at @r run summon minecraft:zombie ~-8 ~ ~-3 {Tags:["ruin.initialized","ruin.elite","ruin.siege","ruin.invasion"],CustomName:{text:'Invasion Elite',color:'green'},CustomNameVisible:1b}
execute as @e[tag=ruin.invasion,tag=ruin.elite,tag=!ruin.invasion_affixed,limit=1,sort=nearest] run tag @s add ruin.invasion_affixed
execute as @e[tag=ruin.invasion_affixed,tag=!ruin.affix_commander,limit=1,sort=nearest] run function ruin:affix/roll_one
execute at @r run summon minecraft:zombie ~4 ~ ~7 {Tags:["ruin.initialized","ruin.elite","ruin.siege","ruin.invasion"],CustomName:{text:'Invasion Elite',color:'green'},CustomNameVisible:1b}
execute as @e[tag=ruin.invasion,tag=ruin.elite,tag=!ruin.invasion_affixed,limit=1,sort=nearest] run tag @s add ruin.invasion_affixed
execute as @e[tag=ruin.invasion_affixed,tag=!ruin.affix_commander,limit=1,sort=nearest] run function ruin:affix/roll_one
execute at @r run summon minecraft:zombie ~-4 ~ ~8 {Tags:["ruin.initialized","ruin.elite","ruin.siege","ruin.invasion"],CustomName:{text:'Invasion Elite',color:'green'},CustomNameVisible:1b}
execute as @e[tag=ruin.invasion,tag=ruin.elite,tag=!ruin.invasion_affixed,limit=1,sort=nearest] run tag @s add ruin.invasion_affixed
execute as @e[tag=ruin.invasion_affixed,tag=!ruin.affix_commander,limit=1,sort=nearest] run function ruin:affix/roll_one
execute at @r run summon minecraft:zombie ~7 ~ ~-6 {Tags:["ruin.initialized","ruin.elite","ruin.siege","ruin.invasion"],CustomName:{text:'Invasion Elite',color:'green'},CustomNameVisible:1b}
execute as @e[tag=ruin.invasion,tag=ruin.elite,tag=!ruin.invasion_affixed,limit=1,sort=nearest] run tag @s add ruin.invasion_affixed
execute as @e[tag=ruin.invasion_affixed,tag=!ruin.affix_commander,limit=1,sort=nearest] run function ruin:affix/roll_one
execute at @r run summon minecraft:zombie ~-7 ~ ~-7 {Tags:["ruin.initialized","ruin.elite","ruin.siege","ruin.invasion"],CustomName:{text:'Invasion Elite',color:'green'},CustomNameVisible:1b}
execute as @e[tag=ruin.invasion,tag=ruin.elite,tag=!ruin.invasion_affixed,limit=1,sort=nearest] run tag @s add ruin.invasion_affixed
execute as @e[tag=ruin.invasion_affixed,tag=!ruin.affix_commander,limit=1,sort=nearest] run function ruin:affix/roll_one
execute at @r run summon minecraft:zombie ~ ~ ~10 {Tags:["ruin.initialized","ruin.elite","ruin.siege","ruin.invasion","ruin.invasion_commander"],CustomName:{text:'Undead Commander',color:'gold',bold:true},CustomNameVisible:1b,PersistenceRequired:1b}
execute as @e[tag=ruin.invasion_commander,limit=1,sort=nearest] run function ruin:affix/commander
