scoreboard players set #event_timer ruin_clock 0
execute at @r run summon minecraft:enderman ~4 ~ ~ {Tags:["ruin.event_spawn"]}
execute at @r run summon minecraft:endermite ~-3 ~ ~ {Tags:["ruin.event_spawn"]}
