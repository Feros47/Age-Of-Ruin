scoreboard players set #active_warden_king ruin_state 0
bossbar remove ruin:warden_king
scoreboard players add #corruption ruin_corrupt 5
function ruin:day/recalculate
tellraw @a [{text:'THE WARDEN KING DEFEATED',color:'gold',bold:true},{text:'  |  World Threat +5',color:'red'}]
