summon minecraft:enderman ~ ~2 ~ {Tags:["ruin.initialized","ruin.boss","ruin.boss_void_emperor","ruin.current_boss","ruin.siege"],CustomName:{text:'THE VOID EMPEROR',color:'light_purple',bold:true},CustomNameVisible:1b,PersistenceRequired:1b,CanPickUpLoot:0b}
execute as @e[tag=ruin.boss_void_emperor,limit=1,sort=nearest] at @s run function ruin:boss/scale_void_emperor
execute as @e[tag=ruin.boss_void_emperor,limit=1,sort=nearest] run item replace entity @s weapon.offhand with minecraft:bow[custom_data={ruin_relic:'voidpiercer'},item_name={text:'Voidpiercer',color:'light_purple',italic:false},item_model='ruin:voidpiercer',enchantments={power:18,punch:4,infinity:1,unbreaking:10}] 1
execute as @e[tag=ruin.boss_void_emperor,limit=1,sort=nearest] run data merge entity @s {drop_chances:{offhand:1.0f}}
execute as @e[tag=ruin.boss_void_emperor,limit=1,sort=nearest] run function ruin:affix/phasewalker
execute as @e[tag=ruin.boss_void_emperor,limit=1,sort=nearest] run function ruin:affix/blinking
execute as @e[tag=ruin.boss_void_emperor,limit=1,sort=nearest] run function ruin:affix/reflective
execute as @e[tag=ruin.boss_void_emperor,limit=1,sort=nearest] run function ruin:affix/leeching
execute as @e[tag=ruin.boss_void_emperor,limit=1,sort=nearest] run function ruin:boss/finalize_pool
scoreboard players set #active_void_emperor ruin_state 1
bossbar remove ruin:void_emperor
bossbar add ruin:void_emperor {text:'THE VOID EMPEROR',color:'light_purple',bold:true}
execute store result bossbar ruin:void_emperor max run scoreboard players get @e[tag=ruin.boss_void_emperor,limit=1,sort=nearest] ruin_basehp
bossbar set ruin:void_emperor players @a
title @a title {text:'THE VOID EMPEROR',color:'light_purple',bold:true}
playsound minecraft:entity.wither.spawn master @a ~ ~ ~ 0.9 0.7
execute as @e[tag=ruin.current_boss] run tag @s remove ruin.current_boss
