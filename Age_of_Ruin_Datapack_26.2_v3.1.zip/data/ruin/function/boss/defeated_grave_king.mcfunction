scoreboard players set #active_grave_king ruin_state 0
bossbar remove ruin:grave_king
scoreboard players add #corruption ruin_corrupt 5
function ruin:day/recalculate
give @a[distance=..128] minecraft:nether_star[custom_data={ruin_item:'ancient_soul'},item_name={text:'Ancient Soul',color:'light_purple',italic:false},item_model='ruin:ancient_soul',enchantment_glint_override=true] 1
tellraw @a [{text:'THE GRAVE KING DEFEATED',color:'gold',bold:true},{text:'  |  World Threat +5',color:'red'}]
