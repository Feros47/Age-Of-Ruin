scoreboard players set @s ruin_level 2
title @a title {text:'THE END AWAKENS',color:'light_purple',bold:true}
