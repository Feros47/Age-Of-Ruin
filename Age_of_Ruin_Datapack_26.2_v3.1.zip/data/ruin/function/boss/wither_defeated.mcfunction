scoreboard players set #wither_active ruin_state 0
execute if score #wither_defeated ruin_state matches 1 run return 0
scoreboard players set #wither_defeated ruin_state 1
scoreboard players add #corruption ruin_corrupt 5
function ruin:day/recalculate
give @a minecraft:wither_rose[custom_data={ruin_item:'heart_of_extinction'},item_name={text:'Heart of Extinction',color:'dark_red',italic:false},item_model='ruin:heart_of_extinction',enchantment_glint_override=true] 1
give @a minecraft:nether_star[custom_data={ruin_item:'ancient_soul'},item_name={text:'Ancient Soul',color:'light_purple',italic:false},item_model='ruin:ancient_soul',enchantment_glint_override=true] 6
tellraw @a [{text:'THE HARBINGER OF EXTINCTION HAS FALLEN',color:'dark_red',bold:true},{text:'  |  Threat +5',color:'red'}]
