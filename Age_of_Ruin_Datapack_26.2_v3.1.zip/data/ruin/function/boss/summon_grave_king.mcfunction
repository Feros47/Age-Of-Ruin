summon minecraft:wither_skeleton ~ ~2 ~ {Tags:["ruin.initialized","ruin.boss","ruin.boss_grave_king","ruin.current_boss","ruin.siege"],CustomName:{text:'THE GRAVE KING',color:'dark_red',bold:true},CustomNameVisible:1b,PersistenceRequired:1b,CanPickUpLoot:0b}
execute as @e[tag=ruin.boss_grave_king,limit=1,sort=nearest] at @s run function ruin:boss/scale_grave_king
execute as @e[tag=ruin.boss_grave_king,limit=1,sort=nearest] run item replace entity @s weapon.offhand with minecraft:netherite_sword[custom_data={ruin_relic:'gravecaller'},item_name={text:'Gravecaller',color:'gray',italic:false},item_model='ruin:gravecaller',enchantments={sharpness:8,unbreaking:8,looting:5}] 1
execute as @e[tag=ruin.boss_grave_king,limit=1,sort=nearest] run data merge entity @s {drop_chances:{offhand:1.0f}}
execute as @e[tag=ruin.boss_grave_king,limit=1,sort=nearest] run function ruin:affix/armored
execute as @e[tag=ruin.boss_grave_king,limit=1,sort=nearest] run function ruin:affix/brutal
execute as @e[tag=ruin.boss_grave_king,limit=1,sort=nearest] run function ruin:affix/necromancer
execute as @e[tag=ruin.boss_grave_king,limit=1,sort=nearest] run function ruin:affix/executioner
execute as @e[tag=ruin.boss_grave_king,limit=1,sort=nearest] run function ruin:boss/finalize_pool
scoreboard players set #active_grave_king ruin_state 1
bossbar remove ruin:grave_king
bossbar add ruin:grave_king {text:'THE GRAVE KING',color:'dark_red',bold:true}
execute store result bossbar ruin:grave_king max run scoreboard players get @e[tag=ruin.boss_grave_king,limit=1,sort=nearest] ruin_basehp
bossbar set ruin:grave_king players @a
title @a title {text:'THE GRAVE KING',color:'dark_red',bold:true}
playsound minecraft:entity.wither.spawn master @a ~ ~ ~ 0.9 0.7
execute as @e[tag=ruin.current_boss] run tag @s remove ruin.current_boss
