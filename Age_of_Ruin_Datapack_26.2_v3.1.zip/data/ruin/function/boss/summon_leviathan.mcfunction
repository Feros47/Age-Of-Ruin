summon minecraft:elder_guardian ~ ~2 ~ {Tags:["ruin.initialized","ruin.boss","ruin.boss_leviathan","ruin.current_boss","ruin.siege"],CustomName:{text:'THE LEVIATHAN',color:'aqua',bold:true},CustomNameVisible:1b,PersistenceRequired:1b,CanPickUpLoot:0b}
execute as @e[tag=ruin.boss_leviathan,limit=1,sort=nearest] at @s run function ruin:boss/scale_leviathan
execute as @e[tag=ruin.boss_leviathan,limit=1,sort=nearest] run item replace entity @s weapon.offhand with minecraft:trident[custom_data={ruin_relic:'leviathan'},item_name={text:'Tidebreaker',color:'aqua',italic:false},enchantments={impaling:10,loyalty:5,unbreaking:8}] 1
execute as @e[tag=ruin.boss_leviathan,limit=1,sort=nearest] run data merge entity @s {drop_chances:{offhand:1.0f}}
execute as @e[tag=ruin.boss_leviathan,limit=1,sort=nearest] run function ruin:affix/juggernaut
execute as @e[tag=ruin.boss_leviathan,limit=1,sort=nearest] run function ruin:affix/regenerating
execute as @e[tag=ruin.boss_leviathan,limit=1,sort=nearest] run function ruin:boss/finalize_pool
scoreboard players set #active_leviathan ruin_state 1
bossbar remove ruin:leviathan
bossbar add ruin:leviathan {text:'THE LEVIATHAN',color:'aqua',bold:true}
execute store result bossbar ruin:leviathan max run scoreboard players get @e[tag=ruin.boss_leviathan,limit=1,sort=nearest] ruin_basehp
bossbar set ruin:leviathan players @a
title @a title {text:'THE LEVIATHAN',color:'aqua',bold:true}
playsound minecraft:entity.wither.spawn master @a ~ ~ ~ 0.9 0.7
execute as @e[tag=ruin.current_boss] run tag @s remove ruin.current_boss
