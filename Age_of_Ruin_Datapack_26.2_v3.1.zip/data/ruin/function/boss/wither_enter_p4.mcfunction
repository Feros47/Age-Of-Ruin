scoreboard players set @s ruin_level 4
title @a title {text:'EXTINCTION PHASE',color:'red',bold:true}
