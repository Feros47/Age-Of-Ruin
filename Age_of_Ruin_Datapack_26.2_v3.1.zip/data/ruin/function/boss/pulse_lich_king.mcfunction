scoreboard players set @s ruin_timer 0
execute if entity @e[tag=ruin.lich_phylactery] run function ruin:affix/heal_fixed
execute if entity @e[tag=ruin.lich_phylactery] run effect give @s minecraft:resistance 3 2 true
summon minecraft:wither_skeleton ~3 ~ ~ {Tags:["ruin.initialized"]}
summon minecraft:skeleton ~-3 ~ ~ {Tags:["ruin.initialized"]}
effect give @a[distance=..12] minecraft:weakness 6 2 true
