scoreboard players set #active_infernal_behemoth ruin_state 0
bossbar remove ruin:infernal_behemoth
scoreboard players add #corruption ruin_corrupt 5
function ruin:day/recalculate
give @a[distance=..128] minecraft:slime_ball[custom_data={ruin_item:'plague_heart'},item_name={text:'Plague Heart',color:'green',italic:false},item_model='ruin:plague_heart',enchantment_glint_override=true] 1
tellraw @a [{text:'THE INFERNAL BEHEMOTH DEFEATED',color:'gold',bold:true},{text:'  |  World Threat +5',color:'red'}]
