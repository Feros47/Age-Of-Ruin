summon minecraft:evoker ~ ~2 ~ {Tags:["ruin.initialized","ruin.boss","ruin.boss_storm_herald","ruin.current_boss","ruin.siege"],CustomName:{text:'THE STORM HERALD',color:'aqua',bold:true},CustomNameVisible:1b,PersistenceRequired:1b,CanPickUpLoot:0b}
execute as @e[tag=ruin.boss_storm_herald,limit=1,sort=nearest] at @s run function ruin:boss/scale_storm_herald
execute as @e[tag=ruin.boss_storm_herald,limit=1,sort=nearest] run item replace entity @s weapon.offhand with minecraft:mace[custom_data={ruin_relic:'stormbreaker'},item_name={text:'Stormbreaker',color:'aqua',italic:false},item_model='ruin:stormbreaker',enchantments={density:8,breach:5,unbreaking:8}] 1
execute as @e[tag=ruin.boss_storm_herald,limit=1,sort=nearest] run data merge entity @s {drop_chances:{offhand:1.0f}}
execute as @e[tag=ruin.boss_storm_herald,limit=1,sort=nearest] run function ruin:affix/stormborn
execute as @e[tag=ruin.boss_storm_herald,limit=1,sort=nearest] run function ruin:affix/blinking
execute as @e[tag=ruin.boss_storm_herald,limit=1,sort=nearest] run function ruin:affix/reflective
execute as @e[tag=ruin.boss_storm_herald,limit=1,sort=nearest] run function ruin:boss/finalize_pool
scoreboard players set #active_storm_herald ruin_state 1
bossbar remove ruin:storm_herald
bossbar add ruin:storm_herald {text:'THE STORM HERALD',color:'aqua',bold:true}
execute store result bossbar ruin:storm_herald max run scoreboard players get @e[tag=ruin.boss_storm_herald,limit=1,sort=nearest] ruin_basehp
bossbar set ruin:storm_herald players @a
title @a title {text:'THE STORM HERALD',color:'aqua',bold:true}
playsound minecraft:entity.wither.spawn master @a ~ ~ ~ 0.9 0.7
execute as @e[tag=ruin.current_boss] run tag @s remove ruin.current_boss
