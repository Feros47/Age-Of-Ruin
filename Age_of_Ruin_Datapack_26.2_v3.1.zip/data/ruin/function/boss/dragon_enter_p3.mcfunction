scoreboard players set @s ruin_level 3
title @a title {text:'THE WORLD EATER DESCENDS',color:'dark_purple',bold:true}
