scoreboard players set #active_lich_king ruin_state 0
bossbar remove ruin:lich_king
scoreboard players add #corruption ruin_corrupt 5
function ruin:day/recalculate
tellraw @a [{text:'THE LICH KING DEFEATED',color:'gold',bold:true},{text:'  |  World Threat +5',color:'red'}]
