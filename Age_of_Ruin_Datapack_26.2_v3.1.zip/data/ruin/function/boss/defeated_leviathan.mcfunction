scoreboard players set #active_leviathan ruin_state 0
bossbar remove ruin:leviathan
scoreboard players add #corruption ruin_corrupt 5
function ruin:day/recalculate
tellraw @a [{text:'THE LEVIATHAN DEFEATED',color:'gold',bold:true},{text:'  |  World Threat +5',color:'red'}]
