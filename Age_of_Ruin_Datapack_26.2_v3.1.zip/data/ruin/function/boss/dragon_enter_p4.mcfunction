scoreboard players set @s ruin_level 4
title @a title {text:'THE WORLD EATER ENRAGES',color:'dark_red',bold:true}
playsound minecraft:entity.ender_dragon.growl hostile @a ~ ~ ~ 1 0.5
