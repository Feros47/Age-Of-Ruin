execute store result score @s ruin_hpcur run data get entity @s Health 100
scoreboard players operation @s ruin_pct = @s ruin_hpcur
scoreboard players set #hundred ruin_tmp 100
scoreboard players operation @s ruin_pct *= #hundred ruin_tmp
scoreboard players operation @s ruin_pct /= @s ruin_maxhp
execute if score @s ruin_level matches 1 if score @s ruin_pct matches ..70 run function ruin:boss/wither_enter_p2
execute if score @s ruin_level matches 2 if score @s ruin_pct matches ..40 run function ruin:boss/wither_enter_p3
execute if score @s ruin_level matches 3 if score @s ruin_pct matches ..15 run function ruin:boss/wither_enter_p4
execute if score @s ruin_level matches 1 if score @s ruin_timer matches 6.. run function ruin:boss/wither_p1
execute if score @s ruin_level matches 2 if score @s ruin_timer matches 5.. run function ruin:boss/wither_p2
execute if score @s ruin_level matches 3 if score @s ruin_timer matches 4.. run function ruin:boss/wither_p3
execute if score @s ruin_level matches 4 if score @s ruin_timer matches 2.. run function ruin:boss/wither_p4
