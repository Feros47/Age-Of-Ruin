scoreboard players set @s ruin_timer 0
summon minecraft:blaze ~4 ~3 ~ {Tags:["ruin.initialized"]}
summon minecraft:magma_cube ~-4 ~ ~ {Size:4,Tags:["ruin.initialized"]}
particle minecraft:explosion ~ ~1 ~ 0 0 0 0 1 force
damage @a[distance=..8] 20 minecraft:explosion
damage @a[distance=..6] 10 minecraft:on_fire
