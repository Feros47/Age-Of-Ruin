scoreboard players set @s ruin_timer 0
effect give @a[distance=..160] minecraft:darkness 2 0 true
damage @a[distance=..160] 22 minecraft:dragon_breath
particle minecraft:dragon_breath ~ ~ ~ 6 3 6 0.15 80 force
