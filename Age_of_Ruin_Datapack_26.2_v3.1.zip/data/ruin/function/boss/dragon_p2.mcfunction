scoreboard players set @s ruin_timer 0
execute at @a[distance=..160] run summon minecraft:shulker ~-4 ~ ~ {Tags:["ruin.initialized"]}
execute at @a[distance=..160] run summon minecraft:enderman ~5 ~ ~ {Tags:["ruin.initialized"]}
effect give @a[distance=..160] minecraft:darkness 3 0 true
execute in minecraft:the_end positioned 0 82 0 run summon minecraft:end_crystal ~ ~ ~ {Invulnerable:0b}
damage @a[distance=..160] 12 minecraft:dragon_breath
