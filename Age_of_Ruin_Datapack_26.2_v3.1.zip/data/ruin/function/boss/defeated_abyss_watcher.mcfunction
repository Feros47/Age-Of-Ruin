scoreboard players set #active_abyss_watcher ruin_state 0
bossbar remove ruin:abyss_watcher
scoreboard players add #corruption ruin_corrupt 5
function ruin:day/recalculate
give @a[distance=..128] minecraft:echo_shard[custom_data={ruin_item:'abyssal_essence'},item_name={text:'Abyssal Essence',color:'dark_aqua',italic:false},item_model='ruin:abyssal_essence',enchantment_glint_override=true] 1
tellraw @a [{text:'THE ABYSS WATCHER DEFEATED',color:'gold',bold:true},{text:'  |  World Threat +5',color:'red'}]
