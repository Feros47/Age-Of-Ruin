scoreboard players set #bossclock ruin_clock 0
function ruin:boss/dragon
function ruin:boss/wither
execute as @e[tag=ruin.boss_grave_king,limit=1] store result score @s ruin_hpcur run data get entity @s Health 1
execute as @e[tag=ruin.boss_grave_king,limit=1] store result score @s ruin_tmp run data get entity @s AbsorptionAmount 1
execute as @e[tag=ruin.boss_grave_king,limit=1] run scoreboard players operation @s ruin_hpcur += @s ruin_tmp
execute if entity @e[tag=ruin.boss_grave_king] store result bossbar ruin:grave_king value run scoreboard players get @e[tag=ruin.boss_grave_king,limit=1] ruin_hpcur
execute as @e[tag=ruin.boss_grave_king] run scoreboard players add @s ruin_timer 1
execute as @e[tag=ruin.boss_grave_king,scores={ruin_timer=5..}] at @s run function ruin:boss/pulse_grave_king
execute if score #active_grave_king ruin_state matches 1 unless entity @e[tag=ruin.boss_grave_king] run function ruin:boss/defeated_grave_king
execute as @e[tag=ruin.boss_infernal_behemoth,limit=1] store result score @s ruin_hpcur run data get entity @s Health 1
execute as @e[tag=ruin.boss_infernal_behemoth,limit=1] store result score @s ruin_tmp run data get entity @s AbsorptionAmount 1
execute as @e[tag=ruin.boss_infernal_behemoth,limit=1] run scoreboard players operation @s ruin_hpcur += @s ruin_tmp
execute if entity @e[tag=ruin.boss_infernal_behemoth] store result bossbar ruin:infernal_behemoth value run scoreboard players get @e[tag=ruin.boss_infernal_behemoth,limit=1] ruin_hpcur
execute as @e[tag=ruin.boss_infernal_behemoth] run scoreboard players add @s ruin_timer 1
execute as @e[tag=ruin.boss_infernal_behemoth,scores={ruin_timer=5..}] at @s run function ruin:boss/pulse_infernal_behemoth
execute if score #active_infernal_behemoth ruin_state matches 1 unless entity @e[tag=ruin.boss_infernal_behemoth] run function ruin:boss/defeated_infernal_behemoth
execute as @e[tag=ruin.boss_abyss_watcher,limit=1] store result score @s ruin_hpcur run data get entity @s Health 1
execute as @e[tag=ruin.boss_abyss_watcher,limit=1] store result score @s ruin_tmp run data get entity @s AbsorptionAmount 1
execute as @e[tag=ruin.boss_abyss_watcher,limit=1] run scoreboard players operation @s ruin_hpcur += @s ruin_tmp
execute if entity @e[tag=ruin.boss_abyss_watcher] store result bossbar ruin:abyss_watcher value run scoreboard players get @e[tag=ruin.boss_abyss_watcher,limit=1] ruin_hpcur
execute as @e[tag=ruin.boss_abyss_watcher] run scoreboard players add @s ruin_timer 1
execute as @e[tag=ruin.boss_abyss_watcher,scores={ruin_timer=5..}] at @s run function ruin:boss/pulse_abyss_watcher
execute if score #active_abyss_watcher ruin_state matches 1 unless entity @e[tag=ruin.boss_abyss_watcher] run function ruin:boss/defeated_abyss_watcher
execute as @e[tag=ruin.boss_leviathan,limit=1] store result score @s ruin_hpcur run data get entity @s Health 1
execute as @e[tag=ruin.boss_leviathan,limit=1] store result score @s ruin_tmp run data get entity @s AbsorptionAmount 1
execute as @e[tag=ruin.boss_leviathan,limit=1] run scoreboard players operation @s ruin_hpcur += @s ruin_tmp
execute if entity @e[tag=ruin.boss_leviathan] store result bossbar ruin:leviathan value run scoreboard players get @e[tag=ruin.boss_leviathan,limit=1] ruin_hpcur
execute as @e[tag=ruin.boss_leviathan] run scoreboard players add @s ruin_timer 1
execute as @e[tag=ruin.boss_leviathan,scores={ruin_timer=6..}] at @s run function ruin:boss/pulse_leviathan
execute if score #active_leviathan ruin_state matches 1 unless entity @e[tag=ruin.boss_leviathan] run function ruin:boss/defeated_leviathan
execute as @e[tag=ruin.boss_ancient_colossus,limit=1] store result score @s ruin_hpcur run data get entity @s Health 1
execute as @e[tag=ruin.boss_ancient_colossus,limit=1] store result score @s ruin_tmp run data get entity @s AbsorptionAmount 1
execute as @e[tag=ruin.boss_ancient_colossus,limit=1] run scoreboard players operation @s ruin_hpcur += @s ruin_tmp
execute if entity @e[tag=ruin.boss_ancient_colossus] store result bossbar ruin:ancient_colossus value run scoreboard players get @e[tag=ruin.boss_ancient_colossus,limit=1] ruin_hpcur
execute as @e[tag=ruin.boss_ancient_colossus] run scoreboard players add @s ruin_timer 1
execute as @e[tag=ruin.boss_ancient_colossus,scores={ruin_timer=5..}] at @s run function ruin:boss/pulse_ancient_colossus
execute if score #active_ancient_colossus ruin_state matches 1 unless entity @e[tag=ruin.boss_ancient_colossus] run function ruin:boss/defeated_ancient_colossus
execute as @e[tag=ruin.boss_lich_king,limit=1] store result score @s ruin_hpcur run data get entity @s Health 1
execute as @e[tag=ruin.boss_lich_king,limit=1] store result score @s ruin_tmp run data get entity @s AbsorptionAmount 1
execute as @e[tag=ruin.boss_lich_king,limit=1] run scoreboard players operation @s ruin_hpcur += @s ruin_tmp
execute if entity @e[tag=ruin.boss_lich_king] store result bossbar ruin:lich_king value run scoreboard players get @e[tag=ruin.boss_lich_king,limit=1] ruin_hpcur
execute as @e[tag=ruin.boss_lich_king] run scoreboard players add @s ruin_timer 1
execute as @e[tag=ruin.boss_lich_king,scores={ruin_timer=5..}] at @s run function ruin:boss/pulse_lich_king
execute if score #active_lich_king ruin_state matches 1 unless entity @e[tag=ruin.boss_lich_king] run function ruin:boss/defeated_lich_king
execute as @e[tag=ruin.boss_infernal_titan,limit=1] store result score @s ruin_hpcur run data get entity @s Health 1
execute as @e[tag=ruin.boss_infernal_titan,limit=1] store result score @s ruin_tmp run data get entity @s AbsorptionAmount 1
execute as @e[tag=ruin.boss_infernal_titan,limit=1] run scoreboard players operation @s ruin_hpcur += @s ruin_tmp
execute if entity @e[tag=ruin.boss_infernal_titan] store result bossbar ruin:infernal_titan value run scoreboard players get @e[tag=ruin.boss_infernal_titan,limit=1] ruin_hpcur
execute as @e[tag=ruin.boss_infernal_titan] run scoreboard players add @s ruin_timer 1
execute as @e[tag=ruin.boss_infernal_titan,scores={ruin_timer=4..}] at @s run function ruin:boss/pulse_infernal_titan
execute if score #active_infernal_titan ruin_state matches 1 unless entity @e[tag=ruin.boss_infernal_titan] run function ruin:boss/defeated_infernal_titan
execute as @e[tag=ruin.boss_warden_king,limit=1] store result score @s ruin_hpcur run data get entity @s Health 1
execute as @e[tag=ruin.boss_warden_king,limit=1] store result score @s ruin_tmp run data get entity @s AbsorptionAmount 1
execute as @e[tag=ruin.boss_warden_king,limit=1] run scoreboard players operation @s ruin_hpcur += @s ruin_tmp
execute if entity @e[tag=ruin.boss_warden_king] store result bossbar ruin:warden_king value run scoreboard players get @e[tag=ruin.boss_warden_king,limit=1] ruin_hpcur
execute as @e[tag=ruin.boss_warden_king] run scoreboard players add @s ruin_timer 1
execute as @e[tag=ruin.boss_warden_king,scores={ruin_timer=4..}] at @s run function ruin:boss/pulse_warden_king
execute if score #active_warden_king ruin_state matches 1 unless entity @e[tag=ruin.boss_warden_king] run function ruin:boss/defeated_warden_king
execute as @e[tag=ruin.boss_storm_herald,limit=1] store result score @s ruin_hpcur run data get entity @s Health 1
execute as @e[tag=ruin.boss_storm_herald,limit=1] store result score @s ruin_tmp run data get entity @s AbsorptionAmount 1
execute as @e[tag=ruin.boss_storm_herald,limit=1] run scoreboard players operation @s ruin_hpcur += @s ruin_tmp
execute if entity @e[tag=ruin.boss_storm_herald] store result bossbar ruin:storm_herald value run scoreboard players get @e[tag=ruin.boss_storm_herald,limit=1] ruin_hpcur
execute as @e[tag=ruin.boss_storm_herald] run scoreboard players add @s ruin_timer 1
execute as @e[tag=ruin.boss_storm_herald,scores={ruin_timer=4..}] at @s run function ruin:boss/pulse_storm_herald
execute if score #active_storm_herald ruin_state matches 1 unless entity @e[tag=ruin.boss_storm_herald] run function ruin:boss/defeated_storm_herald
execute as @e[tag=ruin.boss_void_emperor,limit=1] store result score @s ruin_hpcur run data get entity @s Health 1
execute as @e[tag=ruin.boss_void_emperor,limit=1] store result score @s ruin_tmp run data get entity @s AbsorptionAmount 1
execute as @e[tag=ruin.boss_void_emperor,limit=1] run scoreboard players operation @s ruin_hpcur += @s ruin_tmp
execute if entity @e[tag=ruin.boss_void_emperor] store result bossbar ruin:void_emperor value run scoreboard players get @e[tag=ruin.boss_void_emperor,limit=1] ruin_hpcur
execute as @e[tag=ruin.boss_void_emperor] run scoreboard players add @s ruin_timer 1
execute as @e[tag=ruin.boss_void_emperor,scores={ruin_timer=4..}] at @s run function ruin:boss/pulse_void_emperor
execute if score #active_void_emperor ruin_state matches 1 unless entity @e[tag=ruin.boss_void_emperor] run function ruin:boss/defeated_void_emperor
