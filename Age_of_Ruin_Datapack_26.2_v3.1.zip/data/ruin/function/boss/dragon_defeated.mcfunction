scoreboard players set #dragon_active ruin_state 0
execute if score #dragon_defeated ruin_state matches 1 run return 0
scoreboard players set #dragon_defeated ruin_state 1
scoreboard players add #corruption ruin_corrupt 15
function ruin:day/recalculate
give @a minecraft:dragon_breath[custom_data={ruin_item:'heart_of_end'},item_name={text:'Heart of the End',color:'light_purple',italic:false},item_model='ruin:heart_of_end',enchantment_glint_override=true] 1
give @a minecraft:nether_star[custom_data={ruin_item:'ancient_soul'},item_name={text:'Ancient Soul',color:'light_purple',italic:false},item_model='ruin:ancient_soul',enchantment_glint_override=true] 4
tellraw @a [{text:'THE WORLD EATER HAS FALLEN',color:'light_purple',bold:true},{text:'  |  Threat +15',color:'red'}]
