scoreboard players set @s ruin_level 2
title @a title {text:'THE WITHER SHIELDS ITSELF',color:'dark_red',bold:true}
execute store result entity @s Health float 0.01 run scoreboard players get @s ruin_maxhp
