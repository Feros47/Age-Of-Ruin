scoreboard players set @s ruin_players 0
execute as @a[distance=..96] run scoreboard players add @e[tag=ruin.current_boss,limit=1,sort=nearest] ruin_players 1
execute if score @s ruin_players matches ..0 run scoreboard players set @s ruin_players 1
effect clear @s minecraft:resistance
execute if score @s ruin_players matches 1 run attribute @s minecraft:max_health base set 1024
execute if score @s ruin_players matches 1 run attribute @s minecraft:max_absorption base set 1176
execute if score @s ruin_players matches 1 run scoreboard players set @s ruin_basehp 2200
execute if score @s ruin_players matches 2 run attribute @s minecraft:max_health base set 1024
execute if score @s ruin_players matches 2 run attribute @s minecraft:max_absorption base set 1880
execute if score @s ruin_players matches 2 run scoreboard players set @s ruin_basehp 2904
execute if score @s ruin_players matches 2 run effect give @s minecraft:resistance infinite 0 true
execute if score @s ruin_players matches 3 run attribute @s minecraft:max_health base set 1024
execute if score @s ruin_players matches 3 run attribute @s minecraft:max_absorption base set 2012
execute if score @s ruin_players matches 3 run scoreboard players set @s ruin_basehp 3036
execute if score @s ruin_players matches 3 run effect give @s minecraft:resistance infinite 1 true
execute if score @s ruin_players matches 4.. run attribute @s minecraft:max_health base set 1024
execute if score @s ruin_players matches 4.. run attribute @s minecraft:max_absorption base set 1572
execute if score @s ruin_players matches 4.. run scoreboard players set @s ruin_basehp 2596
execute if score @s ruin_players matches 4.. run effect give @s minecraft:resistance infinite 2 true
execute store result score @s ruin_maxhp run attribute @s minecraft:max_health get 100
execute store result entity @s Health float 0.01 run scoreboard players get @s ruin_maxhp
scoreboard players operation @s ruin_abs = @s ruin_basehp
scoreboard players set #hundred ruin_tmp 100
scoreboard players operation @s ruin_abs *= #hundred ruin_tmp
scoreboard players operation @s ruin_abs -= @s ruin_maxhp
execute store result entity @s AbsorptionAmount float 0.01 run scoreboard players get @s ruin_abs
execute if score @s ruin_players matches 3.. run effect give @s minecraft:strength infinite 1 true
