scoreboard players set @s ruin_timer 0
effect give @a[distance=..24] minecraft:darkness 6 0 true
execute as @a[distance=7..28] run damage @s 16 minecraft:sonic_boom
playsound minecraft:entity.warden.sonic_boom hostile @a[distance=..40] ~ ~ ~ 1 0.7
summon minecraft:warden ~8 ~ ~ {Tags:["ruin.initialized","ruin.abyss_echo"],PersistenceRequired:1b}
