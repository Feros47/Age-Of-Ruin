scoreboard players set @s ruin_timer 0
execute unless entity @a[distance=..7] run effect give @s minecraft:resistance 2 3 true
execute if entity @p[distance=5..24] run tp @s ^ ^ ^4 facing entity @p eyes
summon minecraft:wither_skeleton ~3 ~ ~ {Tags:["ruin.initialized","ruin.siege"]}
summon minecraft:zombie ~-3 ~ ~ {Tags:["ruin.initialized","ruin.siege"]}
damage @a[distance=..4] 12 minecraft:mob_attack
