revoke @s only ruin:gene_drop_fox_lucky
give @s minecraft:emerald 1
