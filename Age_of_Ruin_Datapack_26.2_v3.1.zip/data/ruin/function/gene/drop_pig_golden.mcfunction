revoke @s only ruin:gene_drop_pig_golden
give @s minecraft:gold_nugget 8
execute store result score @s ruin_gene_roll run random value 1..5
execute if score @s ruin_gene_roll matches 1 run give @s minecraft:gold_ingot 1
