execute if entity @s[tag=ruin.gene_alchemist] run return 0
tag @s add ruin.gene_alchemist
