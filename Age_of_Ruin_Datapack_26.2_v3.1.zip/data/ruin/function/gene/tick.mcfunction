scoreboard players set #geneclock ruin_clock 0
execute as @e[type=#ruin:gene_pool,tag=!ruin.gene_initialized,tag=!ruin.gene_baby_pending] at @s run function ruin:gene/random
function ruin:gene/particles
function ruin:gene/auras
