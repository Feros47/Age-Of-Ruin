execute if entity @s[tag=ruin.gene_gourmet] run return 0
tag @s add ruin.gene_gourmet
