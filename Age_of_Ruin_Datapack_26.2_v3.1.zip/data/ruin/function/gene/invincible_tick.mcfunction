# Keep Invincible animals alive and sterile while preserving normal baby growth.
execute as @e[type=#ruin:gene_pool,tag=ruin.gene_invincible] run data modify entity @s Health set value 1024.0f
execute as @e[type=#ruin:gene_pool,tag=ruin.gene_invincible] run data modify entity @s AbsorptionAmount set value 1024.0f
execute as @e[type=#ruin:gene_pool,tag=ruin.gene_invincible] run effect give @s minecraft:resistance 3 3 true
execute as @e[type=#ruin:gene_pool,tag=ruin.gene_invincible] run effect give @s minecraft:fire_resistance 3 0 true
execute as @e[type=#ruin:gene_pool,tag=ruin.gene_invincible] store result score @s ruin_gene_age run data get entity @s Age 1
execute as @e[type=#ruin:gene_pool,tag=ruin.gene_invincible,scores={ruin_gene_age=0..}] run data modify entity @s Age set value 6000
execute as @e[type=#ruin:gene_pool,tag=ruin.gene_invincible] run data modify entity @s InLove set value 0
