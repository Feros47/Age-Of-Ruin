revoke @s only ruin:gene_drop_cow_arcane
give @s minecraft:amethyst_shard[custom_data={ruin_item:'soul_shard'},item_name={text:'Soul Shard',color:'aqua',italic:false},item_model='ruin:soul_shard',enchantment_glint_override=true] 1
