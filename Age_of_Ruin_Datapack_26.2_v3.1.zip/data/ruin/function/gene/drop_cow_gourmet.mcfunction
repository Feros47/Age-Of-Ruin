revoke @s only ruin:gene_drop_cow_gourmet
give @s minecraft:cooked_beef 4
