execute if entity @s[tag=ruin.gene_lucky] run return 0
tag @s add ruin.gene_lucky
