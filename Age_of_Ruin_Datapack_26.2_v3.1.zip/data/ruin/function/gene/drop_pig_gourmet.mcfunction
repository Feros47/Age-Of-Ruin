revoke @s only ruin:gene_drop_pig_gourmet
give @s minecraft:cooked_porkchop 4
