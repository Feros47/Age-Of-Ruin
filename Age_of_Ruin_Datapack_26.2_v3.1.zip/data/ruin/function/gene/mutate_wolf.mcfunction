execute store result score @s ruin_gene_roll run random value 1..1000
execute if score @s ruin_gene_roll matches 1..166 run function ruin:gene/apply_vigor
execute if score @s ruin_gene_roll matches 167..332 run function ruin:gene/apply_swift
execute if score @s ruin_gene_roll matches 333..498 run function ruin:gene/apply_guardian
execute if score @s ruin_gene_roll matches 499..664 run function ruin:gene/apply_primal
execute if score @s ruin_gene_roll matches 665..830 run function ruin:gene/apply_lucky
execute if score @s ruin_gene_roll matches 831..1000 run function ruin:gene/apply_arcane
