execute if entity @s[tag=ruin.gene_golden] run return 0
tag @s add ruin.gene_golden
