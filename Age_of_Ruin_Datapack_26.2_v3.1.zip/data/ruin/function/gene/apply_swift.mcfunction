execute if entity @s[tag=ruin.gene_swift] run return 0
tag @s add ruin.gene_swift
attribute @s minecraft:movement_speed modifier add ruin:gene_swift 0.30 add_multiplied_total
