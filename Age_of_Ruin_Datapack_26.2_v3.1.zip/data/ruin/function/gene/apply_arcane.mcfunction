execute if entity @s[tag=ruin.gene_arcane] run return 0
tag @s add ruin.gene_arcane
