execute if entity @s[tag=ruin.gene_vigor] run return 0
tag @s add ruin.gene_vigor
attribute @s minecraft:max_health modifier add ruin:gene_vigor 0.5 add_multiplied_total
effect give @s minecraft:regeneration 2 4 true
