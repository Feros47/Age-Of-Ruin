revoke @s only ruin:invincible_gene_hit
# Resolve the Invincible animal just struck, then generate its renewable resource package at its feet.
execute at @s as @e[type=#ruin:gene_pool,tag=ruin.gene_invincible,nbt={HurtTime:10s},distance=..7,limit=1,sort=nearest] at @s run function ruin:gene/invincible/drop
