revoke @s only ruin:gene_breeding
tag @e[type=#ruin:gene_pool,nbt={Age:-24000},distance=..12,limit=1,sort=nearest] add ruin.gene_baby_pending
schedule function ruin:gene/finalize_babies 1t append
