revoke @s only ruin:gene_drop_armadillo_golden
give @s minecraft:gold_nugget 4
