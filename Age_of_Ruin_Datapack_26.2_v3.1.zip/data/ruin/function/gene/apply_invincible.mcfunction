# Mutation-only Invincible gene. Never inherited directly.
execute if entity @s[tag=ruin.gene_invincible] run return 0
tag @s add ruin.gene_invincible
attribute @s minecraft:max_health base set 1024
attribute @s minecraft:max_absorption base set 1024
data modify entity @s Health set value 1024.0f
data modify entity @s AbsorptionAmount set value 1024.0f
effect give @s minecraft:resistance infinite 3 true
effect give @s minecraft:fire_resistance infinite 0 true
playsound minecraft:item.totem.use ambient @a[distance=..24] ~ ~ ~ 0.65 1.35
tellraw @a[distance=..32] [{text:'[Age of Ruin] ',color:'dark_red',bold:true},{text:'A rare ',color:'gray'},{text:'INVINCIBLE',color:'gold',bold:true},{text:' mutation has appeared in a newborn animal.',color:'gray'}]
