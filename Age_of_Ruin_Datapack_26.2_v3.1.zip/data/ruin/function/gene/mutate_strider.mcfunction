execute store result score @s ruin_gene_roll run random value 1..5
execute if score @s ruin_gene_roll matches 1 run function ruin:gene/apply_vigor
execute if score @s ruin_gene_roll matches 2 run function ruin:gene/apply_swift
execute if score @s ruin_gene_roll matches 3 run function ruin:gene/apply_primal
execute if score @s ruin_gene_roll matches 4 run function ruin:gene/apply_golden
execute if score @s ruin_gene_roll matches 5 run function ruin:gene/apply_lucky
