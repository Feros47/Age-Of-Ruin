execute as @e[type=minecraft:cow,tag=ruin.gene_baby_pending] store result score @s ruin_gene_roll run random value 1..100
execute as @e[type=minecraft:cow,tag=ruin.gene_baby_pending,scores={ruin_gene_roll=..3}] run function ruin:gene/mutate_cow
execute as @e[type=minecraft:pig,tag=ruin.gene_baby_pending] store result score @s ruin_gene_roll run random value 1..100
execute as @e[type=minecraft:pig,tag=ruin.gene_baby_pending,scores={ruin_gene_roll=..3}] run function ruin:gene/mutate_pig
execute as @e[type=minecraft:sheep,tag=ruin.gene_baby_pending] store result score @s ruin_gene_roll run random value 1..100
execute as @e[type=minecraft:sheep,tag=ruin.gene_baby_pending,scores={ruin_gene_roll=..3}] run function ruin:gene/mutate_sheep
execute as @e[type=minecraft:chicken,tag=ruin.gene_baby_pending] store result score @s ruin_gene_roll run random value 1..100
execute as @e[type=minecraft:chicken,tag=ruin.gene_baby_pending,scores={ruin_gene_roll=..3}] run function ruin:gene/mutate_chicken
execute as @e[type=minecraft:wolf,tag=ruin.gene_baby_pending] store result score @s ruin_gene_roll run random value 1..100
execute as @e[type=minecraft:wolf,tag=ruin.gene_baby_pending,scores={ruin_gene_roll=..3}] run function ruin:gene/mutate_wolf
execute as @e[type=minecraft:horse,tag=ruin.gene_baby_pending] store result score @s ruin_gene_roll run random value 1..100
execute as @e[type=minecraft:horse,tag=ruin.gene_baby_pending,scores={ruin_gene_roll=..3}] run function ruin:gene/mutate_horse
execute as @e[type=minecraft:donkey,tag=ruin.gene_baby_pending] store result score @s ruin_gene_roll run random value 1..100
execute as @e[type=minecraft:donkey,tag=ruin.gene_baby_pending,scores={ruin_gene_roll=..3}] run function ruin:gene/mutate_donkey
execute as @e[type=minecraft:camel,tag=ruin.gene_baby_pending] store result score @s ruin_gene_roll run random value 1..100
execute as @e[type=minecraft:camel,tag=ruin.gene_baby_pending,scores={ruin_gene_roll=..3}] run function ruin:gene/mutate_camel
execute as @e[type=minecraft:goat,tag=ruin.gene_baby_pending] store result score @s ruin_gene_roll run random value 1..100
execute as @e[type=minecraft:goat,tag=ruin.gene_baby_pending,scores={ruin_gene_roll=..3}] run function ruin:gene/mutate_goat
execute as @e[type=minecraft:bee,tag=ruin.gene_baby_pending] store result score @s ruin_gene_roll run random value 1..100
execute as @e[type=minecraft:bee,tag=ruin.gene_baby_pending,scores={ruin_gene_roll=..3}] run function ruin:gene/mutate_bee
execute as @e[type=minecraft:rabbit,tag=ruin.gene_baby_pending] store result score @s ruin_gene_roll run random value 1..100
execute as @e[type=minecraft:rabbit,tag=ruin.gene_baby_pending,scores={ruin_gene_roll=..3}] run function ruin:gene/mutate_rabbit
execute as @e[type=minecraft:axolotl,tag=ruin.gene_baby_pending] store result score @s ruin_gene_roll run random value 1..100
execute as @e[type=minecraft:axolotl,tag=ruin.gene_baby_pending,scores={ruin_gene_roll=..3}] run function ruin:gene/mutate_axolotl
execute as @e[type=minecraft:cat,tag=ruin.gene_baby_pending] store result score @s ruin_gene_roll run random value 1..100
execute as @e[type=minecraft:cat,tag=ruin.gene_baby_pending,scores={ruin_gene_roll=..3}] run function ruin:gene/mutate_cat
execute as @e[type=minecraft:ocelot,tag=ruin.gene_baby_pending] store result score @s ruin_gene_roll run random value 1..100
execute as @e[type=minecraft:ocelot,tag=ruin.gene_baby_pending,scores={ruin_gene_roll=..3}] run function ruin:gene/mutate_ocelot
execute as @e[type=minecraft:fox,tag=ruin.gene_baby_pending] store result score @s ruin_gene_roll run random value 1..100
execute as @e[type=minecraft:fox,tag=ruin.gene_baby_pending,scores={ruin_gene_roll=..3}] run function ruin:gene/mutate_fox
execute as @e[type=minecraft:llama,tag=ruin.gene_baby_pending] store result score @s ruin_gene_roll run random value 1..100
execute as @e[type=minecraft:llama,tag=ruin.gene_baby_pending,scores={ruin_gene_roll=..3}] run function ruin:gene/mutate_llama
execute as @e[type=minecraft:panda,tag=ruin.gene_baby_pending] store result score @s ruin_gene_roll run random value 1..100
execute as @e[type=minecraft:panda,tag=ruin.gene_baby_pending,scores={ruin_gene_roll=..3}] run function ruin:gene/mutate_panda
execute as @e[type=minecraft:mooshroom,tag=ruin.gene_baby_pending] store result score @s ruin_gene_roll run random value 1..100
execute as @e[type=minecraft:mooshroom,tag=ruin.gene_baby_pending,scores={ruin_gene_roll=..3}] run function ruin:gene/mutate_mooshroom
execute as @e[type=minecraft:armadillo,tag=ruin.gene_baby_pending] store result score @s ruin_gene_roll run random value 1..100
execute as @e[type=minecraft:armadillo,tag=ruin.gene_baby_pending,scores={ruin_gene_roll=..3}] run function ruin:gene/mutate_armadillo
execute as @e[type=minecraft:nautilus,tag=ruin.gene_baby_pending] store result score @s ruin_gene_roll run random value 1..100
execute as @e[type=minecraft:nautilus,tag=ruin.gene_baby_pending,scores={ruin_gene_roll=..3}] run function ruin:gene/mutate_nautilus
execute as @e[type=minecraft:strider,tag=ruin.gene_baby_pending] store result score @s ruin_gene_roll run random value 1..100
execute as @e[type=minecraft:strider,tag=ruin.gene_baby_pending,scores={ruin_gene_roll=..3}] run function ruin:gene/mutate_strider
# Independent mutation-only roll for the Invincible gene: 0.25% (1 in 400).
execute as @e[type=#ruin:gene_pool,tag=ruin.gene_baby_pending] store result score @s ruin_gene_roll run random value 1..400
execute as @e[type=#ruin:gene_pool,tag=ruin.gene_baby_pending,scores={ruin_gene_roll=1}] run function ruin:gene/apply_invincible
tag @e[tag=ruin.gene_baby_pending] add ruin.gene_initialized
tag @e[tag=ruin.gene_baby_pending] remove ruin.gene_baby_pending
