revoke @s only ruin:gene_drop_turtle_golden
give @s minecraft:gold_ingot 1
