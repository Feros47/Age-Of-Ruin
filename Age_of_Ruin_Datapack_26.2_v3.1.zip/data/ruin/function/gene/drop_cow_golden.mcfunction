revoke @s only ruin:gene_drop_cow_golden
give @s minecraft:gold_ingot 1
