revoke @s only ruin:gene_drop_sniffer_lucky
execute store result score @s ruin_gene_roll run random value 1..10
execute if score @s ruin_gene_roll matches 1 run give @s minecraft:diamond 1
execute unless score @s ruin_gene_roll matches 1 run give @s minecraft:emerald 2
