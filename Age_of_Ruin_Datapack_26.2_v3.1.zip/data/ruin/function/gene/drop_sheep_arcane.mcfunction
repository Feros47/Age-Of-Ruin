revoke @s only ruin:gene_drop_sheep_arcane
give @s minecraft:lapis_lazuli 6
