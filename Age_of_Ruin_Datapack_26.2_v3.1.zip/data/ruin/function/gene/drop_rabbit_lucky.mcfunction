revoke @s only ruin:gene_drop_rabbit_lucky
execute store result score @s ruin_gene_roll run random value 1..4
execute if score @s ruin_gene_roll matches 1 run give @s minecraft:emerald 1
execute unless score @s ruin_gene_roll matches 1 run give @s minecraft:rabbit_foot 1
