revoke @s only ruin:milk_cow
revoke @s only ruin:milk_goat
execute store result score @s ruin_gene_roll run random value 1..6
execute if score @s ruin_gene_roll matches 1 run give @s minecraft:potion[potion_contents={potion:'minecraft:strong_regeneration'}] 1
execute if score @s ruin_gene_roll matches 2 run give @s minecraft:potion[potion_contents={potion:'minecraft:strong_strength'}] 1
execute if score @s ruin_gene_roll matches 3 run give @s minecraft:potion[potion_contents={potion:'minecraft:long_swiftness'}] 1
execute if score @s ruin_gene_roll matches 4 run give @s minecraft:potion[potion_contents={potion:'minecraft:long_fire_resistance'}] 1
execute if score @s ruin_gene_roll matches 5 run give @s minecraft:potion[potion_contents={potion:'minecraft:long_water_breathing'}] 1
execute if score @s ruin_gene_roll matches 6 run give @s minecraft:potion[potion_contents={potion:'minecraft:long_night_vision'}] 1
tellraw @s {text:'The Alchemist animal produced an infused draught.',color:'light_purple'}
