revoke @s only ruin:gene_drop_chicken_golden
give @s minecraft:gold_nugget 3
