execute store result score @s ruin_gene_roll run random value 1..1000
execute if score @s ruin_gene_roll matches 1..200 run function ruin:gene/apply_vigor
execute if score @s ruin_gene_roll matches 201..400 run function ruin:gene/apply_golden
execute if score @s ruin_gene_roll matches 401..600 run function ruin:gene/apply_arcane
execute if score @s ruin_gene_roll matches 601..800 run function ruin:gene/apply_lucky
execute if score @s ruin_gene_roll matches 801..1000 run function ruin:gene/apply_swift
