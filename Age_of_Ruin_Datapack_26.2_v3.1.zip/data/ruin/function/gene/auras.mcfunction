execute as @e[type=minecraft:wolf,tag=ruin.gene_guardian] at @s run effect give @a[distance=..5] minecraft:strength 3 0 true
execute as @e[type=minecraft:axolotl,tag=ruin.gene_arcane] at @s run effect give @a[distance=..5] minecraft:regeneration 3 0 true
execute as @e[type=minecraft:bee,tag=ruin.gene_arcane] at @s run effect give @a[distance=..5] minecraft:haste 3 0 true
execute as @e[type=minecraft:cat,tag=ruin.gene_lucky] at @s run effect give @a[distance=..4] minecraft:luck 3 0 true
