execute if entity @s[tag=ruin.gene_primal] run return 0
tag @s add ruin.gene_primal
attribute @s minecraft:max_health modifier add ruin:gene_primal 0.25 add_multiplied_total
attribute @s minecraft:scale modifier add ruin:gene_primal 0.15 add_multiplied_total
execute store success score @s ruin_tmp store result score @s ruin_base_dmg run attribute @s minecraft:attack_damage base get 100
execute if score @s ruin_base_dmg matches 1.. run attribute @s minecraft:attack_damage modifier add ruin:gene_primal 0.25 add_multiplied_total
