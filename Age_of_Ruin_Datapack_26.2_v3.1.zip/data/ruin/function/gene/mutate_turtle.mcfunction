execute store result score @s ruin_gene_roll run random value 1..1000
execute if score @s ruin_gene_roll matches 1..250 run function ruin:gene/apply_vigor
execute if score @s ruin_gene_roll matches 251..500 run function ruin:gene/apply_golden
execute if score @s ruin_gene_roll matches 501..750 run function ruin:gene/apply_arcane
execute if score @s ruin_gene_roll matches 751..1000 run function ruin:gene/apply_lucky
