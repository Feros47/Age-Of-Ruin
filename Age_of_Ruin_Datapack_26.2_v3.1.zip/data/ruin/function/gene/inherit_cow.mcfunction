scoreboard players set #parents ruin_tmp 0
execute as @e[type=minecraft:cow,tag=ruin.gene_vigor,distance=..7,nbt={Age:0},limit=2] run scoreboard players add #parents ruin_tmp 1
execute if score #parents ruin_tmp matches 1 store result score @s ruin_gene_roll run random value 1..100
execute if score #parents ruin_tmp matches 1 if score @s ruin_gene_roll matches ..55 run function ruin:gene/apply_vigor
execute if score #parents ruin_tmp matches 2.. store result score @s ruin_gene_roll run random value 1..100
execute if score #parents ruin_tmp matches 2.. if score @s ruin_gene_roll matches ..85 run function ruin:gene/apply_vigor
scoreboard players set #parents ruin_tmp 0
execute as @e[type=minecraft:cow,tag=ruin.gene_gourmet,distance=..7,nbt={Age:0},limit=2] run scoreboard players add #parents ruin_tmp 1
execute if score #parents ruin_tmp matches 1 store result score @s ruin_gene_roll run random value 1..100
execute if score #parents ruin_tmp matches 1 if score @s ruin_gene_roll matches ..55 run function ruin:gene/apply_gourmet
execute if score #parents ruin_tmp matches 2.. store result score @s ruin_gene_roll run random value 1..100
execute if score #parents ruin_tmp matches 2.. if score @s ruin_gene_roll matches ..85 run function ruin:gene/apply_gourmet
scoreboard players set #parents ruin_tmp 0
execute as @e[type=minecraft:cow,tag=ruin.gene_alchemist,distance=..7,nbt={Age:0},limit=2] run scoreboard players add #parents ruin_tmp 1
execute if score #parents ruin_tmp matches 1 store result score @s ruin_gene_roll run random value 1..100
execute if score #parents ruin_tmp matches 1 if score @s ruin_gene_roll matches ..55 run function ruin:gene/apply_alchemist
execute if score #parents ruin_tmp matches 2.. store result score @s ruin_gene_roll run random value 1..100
execute if score #parents ruin_tmp matches 2.. if score @s ruin_gene_roll matches ..85 run function ruin:gene/apply_alchemist
scoreboard players set #parents ruin_tmp 0
execute as @e[type=minecraft:cow,tag=ruin.gene_golden,distance=..7,nbt={Age:0},limit=2] run scoreboard players add #parents ruin_tmp 1
execute if score #parents ruin_tmp matches 1 store result score @s ruin_gene_roll run random value 1..100
execute if score #parents ruin_tmp matches 1 if score @s ruin_gene_roll matches ..55 run function ruin:gene/apply_golden
execute if score #parents ruin_tmp matches 2.. store result score @s ruin_gene_roll run random value 1..100
execute if score #parents ruin_tmp matches 2.. if score @s ruin_gene_roll matches ..85 run function ruin:gene/apply_golden
scoreboard players set #parents ruin_tmp 0
execute as @e[type=minecraft:cow,tag=ruin.gene_arcane,distance=..7,nbt={Age:0},limit=2] run scoreboard players add #parents ruin_tmp 1
execute if score #parents ruin_tmp matches 1 store result score @s ruin_gene_roll run random value 1..100
execute if score #parents ruin_tmp matches 1 if score @s ruin_gene_roll matches ..55 run function ruin:gene/apply_arcane
execute if score #parents ruin_tmp matches 2.. store result score @s ruin_gene_roll run random value 1..100
execute if score #parents ruin_tmp matches 2.. if score @s ruin_gene_roll matches ..85 run function ruin:gene/apply_arcane
scoreboard players set #parents ruin_tmp 0
execute as @e[type=minecraft:cow,tag=ruin.gene_lucky,distance=..7,nbt={Age:0},limit=2] run scoreboard players add #parents ruin_tmp 1
execute if score #parents ruin_tmp matches 1 store result score @s ruin_gene_roll run random value 1..100
execute if score #parents ruin_tmp matches 1 if score @s ruin_gene_roll matches ..55 run function ruin:gene/apply_lucky
execute if score #parents ruin_tmp matches 2.. store result score @s ruin_gene_roll run random value 1..100
execute if score #parents ruin_tmp matches 2.. if score @s ruin_gene_roll matches ..85 run function ruin:gene/apply_lucky
execute store result score @s ruin_gene_roll run random value 1..100
execute if score @s ruin_gene_roll matches ..3 run function ruin:gene/mutate_cow
tag @s add ruin.gene_initialized
