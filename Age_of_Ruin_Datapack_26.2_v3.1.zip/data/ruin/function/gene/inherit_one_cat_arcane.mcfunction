revoke @s only ruin:gene_inherit_one_cat_arcane
execute store result score @s ruin_gene_roll run random value 1..100
execute if score @s ruin_gene_roll matches ..55 as @e[type=minecraft:cat,nbt={Age:-24000},distance=..12,limit=1,sort=nearest] run function ruin:gene/apply_arcane
