execute as @e[type=minecraft:item] at @s run function ruin:altar/check
