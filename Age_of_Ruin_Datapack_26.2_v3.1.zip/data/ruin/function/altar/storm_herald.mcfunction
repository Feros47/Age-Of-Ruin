execute if entity @e[tag=ruin.boss_storm_herald] run return 0
function ruin:boss/summon_storm_herald
kill @s
