execute if entity @e[tag=ruin.boss_ancient_colossus] run return 0
function ruin:boss/summon_ancient_colossus
kill @s
