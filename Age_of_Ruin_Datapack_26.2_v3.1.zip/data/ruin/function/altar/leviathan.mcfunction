execute if entity @e[tag=ruin.boss_leviathan] run return 0
function ruin:boss/summon_leviathan
kill @s
