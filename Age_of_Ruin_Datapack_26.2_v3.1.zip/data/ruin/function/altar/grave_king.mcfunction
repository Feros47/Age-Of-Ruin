execute if entity @e[tag=ruin.boss_grave_king] run return 0
function ruin:boss/summon_grave_king
kill @s
