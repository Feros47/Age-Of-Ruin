execute if entity @e[tag=ruin.boss_void_emperor] run return 0
function ruin:boss/summon_void_emperor
kill @s
