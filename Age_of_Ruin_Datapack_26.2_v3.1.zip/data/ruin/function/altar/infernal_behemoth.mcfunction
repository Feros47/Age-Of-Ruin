execute if entity @e[tag=ruin.boss_infernal_behemoth] run return 0
function ruin:boss/summon_infernal_behemoth
kill @s
