execute if entity @e[tag=ruin.boss_lich_king] run return 0
function ruin:boss/summon_lich_king
kill @s
