execute if entity @e[tag=ruin.boss_warden_king] run return 0
function ruin:boss/summon_warden_king
kill @s
