execute if entity @e[tag=ruin.boss_abyss_watcher] run return 0
function ruin:boss/summon_abyss_watcher
kill @s
