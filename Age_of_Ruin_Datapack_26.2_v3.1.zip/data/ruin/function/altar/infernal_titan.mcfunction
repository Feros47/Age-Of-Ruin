execute if entity @e[tag=ruin.boss_infernal_titan] run return 0
function ruin:boss/summon_infernal_titan
kill @s
