AGE OF RUIN v3.0 - Minecraft Java 26.2

V3 expands the complete v2 system with:
- All 43 vanilla enchantments present in 26.2 (including Lunge) upgradeable to level 255.
- Generic enchant trigger mapping (technical interface below); v2 shortcut triggers remain compatible.
- Legendary/Mythic Luck of the Sea fishing at high enchant levels.
- Nether-specific +25% baseline pressure, elevated rarity odds, Infernal Warbands and Soul Storms.
- Evolved variants for spiders, illagers, silverfish, endermen, witches, Nether mobs, guardians, Wardens, Creaking, Vexes, Shulkers, Breezes, Phantoms, Sulfur Cubes and more.
- Heritable gene system for 25 breedable passive/neutral species. Offspring can inherit both parents' traits and mutate new ones.
- Gene examples: Vigor, Swift, Guardian, Primal, Gourmet, Golden, Arcane, Lucky and Alchemist.
- Alchemist cows/goats grant bonus potion draughts when milked. Gourmet/Golden/Arcane/Lucky animals have additive special drops.
- Epic and Legendary random enemy tiers with actual bonus loot.

ENCHANTMENT UPGRADE TECHNICAL MAPPING
Use the existing Soul economy. Hold an item that already has the enchantment and select the code through the generic ruin_enchant trigger. Requiring the enchantment to already exist preserves vanilla compatibility and exclusivity; Age of Ruin only raises its level.
01 = binding_curse
02 = vanishing_curse
03 = riptide
04 = channeling
05 = wind_burst
06 = frost_walker
07 = sharpness
08 = smite
09 = bane_of_arthropods
10 = impaling
11 = power
12 = density
13 = breach
14 = piercing
15 = sweeping_edge
16 = multishot
17 = fire_aspect
18 = flame
19 = knockback
20 = punch
21 = protection
22 = blast_protection
23 = fire_protection
24 = projectile_protection
25 = feather_falling
26 = fortune
27 = looting
28 = silk_touch
29 = luck_of_the_sea
30 = efficiency
31 = quick_charge
32 = lure
33 = respiration
34 = aqua_affinity
35 = soul_speed
36 = swift_sneak
37 = depth_strider
38 = thorns
39 = loyalty
40 = unbreaking
41 = infinity
42 = mending
43 = lunge

The Bestiary & Ecosystem player PDF intentionally contains no commands.
Back up the world before installing or updating any progression datapack.

V3 FINAL COMPATIBILITY NOTES
- 26.2 entity-predicate advancement JSON uses the new entity_properties/list schema. All Age of Ruin kill, milking and genetic trigger predicates have been migrated.
- Official 26.2 Mounts of Mayhem threats Parched, Camel Husk and Zombie Horse are covered; Parched scales/evolves and the undead mounts receive special traits.
- Direct-birth genetic inheritance uses the actual bred_animals parent/partner trigger context: 55% for a gene present in one parent, 85% when both carry it, plus a 3% mutation roll. Mule inheritance handles horse x donkey crosses.
- Striders now participate in the heritable gene ecosystem, giving the Nether its own domestic breeding line.
