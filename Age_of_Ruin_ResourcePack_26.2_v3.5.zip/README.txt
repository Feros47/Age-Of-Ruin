AGE OF RUIN RESOURCE PACK v3.5 - Minecraft Java 26.2

Resource-pack format: 88.0
Compatible datapack: Age of Ruin v3.10

Install this ZIP as a client resource pack, or distribute its direct-download URL and SHA-1 through server.properties. Do not place it in the world's datapacks folder.

Contents:
- 35 gameplay item definitions plus 10 dedicated boss-display definitions and 45 matching models
- 34 unique 16x16 item textures plus one transparent ten-boss texture atlas registered in the Java 26.2 item atlas (Infernal Heart intentionally shares the Infernal Sigil visual)
- English names for all 35 custom items and Fortification

The ten custom bosses use nine-cuboid volumetric item_display models while fully hidden carrier mobs provide AI and hitboxes. v3.5 removes camera-facing billboard behavior, adds visible depth on every axis, follows carrier rotation, and uses natural world lighting. Replace v3.4, require v3.5, and reconnect or reload client resources.

The asset chain was validated from every datapack minecraft:item_model reference through item definition, model and PNG texture. A final in-game client visual check is still recommended after upload/distribution.
