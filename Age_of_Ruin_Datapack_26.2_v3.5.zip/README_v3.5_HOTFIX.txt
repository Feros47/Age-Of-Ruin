AGE OF RUIN v3.5
Replace the previous Age of Ruin datapack ZIP in world/datapacks with this ZIP and fully restart the server.
The v3.1 resource pack remains compatible; no resource-pack replacement is required for this repair.
Do not keep multiple Age of Ruin datapack versions enabled at the same time.
Admin smoke test: /function ruin:admin/v35_selftest
Runtime diagnostic: /function ruin:admin/runtime_status
