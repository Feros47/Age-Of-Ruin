tellraw @s {text:'=== AGE OF RUIN v3.5 ADMIN ===',color:'dark_red',bold:true}
tellraw @s [{text:'Status: ',color:'gray'},{text:'/function ruin:admin/status',color:'aqua'}]
tellraw @s [{text:'Show daily report now: ',color:'gray'},{text:'/function ruin:admin/daily_message',color:'aqua'}]
tellraw @s [{text:'Forced Elite test: ',color:'gray'},{text:'/function ruin:admin/test_elite',color:'aqua'}]
tellraw @s [{text:'Genetic Cow test: ',color:'gray'},{text:'/function ruin:admin/test_gene',color:'aqua'}]
tellraw @s {text:'Bosses:',color:'gold',bold:true}
tellraw @s {text:'/function ruin:admin/boss/grave_king',color:'aqua'}
tellraw @s {text:'/function ruin:admin/boss/infernal_behemoth',color:'aqua'}
tellraw @s {text:'/function ruin:admin/boss/abyss_watcher',color:'aqua'}
tellraw @s {text:'/function ruin:admin/boss/leviathan',color:'aqua'}
tellraw @s {text:'/function ruin:admin/boss/ancient_colossus',color:'aqua'}
tellraw @s {text:'/function ruin:admin/boss/lich_king',color:'aqua'}
tellraw @s {text:'/function ruin:admin/boss/infernal_titan',color:'aqua'}
tellraw @s {text:'/function ruin:admin/boss/warden_king',color:'aqua'}
tellraw @s {text:'/function ruin:admin/boss/storm_herald',color:'aqua'}
tellraw @s {text:'/function ruin:admin/boss/void_emperor',color:'aqua'}

tellraw @s [{text:'/function ruin:admin/runtime_status',color:'aqua'},{text:' - verify scheduler/day clock',color:'gray'}]
tellraw @s [{text:'/function ruin:admin/test_scaling',color:'aqua'},{text:' - summon a naturally processed scaling test zombie',color:'gray'}]

tellraw @s [{text:'/function ruin:admin/test_gene_loot',color:'aqua'},{text:' — spawn a cow that proves gene loot bonuses',color:'gray'}]
tellraw @s [{text:'/function ruin:admin/inspect_gene_loot',color:'aqua'},{text:' — show nearest genetic animal DeathLootTable',color:'gray'}]
