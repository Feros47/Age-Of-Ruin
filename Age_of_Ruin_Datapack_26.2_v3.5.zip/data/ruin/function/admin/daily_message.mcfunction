execute store result score #raw_day ruin_worldday run time query day repetitions
scoreboard players operation #day ruin_day = #raw_day ruin_worldday
scoreboard players operation #day ruin_day -= #epoch ruin_worldday
scoreboard players add #day ruin_day 1
function ruin:day/recalculate
function ruin:day/set_era
function ruin:day/message
