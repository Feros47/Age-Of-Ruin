# Rebuild affix suffixes on an Age of Ruin named hostile.
data modify entity @s CustomName.extra set value []
execute if entity @s[tag=ruin.affix_armored] run data modify entity @s CustomName.extra append value {text:' • Armored',color:'gray'}
execute if entity @s[tag=ruin.affix_brutal] run data modify entity @s CustomName.extra append value {text:' • Brutal',color:'red'}
execute if entity @s[tag=ruin.affix_swift] run data modify entity @s CustomName.extra append value {text:' • Swift',color:'aqua'}
execute if entity @s[tag=ruin.affix_vampiric] run data modify entity @s CustomName.extra append value {text:' • Vampiric',color:'dark_red'}
execute if entity @s[tag=ruin.affix_regenerating] run data modify entity @s CustomName.extra append value {text:' • Regenerating',color:'green'}
execute if entity @s[tag=ruin.affix_berserker] run data modify entity @s CustomName.extra append value {text:' • Berserker',color:'red'}
execute if entity @s[tag=ruin.affix_juggernaut] run data modify entity @s CustomName.extra append value {text:' • Juggernaut',color:'dark_gray'}
execute if entity @s[tag=ruin.affix_stormborn] run data modify entity @s CustomName.extra append value {text:' • Stormborn',color:'aqua'}
execute if entity @s[tag=ruin.affix_venomous] run data modify entity @s CustomName.extra append value {text:' • Venomous',color:'dark_green'}
execute if entity @s[tag=ruin.affix_withering] run data modify entity @s CustomName.extra append value {text:' • Withering',color:'dark_gray'}
execute if entity @s[tag=ruin.affix_frostbound] run data modify entity @s CustomName.extra append value {text:' • Frostbound',color:'blue'}
execute if entity @s[tag=ruin.affix_infernal] run data modify entity @s CustomName.extra append value {text:' • Infernal',color:'gold'}
execute if entity @s[tag=ruin.affix_explosive] run data modify entity @s CustomName.extra append value {text:' • Explosive',color:'red'}
execute if entity @s[tag=ruin.affix_necromancer] run data modify entity @s CustomName.extra append value {text:' • Necromancer',color:'dark_purple'}
execute if entity @s[tag=ruin.affix_commander] run data modify entity @s CustomName.extra append value {text:' • Commander',color:'gold'}
execute if entity @s[tag=ruin.affix_blinking] run data modify entity @s CustomName.extra append value {text:' • Blinking',color:'light_purple'}
execute if entity @s[tag=ruin.affix_reflective] run data modify entity @s CustomName.extra append value {text:' • Reflective',color:'white'}
execute if entity @s[tag=ruin.affix_leeching] run data modify entity @s CustomName.extra append value {text:' • Leeching',color:'dark_red'}
execute if entity @s[tag=ruin.affix_hexed] run data modify entity @s CustomName.extra append value {text:' • Hexed',color:'dark_purple'}
execute if entity @s[tag=ruin.affix_phasewalker] run data modify entity @s CustomName.extra append value {text:' • Phasewalker',color:'light_purple'}
execute if entity @s[tag=ruin.affix_executioner] run data modify entity @s CustomName.extra append value {text:' • Executioner',color:'dark_red'}
execute if entity @s[tag=ruin.affix_architect] run data modify entity @s CustomName.extra append value {text:' • Architect',color:'yellow'}
data merge entity @s {CustomNameVisible:1b}
