scoreboard players set @s ruin_boss_timer 0
execute at @a[distance=..160] run summon minecraft:shulker ~4 ~ ~ {Tags:["ruin.initialized"]}
execute at @a[distance=..160] run summon minecraft:endermite ~-4 ~ ~ {Tags:["ruin.initialized"]}
execute at @a[distance=..160] run summon minecraft:phantom ~ ~6 ~ {Tags:["ruin.initialized"]}
damage @a[distance=..160] 16 minecraft:dragon_breath
