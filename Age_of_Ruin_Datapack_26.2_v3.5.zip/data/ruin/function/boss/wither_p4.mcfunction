scoreboard players set @s ruin_boss_timer 0
damage @s 8 minecraft:generic
damage @a[distance=..96] 22 minecraft:wither
effect give @a[distance=..96] minecraft:weakness 3 1 true
