execute as @e[type=minecraft:wither,tag=!ruin.wither] run tag @s add ruin.wither
execute as @e[type=minecraft:wither,tag=ruin.wither,tag=!ruin.wither_scaled] at @s run function ruin:boss/wither_scale
execute as @e[type=minecraft:wither,tag=ruin.wither,tag=!ruin.wither_scaled] run tag @s add ruin.wither_scaled
execute if entity @e[type=minecraft:wither,tag=ruin.wither] run scoreboard players set #wither_active ruin_state 1
scoreboard players add @e[type=minecraft:wither,tag=ruin.wither] ruin_boss_timer 1
execute as @e[type=minecraft:wither,tag=ruin.wither] at @s run function ruin:boss/wither_phase
execute if score #wither_active ruin_state matches 1 unless entity @e[type=minecraft:wither,tag=ruin.wither] run scoreboard players set #wither_active ruin_state 0
