scoreboard players set #active_infernal_titan ruin_state 0
bossbar remove ruin:infernal_titan
scoreboard players add #corruption ruin_corrupt 5
function ruin:day/recalculate
tellraw @a [{text:'THE INFERNAL TITAN DEFEATED',color:'gold',bold:true},{text:'  |  World Threat +5',color:'red'}]

tag @a remove ruin.part_infernal_titan
