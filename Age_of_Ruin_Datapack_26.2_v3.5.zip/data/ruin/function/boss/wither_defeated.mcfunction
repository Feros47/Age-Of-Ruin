scoreboard players set #wither_active ruin_state 0
# v3.5 rewards are handled by ruin:wither_kill so unrelated Withers cannot interfere.
