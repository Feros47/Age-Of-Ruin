scoreboard players set #active_void_emperor ruin_state 0
bossbar remove ruin:void_emperor
scoreboard players add #corruption ruin_corrupt 5
function ruin:day/recalculate
tellraw @a [{text:'THE VOID EMPEROR DEFEATED',color:'gold',bold:true},{text:'  |  World Threat +5',color:'red'}]

tag @a remove ruin.part_void_emperor
