scoreboard players set @s ruin_boss_timer 0
execute at @a[distance=..160] run summon minecraft:endermite ~3 ~ ~ {Tags:["ruin.initialized"]}
damage @a[distance=..160] 8 minecraft:dragon_breath
