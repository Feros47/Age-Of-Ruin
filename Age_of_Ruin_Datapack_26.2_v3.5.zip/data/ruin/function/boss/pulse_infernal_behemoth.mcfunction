scoreboard players set @s ruin_boss_timer 0
summon minecraft:blaze ~4 ~3 ~ {Tags:["ruin.initialized"]}
summon minecraft:magma_cube ~-4 ~ ~ {Size:3,Tags:["ruin.initialized"]}
damage @a[distance=..6] 14 minecraft:on_fire
particle minecraft:flame ~ ~1 ~ 3 1 3 0.08 50 force
