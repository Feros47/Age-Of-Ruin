tag @a remove ruin.part_lich_king
kill @e[tag=ruin.lich_phylactery]
summon minecraft:evoker ~ ~2 ~ {Tags:["ruin.initialized","ruin.boss","ruin.boss_lich_king","ruin.current_boss","ruin.siege"],CustomName:{text:'THE LICH KING',color:'dark_purple',bold:true},CustomNameVisible:1b,PersistenceRequired:1b,CanPickUpLoot:0b}
execute as @e[tag=ruin.boss_lich_king,limit=1,sort=nearest] at @s run tag @a[distance=..128] add ruin.part_lich_king
execute as @e[tag=ruin.boss_lich_king,limit=1,sort=nearest] at @s run function ruin:boss/scale_lich_king
execute as @e[tag=ruin.boss_lich_king,limit=1,sort=nearest] run item replace entity @s weapon.offhand with minecraft:echo_shard[custom_data={ruin_item:'lich_phylactery'},item_name={text:'Lich Phylactery',color:'light_purple',italic:false},item_model='ruin:lich_phylactery',enchantment_glint_override=true] 1
execute as @e[tag=ruin.boss_lich_king,limit=1,sort=nearest] run data merge entity @s {drop_chances:{offhand:1.0f}}
execute as @e[tag=ruin.boss_lich_king,limit=1,sort=nearest] run function ruin:affix/necromancer
execute as @e[tag=ruin.boss_lich_king,limit=1,sort=nearest] run function ruin:affix/hexed
execute as @e[tag=ruin.boss_lich_king,limit=1,sort=nearest] run function ruin:affix/regenerating
execute as @e[tag=ruin.boss_lich_king,limit=1,sort=nearest] run function ruin:boss/finalize_pool
scoreboard players set #active_lich_king ruin_state 1
bossbar remove ruin:lich_king
bossbar add ruin:lich_king {text:'THE LICH KING',color:'dark_purple',bold:true}
execute store result bossbar ruin:lich_king max run scoreboard players get @e[tag=ruin.boss_lich_king,limit=1,sort=nearest] ruin_basehp
bossbar set ruin:lich_king players @a
title @a title {text:'THE LICH KING',color:'dark_purple',bold:true}
playsound minecraft:entity.wither.spawn master @a ~ ~ ~ 0.9 0.7
execute as @e[tag=ruin.current_boss] run tag @s remove ruin.current_boss
summon minecraft:shulker ~6 ~1 ~ {Tags:["ruin.lich_phylactery"],CustomName:{text:'Phylactery',color:'dark_purple'},PersistenceRequired:1b}
summon minecraft:shulker ~-6 ~1 ~ {Tags:["ruin.lich_phylactery"],CustomName:{text:'Phylactery',color:'dark_purple'},PersistenceRequired:1b}
summon minecraft:shulker ~ ~1 ~6 {Tags:["ruin.lich_phylactery"],CustomName:{text:'Phylactery',color:'dark_purple'},PersistenceRequired:1b}
