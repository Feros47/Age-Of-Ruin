scoreboard players set #active_storm_herald ruin_state 0
bossbar remove ruin:storm_herald
scoreboard players add #corruption ruin_corrupt 5
function ruin:day/recalculate
give @a[tag=ruin.part_storm_herald] minecraft:heart_of_the_sea[custom_data={ruin_item:'storm_core'},item_name={text:'Storm Core',color:'aqua',italic:false},item_model='ruin:storm_core',enchantment_glint_override=true] 1
tellraw @a [{text:'THE STORM HERALD DEFEATED',color:'gold',bold:true},{text:'  |  World Threat +5',color:'red'}]

tag @a remove ruin.part_storm_herald
