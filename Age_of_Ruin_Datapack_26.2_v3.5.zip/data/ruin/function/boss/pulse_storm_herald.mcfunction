scoreboard players set @s ruin_boss_timer 0
execute at @p[distance=..50] run summon minecraft:lightning_bolt ~ ~ ~
summon minecraft:vex ~3 ~3 ~ {LifeTicks:400}
summon minecraft:breeze ~-3 ~ ~ {Tags:["ruin.initialized"]}
damage @a[distance=..7] 14 minecraft:magic
