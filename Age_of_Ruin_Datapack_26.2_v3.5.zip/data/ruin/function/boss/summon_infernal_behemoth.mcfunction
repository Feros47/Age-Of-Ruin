tag @a remove ruin.part_infernal_behemoth
summon minecraft:ravager ~ ~2 ~ {Tags:["ruin.initialized","ruin.boss","ruin.boss_infernal_behemoth","ruin.current_boss","ruin.siege"],CustomName:{text:'THE INFERNAL BEHEMOTH',color:'red',bold:true},CustomNameVisible:1b,PersistenceRequired:1b,CanPickUpLoot:0b}
execute as @e[tag=ruin.boss_infernal_behemoth,limit=1,sort=nearest] at @s run tag @a[distance=..128] add ruin.part_infernal_behemoth
execute as @e[tag=ruin.boss_infernal_behemoth,limit=1,sort=nearest] at @s run function ruin:boss/scale_infernal_behemoth
execute as @e[tag=ruin.boss_infernal_behemoth,limit=1,sort=nearest] run item replace entity @s weapon.offhand with minecraft:blaze_powder[custom_data={ruin_item:'infernal_heart'},item_name={text:'Infernal Heart',color:'gold',italic:false},enchantment_glint_override=true] 1
execute as @e[tag=ruin.boss_infernal_behemoth,limit=1,sort=nearest] run data merge entity @s {drop_chances:{offhand:1.0f}}
execute as @e[tag=ruin.boss_infernal_behemoth,limit=1,sort=nearest] run function ruin:affix/infernal
execute as @e[tag=ruin.boss_infernal_behemoth,limit=1,sort=nearest] run function ruin:affix/juggernaut
execute as @e[tag=ruin.boss_infernal_behemoth,limit=1,sort=nearest] run function ruin:affix/brutal
execute as @e[tag=ruin.boss_infernal_behemoth,limit=1,sort=nearest] run function ruin:boss/finalize_pool
scoreboard players set #active_infernal_behemoth ruin_state 1
bossbar remove ruin:infernal_behemoth
bossbar add ruin:infernal_behemoth {text:'THE INFERNAL BEHEMOTH',color:'red',bold:true}
execute store result bossbar ruin:infernal_behemoth max run scoreboard players get @e[tag=ruin.boss_infernal_behemoth,limit=1,sort=nearest] ruin_basehp
bossbar set ruin:infernal_behemoth players @a
title @a title {text:'THE INFERNAL BEHEMOTH',color:'red',bold:true}
playsound minecraft:entity.wither.spawn master @a ~ ~ ~ 0.9 0.7
execute as @e[tag=ruin.current_boss] run tag @s remove ruin.current_boss
