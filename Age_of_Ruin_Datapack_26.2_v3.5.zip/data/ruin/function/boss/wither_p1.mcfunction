scoreboard players set @s ruin_boss_timer 0
summon minecraft:wither_skeleton ~3 ~ ~ {Tags:["ruin.initialized","ruin.siege"]}
summon minecraft:wither_skeleton ~-3 ~ ~ {Tags:["ruin.initialized","ruin.siege"]}
damage @a[distance=..96] 10 minecraft:wither
