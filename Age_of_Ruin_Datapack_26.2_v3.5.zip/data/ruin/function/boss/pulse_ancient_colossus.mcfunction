scoreboard players set @s ruin_boss_timer 0
execute if entity @e[tag=ruin.colossus_node,distance=..24] run effect give @s minecraft:resistance 2 4 true
execute unless entity @e[tag=ruin.colossus_node,distance=..24] run effect clear @s minecraft:resistance
damage @a[distance=..7] 18 minecraft:mob_attack
particle minecraft:poof ~ ~1 ~ 3 1 3 0.1 40 force
