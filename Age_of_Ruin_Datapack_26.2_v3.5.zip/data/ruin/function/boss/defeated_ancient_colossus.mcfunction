scoreboard players set #active_ancient_colossus ruin_state 0
bossbar remove ruin:ancient_colossus
scoreboard players add #corruption ruin_corrupt 5
function ruin:day/recalculate
tellraw @a [{text:'THE ANCIENT COLOSSUS DEFEATED',color:'gold',bold:true},{text:'  |  World Threat +5',color:'red'}]

kill @e[tag=ruin.colossus_node]
tag @a remove ruin.part_ancient_colossus
