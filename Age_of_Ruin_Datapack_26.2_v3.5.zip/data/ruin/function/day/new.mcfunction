scoreboard players operation #processed_day ruin_day = #day ruin_day
function ruin:day/recalculate
function ruin:day/set_era
scoreboard players set #bloodmoon ruin_state 0
scoreboard players set #event ruin_state 0
function ruin:event/roll_bloodmoon
# Lock sleeping immediately on a predicted Blood Moon day so players cannot skip it before night-start detection.
execute if score #bloodmoon ruin_state matches 1 run gamerule playersSleepingPercentage 101
execute unless score #bloodmoon ruin_state matches 1 run gamerule playersSleepingPercentage 100
execute unless score #bloodmoon ruin_state matches 1 run function ruin:event/roll_world
execute unless score #bloodmoon ruin_state matches 1 run function ruin:event/check_scheduled_invasion
function ruin:day/message
