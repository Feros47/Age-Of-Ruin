execute store result score #mutation_gene ruin_gene_roll run random value 1..9
execute if score #mutation_gene ruin_gene_roll matches 1 run tag @e[type=minecraft:marker,tag=ruin.gene_hatch,limit=1,sort=nearest] add ruin.pending_vigor
execute if score #mutation_gene ruin_gene_roll matches 2 run tag @e[type=minecraft:marker,tag=ruin.gene_hatch,limit=1,sort=nearest] add ruin.pending_swift
execute if score #mutation_gene ruin_gene_roll matches 3 run tag @e[type=minecraft:marker,tag=ruin.gene_hatch,limit=1,sort=nearest] add ruin.pending_guardian
execute if score #mutation_gene ruin_gene_roll matches 4 run tag @e[type=minecraft:marker,tag=ruin.gene_hatch,limit=1,sort=nearest] add ruin.pending_primal
execute if score #mutation_gene ruin_gene_roll matches 5 run tag @e[type=minecraft:marker,tag=ruin.gene_hatch,limit=1,sort=nearest] add ruin.pending_gourmet
execute if score #mutation_gene ruin_gene_roll matches 6 run tag @e[type=minecraft:marker,tag=ruin.gene_hatch,limit=1,sort=nearest] add ruin.pending_golden
execute if score #mutation_gene ruin_gene_roll matches 7 run tag @e[type=minecraft:marker,tag=ruin.gene_hatch,limit=1,sort=nearest] add ruin.pending_arcane
execute if score #mutation_gene ruin_gene_roll matches 8 run tag @e[type=minecraft:marker,tag=ruin.gene_hatch,limit=1,sort=nearest] add ruin.pending_lucky
execute if score #mutation_gene ruin_gene_roll matches 9 run tag @e[type=minecraft:marker,tag=ruin.gene_hatch,limit=1,sort=nearest] add ruin.pending_alchemist
