execute if entity @s[tag=ruin.pending_vigor] as @e[type=minecraft:frog,tag=ruin.hatch_candidate,distance=..24,limit=1,sort=nearest] run function ruin:gene/apply_vigor
execute if entity @s[tag=ruin.pending_swift] as @e[type=minecraft:frog,tag=ruin.hatch_candidate,distance=..24,limit=1,sort=nearest] run function ruin:gene/apply_swift
execute if entity @s[tag=ruin.pending_guardian] as @e[type=minecraft:frog,tag=ruin.hatch_candidate,distance=..24,limit=1,sort=nearest] run function ruin:gene/apply_guardian
execute if entity @s[tag=ruin.pending_primal] as @e[type=minecraft:frog,tag=ruin.hatch_candidate,distance=..24,limit=1,sort=nearest] run function ruin:gene/apply_primal
execute if entity @s[tag=ruin.pending_gourmet] as @e[type=minecraft:frog,tag=ruin.hatch_candidate,distance=..24,limit=1,sort=nearest] run function ruin:gene/apply_gourmet
execute if entity @s[tag=ruin.pending_golden] as @e[type=minecraft:frog,tag=ruin.hatch_candidate,distance=..24,limit=1,sort=nearest] run function ruin:gene/apply_golden
execute if entity @s[tag=ruin.pending_arcane] as @e[type=minecraft:frog,tag=ruin.hatch_candidate,distance=..24,limit=1,sort=nearest] run function ruin:gene/apply_arcane
execute if entity @s[tag=ruin.pending_lucky] as @e[type=minecraft:frog,tag=ruin.hatch_candidate,distance=..24,limit=1,sort=nearest] run function ruin:gene/apply_lucky
execute if entity @s[tag=ruin.pending_alchemist] as @e[type=minecraft:frog,tag=ruin.hatch_candidate,distance=..24,limit=1,sort=nearest] run function ruin:gene/apply_alchemist
execute if entity @s[tag=ruin.pending_invincible] as @e[type=minecraft:frog,tag=ruin.hatch_candidate,distance=..24,limit=1,sort=nearest] run function ruin:gene/apply_invincible
tag @e[type=minecraft:frog,tag=ruin.hatch_candidate,distance=..24,limit=1,sort=nearest] add ruin.gene_initialized
tag @e[type=minecraft:frog,tag=ruin.hatch_candidate,distance=..24,limit=1,sort=nearest] remove ruin.hatch_candidate
kill @s
