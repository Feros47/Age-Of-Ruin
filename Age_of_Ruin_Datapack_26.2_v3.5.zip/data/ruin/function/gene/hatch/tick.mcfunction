scoreboard players add @e[type=minecraft:marker,tag=ruin.gene_hatch] ruin_gene_age 1
# Prefer newly emerged, uninitialized animals near the breeding site. Parents are already initialized in normal Age of Ruin play.
execute as @e[type=minecraft:marker,tag=ruin.hatch_turtle] at @s run tag @e[type=minecraft:turtle,tag=!ruin.gene_initialized,tag=!ruin.gene_baby_pending,distance=..24,limit=1,sort=nearest] add ruin.hatch_candidate
execute as @e[type=minecraft:marker,tag=ruin.hatch_turtle] at @s if entity @e[type=minecraft:turtle,tag=ruin.hatch_candidate,distance=..24] run function ruin:gene/hatch/transfer_turtle
execute as @e[type=minecraft:marker,tag=ruin.hatch_frog] at @s run tag @e[type=minecraft:frog,tag=!ruin.gene_initialized,tag=!ruin.gene_baby_pending,distance=..24,limit=1,sort=nearest] add ruin.hatch_candidate
execute as @e[type=minecraft:marker,tag=ruin.hatch_frog] at @s if entity @e[type=minecraft:frog,tag=ruin.hatch_candidate,distance=..24] run function ruin:gene/hatch/transfer_frog
execute as @e[type=minecraft:marker,tag=ruin.hatch_sniffer] at @s run tag @e[type=minecraft:sniffer,tag=!ruin.gene_initialized,tag=!ruin.gene_baby_pending,distance=..24,limit=1,sort=nearest] add ruin.hatch_candidate
execute as @e[type=minecraft:marker,tag=ruin.hatch_sniffer] at @s if entity @e[type=minecraft:sniffer,tag=ruin.hatch_candidate,distance=..24] run function ruin:gene/hatch/transfer_sniffer
# Expire after roughly one real hour to prevent permanent marker buildup if eggs are moved away.
kill @e[type=minecraft:marker,tag=ruin.gene_hatch,scores={ruin_gene_age=1800..}]
