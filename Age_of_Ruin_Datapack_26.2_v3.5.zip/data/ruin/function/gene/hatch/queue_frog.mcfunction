revoke @s only ruin:gene_hatch_frog
summon minecraft:marker ~ ~ ~ {Tags:["ruin.gene_hatch","ruin.hatch_frog"]}
scoreboard players set @e[type=minecraft:marker,tag=ruin.hatch_frog,limit=1,sort=nearest] ruin_gene_age 0
tag @e[type=minecraft:frog,nbt={Age:6000},distance=..16,limit=2,sort=nearest] add ruin.hatch_parent_temp
execute unless entity @e[type=minecraft:frog,tag=ruin.hatch_parent_temp,distance=..16] run tag @e[type=minecraft:frog,distance=..16,limit=2,sort=nearest] add ruin.hatch_parent_temp
scoreboard players set #parents ruin_gene_count 0
execute as @e[type=minecraft:frog,tag=ruin.hatch_parent_temp,tag=ruin.gene_vigor,distance=..16] run scoreboard players add #parents ruin_gene_count 1
execute store result score #roll ruin_gene_roll run random value 1..100
execute if score #parents ruin_gene_count matches 1 if score #roll ruin_gene_roll matches ..55 run tag @e[type=minecraft:marker,tag=ruin.hatch_frog,limit=1,sort=nearest] add ruin.pending_vigor
execute if score #parents ruin_gene_count matches 2.. if score #roll ruin_gene_roll matches ..85 run tag @e[type=minecraft:marker,tag=ruin.hatch_frog,limit=1,sort=nearest] add ruin.pending_vigor
scoreboard players set #parents ruin_gene_count 0
execute as @e[type=minecraft:frog,tag=ruin.hatch_parent_temp,tag=ruin.gene_swift,distance=..16] run scoreboard players add #parents ruin_gene_count 1
execute store result score #roll ruin_gene_roll run random value 1..100
execute if score #parents ruin_gene_count matches 1 if score #roll ruin_gene_roll matches ..55 run tag @e[type=minecraft:marker,tag=ruin.hatch_frog,limit=1,sort=nearest] add ruin.pending_swift
execute if score #parents ruin_gene_count matches 2.. if score #roll ruin_gene_roll matches ..85 run tag @e[type=minecraft:marker,tag=ruin.hatch_frog,limit=1,sort=nearest] add ruin.pending_swift
scoreboard players set #parents ruin_gene_count 0
execute as @e[type=minecraft:frog,tag=ruin.hatch_parent_temp,tag=ruin.gene_guardian,distance=..16] run scoreboard players add #parents ruin_gene_count 1
execute store result score #roll ruin_gene_roll run random value 1..100
execute if score #parents ruin_gene_count matches 1 if score #roll ruin_gene_roll matches ..55 run tag @e[type=minecraft:marker,tag=ruin.hatch_frog,limit=1,sort=nearest] add ruin.pending_guardian
execute if score #parents ruin_gene_count matches 2.. if score #roll ruin_gene_roll matches ..85 run tag @e[type=minecraft:marker,tag=ruin.hatch_frog,limit=1,sort=nearest] add ruin.pending_guardian
scoreboard players set #parents ruin_gene_count 0
execute as @e[type=minecraft:frog,tag=ruin.hatch_parent_temp,tag=ruin.gene_primal,distance=..16] run scoreboard players add #parents ruin_gene_count 1
execute store result score #roll ruin_gene_roll run random value 1..100
execute if score #parents ruin_gene_count matches 1 if score #roll ruin_gene_roll matches ..55 run tag @e[type=minecraft:marker,tag=ruin.hatch_frog,limit=1,sort=nearest] add ruin.pending_primal
execute if score #parents ruin_gene_count matches 2.. if score #roll ruin_gene_roll matches ..85 run tag @e[type=minecraft:marker,tag=ruin.hatch_frog,limit=1,sort=nearest] add ruin.pending_primal
scoreboard players set #parents ruin_gene_count 0
execute as @e[type=minecraft:frog,tag=ruin.hatch_parent_temp,tag=ruin.gene_gourmet,distance=..16] run scoreboard players add #parents ruin_gene_count 1
execute store result score #roll ruin_gene_roll run random value 1..100
execute if score #parents ruin_gene_count matches 1 if score #roll ruin_gene_roll matches ..55 run tag @e[type=minecraft:marker,tag=ruin.hatch_frog,limit=1,sort=nearest] add ruin.pending_gourmet
execute if score #parents ruin_gene_count matches 2.. if score #roll ruin_gene_roll matches ..85 run tag @e[type=minecraft:marker,tag=ruin.hatch_frog,limit=1,sort=nearest] add ruin.pending_gourmet
scoreboard players set #parents ruin_gene_count 0
execute as @e[type=minecraft:frog,tag=ruin.hatch_parent_temp,tag=ruin.gene_golden,distance=..16] run scoreboard players add #parents ruin_gene_count 1
execute store result score #roll ruin_gene_roll run random value 1..100
execute if score #parents ruin_gene_count matches 1 if score #roll ruin_gene_roll matches ..55 run tag @e[type=minecraft:marker,tag=ruin.hatch_frog,limit=1,sort=nearest] add ruin.pending_golden
execute if score #parents ruin_gene_count matches 2.. if score #roll ruin_gene_roll matches ..85 run tag @e[type=minecraft:marker,tag=ruin.hatch_frog,limit=1,sort=nearest] add ruin.pending_golden
scoreboard players set #parents ruin_gene_count 0
execute as @e[type=minecraft:frog,tag=ruin.hatch_parent_temp,tag=ruin.gene_arcane,distance=..16] run scoreboard players add #parents ruin_gene_count 1
execute store result score #roll ruin_gene_roll run random value 1..100
execute if score #parents ruin_gene_count matches 1 if score #roll ruin_gene_roll matches ..55 run tag @e[type=minecraft:marker,tag=ruin.hatch_frog,limit=1,sort=nearest] add ruin.pending_arcane
execute if score #parents ruin_gene_count matches 2.. if score #roll ruin_gene_roll matches ..85 run tag @e[type=minecraft:marker,tag=ruin.hatch_frog,limit=1,sort=nearest] add ruin.pending_arcane
scoreboard players set #parents ruin_gene_count 0
execute as @e[type=minecraft:frog,tag=ruin.hatch_parent_temp,tag=ruin.gene_lucky,distance=..16] run scoreboard players add #parents ruin_gene_count 1
execute store result score #roll ruin_gene_roll run random value 1..100
execute if score #parents ruin_gene_count matches 1 if score #roll ruin_gene_roll matches ..55 run tag @e[type=minecraft:marker,tag=ruin.hatch_frog,limit=1,sort=nearest] add ruin.pending_lucky
execute if score #parents ruin_gene_count matches 2.. if score #roll ruin_gene_roll matches ..85 run tag @e[type=minecraft:marker,tag=ruin.hatch_frog,limit=1,sort=nearest] add ruin.pending_lucky
scoreboard players set #parents ruin_gene_count 0
execute as @e[type=minecraft:frog,tag=ruin.hatch_parent_temp,tag=ruin.gene_alchemist,distance=..16] run scoreboard players add #parents ruin_gene_count 1
execute store result score #roll ruin_gene_roll run random value 1..100
execute if score #parents ruin_gene_count matches 1 if score #roll ruin_gene_roll matches ..55 run tag @e[type=minecraft:marker,tag=ruin.hatch_frog,limit=1,sort=nearest] add ruin.pending_alchemist
execute if score #parents ruin_gene_count matches 2.. if score #roll ruin_gene_roll matches ..85 run tag @e[type=minecraft:marker,tag=ruin.hatch_frog,limit=1,sort=nearest] add ruin.pending_alchemist
execute store result score #roll ruin_gene_roll run random value 1..100
execute if score #roll ruin_gene_roll matches ..3 run function ruin:gene/hatch/mutation_marker
execute store result score #roll ruin_gene_roll run random value 1..400
execute if score #roll ruin_gene_roll matches 1 run tag @e[type=minecraft:marker,tag=ruin.hatch_frog,limit=1,sort=nearest] add ruin.pending_invincible
tag @e[tag=ruin.hatch_parent_temp] remove ruin.hatch_parent_temp
