summon minecraft:zombie ~2 ~ ~ {Tags:["ruin.initialized","ruin.thrall"],CustomName:{text:'Raised Thrall',color:'dark_gray'},PersistenceRequired:1b}
summon minecraft:skeleton ~-2 ~ ~ {Tags:["ruin.initialized","ruin.thrall"],CustomName:{text:'Raised Thrall',color:'dark_gray'},PersistenceRequired:1b}
