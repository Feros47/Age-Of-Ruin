$data modify storage ruin:health label set value {text:"❤ $(current) / $(max) HP",color:"yellow",bold:true}
