$data modify storage ruin:health label set value {text:"❤ $(current) / $(max) HP",color:"red",bold:true}
