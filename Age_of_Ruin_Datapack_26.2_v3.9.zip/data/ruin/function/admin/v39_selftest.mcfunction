tellraw @s {text:'=== AGE OF RUIN v3.9 SELF-TEST ===',color:'gold',bold:true}
function ruin:admin/runtime_status
tellraw @s {text:'Spawning one normal processed Zombie, one guaranteed Elite, and one multi-gene Cow nearby.',color:'gray'}
function ruin:admin/test_scaling
function ruin:admin/test_elite
function ruin:admin/test_gene_loot
tellraw @s {text:'Label test: nearby named entities should show health on line one and their complete name, genes or affixes on line two.',color:'aqua'}
