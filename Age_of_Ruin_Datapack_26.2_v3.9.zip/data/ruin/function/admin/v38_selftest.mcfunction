# Compatibility alias retained for v3.8 operator notes.
function ruin:admin/v39_selftest
