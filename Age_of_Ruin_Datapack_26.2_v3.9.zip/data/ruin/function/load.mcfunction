# Age of Ruin v3.9 loader
scoreboard objectives add ruin_state dummy
scoreboard objectives add ruin_version dummy
execute unless score #version ruin_version matches 39 run function ruin:migrate/v39
execute if score #version ruin_version matches 39 run scoreboard players set #runtime_ready ruin_runtime 0
execute if score #version ruin_version matches 39 run schedule function ruin:runtime/heartbeat 1t replace
execute if score #version ruin_version matches 39 run tellraw @a [{text:'[Age of Ruin] ',color:'dark_red',bold:true},{text:'v3.9 runtime loaded.',color:'gold'}]
