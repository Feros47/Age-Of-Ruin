AGE OF RUIN RESOURCE PACK v3.4 - Minecraft Java 26.2

Resource-pack format: 88.0
Compatible datapack: Age of Ruin v3.9

Install this ZIP as a client resource pack, or distribute its direct-download URL and SHA-1 through server.properties. Do not place it in the world's datapacks folder.

Contents:
- 35 gameplay item definitions plus 10 dedicated boss-display definitions and 45 matching models
- 34 unique 16x16 item textures plus one transparent ten-boss model atlas registered in the Java 26.2 item atlas (Infernal Heart intentionally shares the Infernal Sigil visual)
- English names for all 35 custom items and Fortification

The ten custom bosses use vanilla item_display entities as visual models while invisible carrier mobs provide AI and hitboxes. v3.4 relocates the boss atlas into the client item-atlas namespace and supplies particle references, eliminating the purple/black missing-texture model. Replace v3.3, require v3.4, and reconnect or reload client resources.

The asset chain was validated from every datapack minecraft:item_model reference through item definition, model and PNG texture. A final in-game client visual check is still recommended after upload/distribution.
