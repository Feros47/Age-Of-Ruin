AGE OF RUIN RESOURCE PACK v3.2 - Minecraft Java 26.2

Resource-pack format: 88.0
Compatible datapack: Age of Ruin v3.6

Install this ZIP as a client resource pack, or distribute its direct-download URL and SHA-1 through server.properties. Do not place it in the world's datapacks folder.

Contents:
- 35 custom item definitions and 35 matching models
- 34 unique 16x16 item textures (Infernal Heart intentionally shares the Infernal Sigil visual)
- English names for all 35 custom items and Fortification

The asset chain was validated from every datapack minecraft:item_model reference through item definition, model and PNG texture. A final in-game client visual check is still recommended after upload/distribution.
